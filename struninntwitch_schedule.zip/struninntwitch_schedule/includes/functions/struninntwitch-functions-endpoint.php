<?php
/**
 * Functions - Endpoints
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_channel_schedule_get')) {
  /**
   * Returns Twitch channel current week schedule.
   * 
   * @since 1.0.0
   * 
   * @return array $channel_week_schedule     Twitch channel current week schedule, or error.
   */
  function struninntwitch_channel_schedule_get() {
    $channel_id = struninntwitch_channel_id_get();

    $last_monday = new DateTime('monday this week');

    $schedule_filters = [];

    // check if data exists in cache and is not stale before requesting endpoint
    $cache_stale_age = absint(struninntwitch_customizer_setting_value_get('struninntwitch_setting_schedule_cache_age'));
    $cache_stale_unit = struninntwitch_customizer_setting_value_get('struninntwitch_setting_schedule_cache_unit');

    $cache_data_is_stale = struninntwitch_cache_channel_data_is_stale($channel_id, $cache_stale_age, $cache_stale_unit, 'schedule', $schedule_filters);

    if ($cache_data_is_stale) {
      $schedule_params = $schedule_filters;

      $last_monday = new DateTime('monday this week');

      // format: 2006-01-02T15:04:05Z
      $schedule_params['start_time'] = $last_monday->format('Y-m-d\TH:i:s\Z');
      $schedule_params['broadcaster_id'] = $channel_id;
  
      $channel_schedule = struninntwitch_endpoint_data_get('schedule', $schedule_params);
  
      if (is_wp_error($channel_schedule)) {
        return struninntwitch_error_get($channel_schedule);
      }
  
      if (is_array($channel_schedule) && array_key_exists('error', $channel_schedule)) {
        if (array_key_exists('status', $channel_schedule) && array_key_exists('message', $channel_schedule)) {
          $channel_week_schedule = $channel_schedule;
        } else {
          $channel_week_schedule = struninntwitch_error_get();
        }
      } else {
        $channel_week_schedule = [];
        
        $next_monday = new DateTime('monday next week');
  
        $game_data = [];
        
        foreach ($channel_schedule['data']['segments'] as $segment) {
          // Twitch timestamps are in RFC3339 format
          $segment_stream_start_date = DateTime::createFromFormat('Y-m-d\TH:i:s\Z', $segment['start_time']);
    
          // if segment stream start date is in the current week, save it
          if (($segment_stream_start_date > $last_monday) && ($segment_stream_start_date < $next_monday)) {
            // add game / category data if it exists in the segment
            if (is_array($segment['category'])) {
              $game_id = $segment['category']['id'];
  
              // only fetch each game data once
              if (!array_key_exists($game_id, $game_data)) {
                $segment_game_data = struninntwitch_game_get($game_id);
  
                if ($segment_game_data) {
                  $game_data[$game_id] = $segment_game_data;
                }
              }
  
              $segment['category']['box_art_url'] = '';
  
              // add game data
              if (array_key_exists('box_art_url', $segment['category'])) {
                $segment['category']['box_art_url'] = $game_data[$game_id]['box_art_url'];
              }
            }
  
            $channel_week_schedule[] = $segment;
          }
        }

        // update channel week schedule cache data
        struninntwitch_cache_channel_data_update($channel_id, $channel_week_schedule, 'schedule', $schedule_filters);
      }
    } else {
      $channel_week_schedule = struninntwitch_cache_channel_endpoint_data_get($channel_id, 'schedule', $schedule_filters);
    }

    return $channel_week_schedule;
  }
}

if (!function_exists('struninntwitch_game_get')) {
  /**
   * Returns Twitch game or category data.
   * 
   * @since 1.0.0
   * 
   * @param string $game_id             Twitch game or category ID.
   * @return array|bool $game_data      Twitch game data, or false on error.
   */
  function struninntwitch_game_get($game_id) {
    $game_data = false;

    $twitch_game_data = struninntwitch_endpoint_data_get('games', ['id' => $game_id]);

    if (is_array($twitch_game_data) && array_key_exists('data', $twitch_game_data)) {
      $game_data = $twitch_game_data['data'][0];
    }

    return $game_data;
  }
}

?>