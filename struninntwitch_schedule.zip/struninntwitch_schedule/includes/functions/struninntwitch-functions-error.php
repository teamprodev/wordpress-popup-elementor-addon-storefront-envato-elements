<?php
/**
 * Functions - Error
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_error_get')) {
  /**
   * Returns error data.
   * 
   * @since 1.0.0
   * 
   * @param array|WP_Error $args {
   *   @type string $title    Error title.
   *   @type string $text     Error text.
   *   @type int    $code     Error status code.
   * }
   * @return array $error     Error data.
   */
  function struninntwitch_error_get($args = []) {
    $defaults = [
      'title' => esc_html__('Error', 'struninntwitch_schedule'),
      'text'  => esc_html__('An error has ocurred', 'struninntwitch_schedule'),
      'code'  => 500
    ];

    if (is_wp_error($args)) {
      $args = [
        'text'  => $args->get_error_message(),
        'code'  => $args->get_error_code()
      ];
    }

    $options = array_merge($defaults, $args);
    
    $error = [
      'error'   => $options['title'],
      'status'  => $options['code'],
      'message' => $options['text']
    ];

    return $error;
  }
}

if (!function_exists('struninntwitch_error_invalid_client_id_get')) {
  /**
   * Returns invalid client ID error.
   * 
   * @since 1.0.0
   * 
   * @return array $error     Error data.
   */
  function struninntwitch_error_invalid_client_id_get() {
    $error = struninntwitch_error_get([
      'title' => esc_html__('Authorization Failed', 'struninntwitch_schedule'),
      'text'  => esc_html__('Invalid application client ID', 'struninntwitch_schedule'),
      'code'  => 401
    ]);

    return $error;
  }
}

if (!function_exists('struninntwitch_error_invalid_client_secret_get')) {
  /**
   * Returns invalid client secret error.
   * 
   * @since 1.0.0
   * 
   * @return array $error     Error data.
   */
  function struninntwitch_error_invalid_client_secret_get() {
    $error = struninntwitch_error_get([
      'title' => esc_html__('Authorization Failed', 'struninntwitch_schedule'),
      'text'  => esc_html__('Invalid application client secret', 'struninntwitch_schedule'),
      'code'  => 401
    ]);

    return $error;
  }
}

if (!function_exists('struninntwitch_error_invalid_access_token_get')) {
  /**
   * Returns invalid access token error.
   * 
   * @since 1.0.0
   * 
   * @return array $error     Error data.
   */
  function struninntwitch_error_invalid_access_token_get() {
    $error = struninntwitch_error_get([
      'title' => esc_html__('Authorization Failed', 'struninntwitch_schedule'),
      'text'  => esc_html__('Invalid application access token', 'struninntwitch_schedule'),
      'code'  => 401
    ]);

    return $error;
  }
}

if (!function_exists('struninntwitch_error_invalid_channel_id_get')) {
  /**
   * Returns invalid channel ID error.
   * 
   * @since 1.0.0
   * 
   * @return array $error     Error data.
   */
  function struninntwitch_error_invalid_channel_id_get() {
    $error = struninntwitch_error_get([
      'title' => esc_html__('Not Found', 'struninntwitch_schedule'),
      'text'  => esc_html__('Invalid channel ID', 'struninntwitch_schedule'),
      'code'  => 404
    ]);

    return $error;
  }
}

if (!function_exists('struninntwitch_error_invalid_data_get')) {
  /**
   * Returns invalid data error.
   * 
   * @since 1.0.0
   * 
   * @return array $error     Error data.
   */
  function struninntwitch_error_invalid_data_get() {
    $error = struninntwitch_error_get([
      'title' => esc_html__('Malformed Data', 'struninntwitch_schedule'),
      'text'  => esc_html__('Invalid data returned from the application', 'struninntwitch_schedule'),
      'code'  => 500
    ]);

    return $error;
  }
}

?>