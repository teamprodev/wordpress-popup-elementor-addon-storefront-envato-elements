<?php
/**
 * Functions
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Cache
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/cache/struninntwitch-functions-cache.php';

/**
 * Translation
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-translation.php';

/**
 * Utils
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-utils.php';

/**
 * Plugin
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-plugin.php';

/**
 * Error
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-error.php';

/**
 * API
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-api.php';

/**
 * Endpoint
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-endpoint.php';

/**
 * Template
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/template/struninntwitch-functions-template.php';

/**
 * Shortcode
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions-shortcode.php';

/**
 * Load Elementor related functions
 * if the plugin is installed and active
 */
if (struninntwitch_plugin_elementor_is_active()) {
  /**
   * Elementor
   */
  require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/elementor/struninntwitch-functions-elementor.php';
}

?>