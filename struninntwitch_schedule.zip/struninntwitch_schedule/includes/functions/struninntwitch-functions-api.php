<?php
/**
 * Functions - API
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_app_new_access_token_get')) {
  /**
   * Returns a new Twitch application access token.
   * 
   * @since 1.0.0
   * 
   * @param array $access_keys {
   *   @type string $client_id        Twitch application Client ID.
   *   @type string $client_secret    Twitch application Client Secret.
   *   @type string $access_token     Twitch application Access Token.
   * }
   * @return string|bool $app_access_token       Twitch application Access Token on success, false on error.
   */
  function struninntwitch_app_new_access_token_get($access_keys = []) {
    $app_access_token = false;

    $oauth_endpoint_url = 'https://id.twitch.tv/oauth2/token';

    $client_id = array_key_exists('client_id', $access_keys) ? $access_keys['client_id'] : false;
    $client_secret = array_key_exists('client_secret', $access_keys) ? $access_keys['client_secret'] : false;

    if ($client_id && $client_secret) {
      $oauth_endpoint_params = [
        'client_id=' . $client_id,
        'client_secret=' . $client_secret,
        'grant_type=client_credentials'
      ];
    
      $request_url = $oauth_endpoint_url . '?' . implode('&', $oauth_endpoint_params);
      $response = wp_remote_post($request_url);
  
      if (!is_wp_error($response)) {
        $response_body = json_decode($response['body']);
        $status_property_exists = property_exists($response_body, 'status');
  
        // successful response either doesn't have a status property or it has it and it equals 200.
        if (!$status_property_exists || ($status_property_exists && ($response_body->status === 200))) {
          $app_access_token = (json_decode($response['body']))->access_token;
        }
      }
    }
  
    return $app_access_token;
  }
}

if (!function_exists('struninntwitch_app_access_token_is_valid')) {
  /**
   * Check if a given Twitch application Access Token is valid (hasn't expired).
   * 
   * @since 1.0.0
   * 
   * @param string  $app_access_token             Twitch application access token to verify validity of.
   * @return bool   $app_access_token_is_valid    True if the application access token is valid, false otherwise.
   */
  function struninntwitch_app_access_token_is_valid($app_access_token) {
    $app_access_token_is_valid = false;

    $oauth_endpoint_url = 'https://id.twitch.tv/oauth2/validate';
    $headers = [
      'headers' => [
        'Authorization' => 'Bearer ' . $app_access_token
      ]
    ];

    $response = wp_remote_get($oauth_endpoint_url, $headers);

    if (!is_wp_error($response)) {
      $response_body = json_decode($response['body']);
      $status_property_exists = property_exists($response_body, 'status');

      // successful response either doesn't have a status property or it has it and it equals 200.
      if (!$status_property_exists || ($status_property_exists && ($response_body->status === 200))) {
        $app_access_token_is_valid = true;
      }
    }

    return $app_access_token_is_valid;
  }
}

if (!function_exists('struninntwitch_app_access_token_get')) {
  /**
   * Returns a new Twitch application access token.
   * 
   * @since 1.0.0
   * 
   * @param array $access_keys {
   *   @type string $client_id        Twitch application Client ID.
   *   @type string $client_secret    Twitch application Client Secret.
   *   @type string $access_token     Twitch application Access Token.
   * }
   * @return string|bool $app_access_token       Twitch application Access Token on success, false on error.
   */
  function struninntwitch_app_access_token_get($access_keys) {
    // get existing oauth access token
    $app_access_token = $access_keys['access_token'];

    $app_access_token_exists = $app_access_token !== '';
    $app_access_token_is_valid = $app_access_token_exists && struninntwitch_app_access_token_is_valid($app_access_token);

    // if a Twitch application access token doesn't exist or is invalid
    // generate a new access token and save it
    if (!($app_access_token_exists && $app_access_token_is_valid)) {
      $app_access_token = struninntwitch_app_new_access_token_get($access_keys);

      $access_token_updated = update_option('struninntwitch_setting_app_access_token', $app_access_token);

      if (!$access_token_updated) {
        $app_access_token = false;
      }
    }

    return $app_access_token;
  }
}

if (!function_exists('struninntwitch_endpoint_data_get')) {
  /**
   * Returns Twitch endpoint resource data.
   * 
   * @since 1.0.0
   * 
   * @param string  $resource     Twitch endpoint resource.
   * @param array   $params       Twitch endpoint resource params.
   * @return array  $result       Twitch endpoint resource data.        
   */
  function struninntwitch_endpoint_data_get($resource = '', $params = []) {
    $result = struninntwitch_error_invalid_access_token_get();
    
    $endpoint = 'https://api.twitch.tv/helix/';
    $endpoint_url = $endpoint . $resource;

    $access_keys = struninntwitch_access_keys_get();

    if ($access_keys['client_id'] === '') {
      return struninntwitch_error_invalid_client_id_get();
    }
    
    if ($access_keys['client_secret'] === '') {
      return struninntwitch_error_invalid_client_secret_get();
    }

    if (array_key_exists('broadcaster_id', $params) && ($params['broadcaster_id'] === '')) {
      return struninntwitch_error_invalid_channel_id_get();
    }

    if (array_key_exists('user_id', $params) && ($params['user_id'] === '')) {
      return struninntwitch_error_invalid_channel_id_get();
    }

    $app_access_token = struninntwitch_app_access_token_get($access_keys);

    if ($app_access_token) {
      $headers = array(
        'headers' => array(
          'Client-ID'     => $access_keys['client_id'],
          'Authorization' => 'Bearer ' . $app_access_token
        )
      );

      if (count($params) > 0) {
        $parameters = [];

        foreach ($params as $param_name => $param_value) {
          $parameters[] = $param_name . '=' . $param_value;
        }
      
        $endpoint_url .= '?' . implode('&', $parameters);
      }

      $response = wp_remote_get($endpoint_url, $headers);

      if (is_wp_error($response)) {
        $result = struninntwitch_error_get($response);
      } else {
        if (is_array($response)) {
          $result = json_decode($response['body'], true);
        } else {
          $result = struninntwitch_error_invalid_data_get();
        }
      }
    }

    return $result;
  }
}

?>