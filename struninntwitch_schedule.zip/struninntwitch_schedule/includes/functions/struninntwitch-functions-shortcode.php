<?php
/**
 * Functions - Shortcode
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_shortcode_args_parse')) {
  /**
   * Returns parsed shortcode args.
   * 
   * @since 1.0.0
   * 
   * @param array   $shortcode_args               Shortcode args.
   * @return array  $parsed_shortcode_args        Parsed shortcode args.
   */
  function struninntwitch_shortcode_args_parse($shortcode_args) {
    $parsed_shortcode_args = [];

    foreach ((array) $shortcode_args as $shortcode_arg_key => $shortcode_arg_value) {
      $value = $shortcode_arg_value;

      if ($shortcode_arg_key === 'additional_wrapper_classes') {
        $value = explode(',', str_replace(' ', '', $value));
      } else if ($value === 'true') {
        $value = true;
      } else if ($value === 'false') {
        $value = false;
      }

      $parsed_shortcode_args[$shortcode_arg_key] = $value;
    }

    return $parsed_shortcode_args;
  }
}

add_filter('struninntwitch_shortcode_args', 'struninntwitch_shortcode_args_parse');

if (!function_exists('struninntwitch_schedule_shortcode_register')) {
  /**
   * Register shortcodes.
   * 
   * @since 1.0.0
   */
  function struninntwitch_schedule_shortcode_register() {
    $shortcodes = [
      'struninntwitch_channel_subscribe_button' => [
        'shortcode_callback'    => 'struninntwitch_template_channel_subscribe_button_get',
        'default_args_callback' => 'struninntwitch_template_channel_subscribe_button_args_default_get'
      ],
      'struninntwitch_channel_schedule' => [
        'shortcode_callback'    => 'struninntwitch_template_channel_schedule_get',
        'default_args_callback' => 'struninntwitch_template_channel_schedule_args_default_get'
      ]
    ];

    foreach ($shortcodes as $shortcode_name => $shortcode_data) {
      add_shortcode($shortcode_name, function ($args) use ($shortcode_name, $shortcode_data) {
        $shortcode_args_defaults = call_user_func($shortcode_data['default_args_callback']);
    
        $shortcode_args = apply_filters('struninntwitch_shortcode_args', $args);

        $args = shortcode_atts($shortcode_args_defaults, $shortcode_args, $shortcode_name);

        return call_user_func($shortcode_data['shortcode_callback'], $args);
      });
    }
  }
}

struninntwitch_schedule_shortcode_register();

?>