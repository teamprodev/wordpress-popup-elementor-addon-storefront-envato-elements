<?php
/**
 * Functions - Translation
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_schedule_translation_get')) {
  /**
   * Returns translation strings for dynamic scripts.
   * 
   * @since 1.0.0
   * 
   * @return array $translation_strings     Translation strings.
   */
  function struninntwitch_schedule_translation_get() {
    $translation_strings = [
      'view_the_full_schedule'  => esc_html__('View the Full Schedule', 'struninntwitch_schedule')
    ];

    return $translation_strings;
  }
}

?>