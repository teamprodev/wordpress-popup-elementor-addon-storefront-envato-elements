<?php
/**
 * Functions - Elementor
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_schedule_elementor_widgets_register')) {
  /**
   * Registers Elementor widgets.
   * 
   * @since 1.0.0
   * 
   * @param object $widgets_manager     Elementot widgets manager instance.
   */
  function struninntwitch_schedule_elementor_widgets_register($widgets_manager) {
    require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/elementor/widgets/subscribe/StruninnTwitch_Elementor_Widget_Channel_Subscribe_Button.php';
    require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/elementor/widgets/schedule/StruninnTwitch_Elementor_Widget_Channel_Schedule.php';

    $widgets_manager->register(new StruninnTwitch_Elementor_Widget_Channel_Subscribe_Button());
    $widgets_manager->register(new StruninnTwitch_Elementor_Widget_Channel_Schedule());
  }
}

add_action('elementor/widgets/register', 'struninntwitch_schedule_elementor_widgets_register');

if (!function_exists('struninntwitch_elementor_widget_categories_register')) {
  /**
   * Registers Elementor categories.
   * 
   * @since 1.0.0
   * 
   * @param object $elements_manager      Elementor elements manager instance.
   */
  function struninntwitch_elementor_widget_categories_register($elements_manager) {
    $elements_manager->add_category(
      'struninntwitch',
      [
        'title' => esc_html_x('Struninn for Twitch', '(Elementor) Struninn Twitch Category - Title', 'struninntwitch_schedule')
      ]
    );
  }
}

add_action('elementor/elements/categories_registered', 'struninntwitch_elementor_widget_categories_register');

if (!function_exists('struninntwitch_elementor_widget_color_options_get')) {
  /**
   * Returns color options for an Elementor widget.
   * 
   * @since 1.0.0
   * 
   * @param string $elementor_widget_name                 Elementor widget to return color options for.
   * @return array $elementor_widget_color_options        Color options for Elementor widget.
   */
  function struninntwitch_elementor_widget_color_options_get($elementor_widget_name) {
    $elementor_widget_applicable_color_options = [
      'channel_subscribe_button'  => [
        '--struninntwitch-global-primary-color',
        '--struninntwitch-button-color'
      ],
      'channel_schedule'          => [
        '--struninntwitch-global-primary-color',
        '--struninntwitch-box-background-color',
        '--struninntwitch-border-color',
        '--struninntwitch-text-primary-color',
        '--struninntwitch-text-bold-color',
        '--struninntwitch-button-color'
      ],
      'channel_videos'            => [
        '--struninntwitch-global-primary-color',
        '--struninntwitch-button-color'
      ]
    ];

    $elementor_widget_color_options = [];

    $color_options = struninntwitch_customizer_color_options_get();

    if (array_key_exists($elementor_widget_name, $elementor_widget_applicable_color_options)) {
      foreach ($elementor_widget_applicable_color_options[$elementor_widget_name] as $elementor_widget_applicable_color_option) {
        if (array_key_exists($elementor_widget_applicable_color_option, $color_options)) {
          $elementor_widget_color_options[$elementor_widget_applicable_color_option] = $color_options[$elementor_widget_applicable_color_option];
        }
      }
    }

    return $elementor_widget_color_options;
  }
}


if (!function_exists('struninntwitch_elementor_widget_color_styles_get')) {
  /**
   * Returns style variables for Elementor widget settings.
   * 
   * @since 1.0.0
   * 
   * @param array   $elementor_widget_settings      Elementor widget settings.
   * @param array   $color_settings                 Color settings.
   * @return string $color_styles                   Color style variables.
   */
  function struninntwitch_elementor_widget_color_styles_get($elementor_widget_settings, $color_settings) {
    $color_styles = '';

    foreach ($color_settings as $color_setting_name => $color_setting_data) {
      if (array_key_exists($color_setting_name, $elementor_widget_settings) && ($elementor_widget_settings[$color_setting_name] !== $color_setting_data['default'])) {
        $color_styles .= $color_setting_name . ':' . $elementor_widget_settings[$color_setting_name] . ';';
      }
    }

    return $color_styles;
  }
}

?>