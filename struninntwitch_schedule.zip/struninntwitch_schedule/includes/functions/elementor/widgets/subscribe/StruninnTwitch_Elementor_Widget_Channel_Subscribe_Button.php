<?php
/**
 * Functions - Elementor - Widget
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!class_exists('StruninnTwitch_Elementor_Widget_Channel_Subscribe_Button')) {
  /**
   * Channel Subscribe Elementor Widget.
   * 
   * @since 1.0.0
   */
  class StruninnTwitch_Elementor_Widget_Channel_Subscribe_Button extends \Elementor\Widget_Base {
    public function get_name() {
      return 'struninntwitch_elementor_widget_channel_subscribe_button';
    }
  
    public function get_title() {
      return esc_html__('Channel Subscribe Button', 'struninntwitch_schedule');
    }
  
    public function get_icon() {
      return 'eicon-button';
    }
  
    public function get_categories() {
      return ['struninntwitch'];
    }
  
    public function get_keywords() {
      return ['struninn', 'struninntwitch', 'twitch', 'channel', 'subscribe', 'button'];
    }
  
    protected function register_controls() {
      $this->start_controls_section(
        'struninntwitch_channel_subscribe_button_content',
        [
          'label' => esc_html__('Content', 'struninntwitch_schedule'),
          'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
      );

      $this->add_control(
        'struninntwitch_channel_subscribe_button_text',
        [
          'label'   => esc_html__('Text', 'struninntwitch_schedule'),
          'type'    => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__('Subscribe!', 'struninntwitch_schedule')
        ]
      );

      $this->add_control(
        'struninntwitch_channel_subscribe_button_url',
        [
          'label'       => esc_html__('URL', 'struninntwitch_schedule'),
          'type'        => \Elementor\Controls_Manager::TEXT,
          'input_type'  => 'url',
          'default'     => struninntwitch_channel_subscribe_url_get()
        ]
      );

      $this->end_controls_section();

      $color_settings = struninntwitch_elementor_widget_color_options_get('channel_subscribe_button');

      $this->start_controls_section(
        'struninntwitch_channel_subscribe_button_style',
        [
          'label' => esc_html__('Colors', 'struninntwitch_schedule'),
          'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ]
      );

      foreach ($color_settings as $color_setting_name => $color_setting_data) {
        $this->add_control(
          $color_setting_name,
          [
            'label'   => $color_setting_data['label'],
            'type'    => \Elementor\Controls_Manager::COLOR,
            'default' => $color_setting_data['default']
          ]
        );
      }
  
      $this->end_controls_section();
    }
  
    protected function render() {
      $settings = $this->get_settings_for_display();

      $color_settings = struninntwitch_elementor_widget_color_options_get('channel_subscribe_button');

      $styles = struninntwitch_elementor_widget_color_styles_get($settings, $color_settings);

      $args = [
        'text'    => $settings['struninntwitch_channel_subscribe_button_text'],
        'href'    => $settings['struninntwitch_channel_subscribe_button_url'],
        'styles'  => $styles
      ];
    
      struninntwitch_template_channel_subscribe_button($args);
    }
  }
}

?>