<?php
/**
 * Functions - Elementor - Widget
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!class_exists('StruninnTwitch_Elementor_Widget_Channel_Schedule')) {
  /**
   * Channel Schedule Elementor Widget.
   * 
   * @since 1.0.0
   */
  class StruninnTwitch_Elementor_Widget_Channel_Schedule extends \Elementor\Widget_Base {
    public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);

      wp_register_script('struninntwitch-elementor-widget-channel-schedule', STRUNINNTWITCH_SCHEDULE_URL . 'js/elementor/widget/schedule/channelSchedule.bundle.min.js', ['elementor-frontend'], '1.0.0', true);
    }

    public function get_name() {
      return 'struninntwitch_elementor_widget_channel_schedule';
    }
  
    public function get_title() {
      return esc_html__('Channel Schedule', 'struninntwitch_schedule');
    }
  
    public function get_icon() {
      return 'eicon-archive';
    }
  
    public function get_categories() {
      return ['struninntwitch'];
    }
  
    public function get_keywords() {
      return ['struninn', 'struninntwitch', 'twitch', 'channel', 'schedule'];
    }
  
    protected function register_controls() {
      $this->start_controls_section(
        'struninntwitch_channel_schedule_content',
        [
          'label' => esc_html__('Content', 'struninntwitch_schedule'),
          'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
      );

      $this->add_control(
        'struninntwitch_channel_schedule_template',
        [
          'label'   => esc_html__('Template', 'struninntwitch_schedule'),
          'type'    => \Elementor\Controls_Manager::SELECT,
          'default' => 'table',
          'options' => [
            'table' => esc_html__('V1', 'struninntwitch_schedule'),
            'grid'  => esc_html__('V2', 'struninntwitch_schedule')
          ]
        ]
      );

      $this->add_control(
        'struninntwitch_channel_schedule_hide_more_button',
        [
          'label'         => esc_html__('More Button', 'struninntwitch_schedule'),
          'type'          => \Elementor\Controls_Manager::SWITCHER,
          'return_value'  => 'yes',
          'default'       => 'yes'
        ]
      );

      $this->end_controls_section();

      $color_settings = struninntwitch_elementor_widget_color_options_get('channel_schedule');

      $this->start_controls_section(
        'struninntwitch_channel_schedule_style',
        [
          'label' => esc_html__('Colors', 'struninntwitch_schedule'),
          'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ]
      );

      foreach ($color_settings as $color_setting_name => $color_setting_data) {
        $this->add_control(
          $color_setting_name,
          [
            'label'   => $color_setting_data['label'],
            'type'    => \Elementor\Controls_Manager::COLOR,
            'default' => $color_setting_data['default']
          ]
        );
      }
  
      $this->end_controls_section();
    }
  
    protected function render() {
      $settings = $this->get_settings_for_display();

      $color_settings = struninntwitch_elementor_widget_color_options_get('channel_schedule');

      $styles = struninntwitch_elementor_widget_color_styles_get($settings, $color_settings);

      $args = [
        'template'          => $settings['struninntwitch_channel_schedule_template'],
        'styles'            => $styles,
        'hide_more_button'  => $settings['struninntwitch_channel_schedule_hide_more_button'] !== 'yes'
      ];
    
      struninntwitch_template_channel_schedule($args);
    }

    public function get_script_depends() {
      return ['struninntwitch-elementor-widget-channel-schedule'];
    }
  }
}

?>