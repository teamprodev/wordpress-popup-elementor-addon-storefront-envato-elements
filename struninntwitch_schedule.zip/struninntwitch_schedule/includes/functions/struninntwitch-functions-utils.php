<?php
/**
 * Functions - Utils
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_access_keys_get')) {
  /**
   * Returns Twitch application access keys.
   * 
   * @since 1.0.0
   * 
   * @return array $access_keys {
   *   @type string $client_id        Twitch application Client ID.
   *   @type string $client_secret    Twitch application Client Secret.
   *   @type string $access_token     Twitch application Access Token.
   * }
   */
  function struninntwitch_access_keys_get() {
    $access_keys = [
      'client_id'     => struninntwitch_customizer_setting_value_get('struninntwitch_setting_app_client_id'),
      'client_secret' => struninntwitch_customizer_setting_value_get('struninntwitch_setting_app_client_secret'),
      'access_token'  => struninntwitch_customizer_setting_value_get('struninntwitch_setting_app_access_token')
    ];

    return $access_keys;
  }
}

if (!function_exists('struninntwitch_channel_id_get')) {
  /**
   * Returns Twitch channel id.
   * 
   * @since 1.0.0
   * 
   * @return string $channel_id       Twitch channel id.
   */
  function struninntwitch_channel_id_get() {
    $channel_id = struninntwitch_customizer_setting_value_get('struninntwitch_setting_channel_id');

    // if there was a network error when the user saved the channel name via the customizer
    // then the channel id could not be found.
    // fetch and update the channel id setting with the current channel name setting.
    if (!$channel_id) {
      $channel_name = struninntwitch_customizer_setting_value_get('struninntwitch_setting_channel_name');

      if ($channel_name) {
        $channel_id_updated = struninntwitch_customizer_setting_channel_id_update($channel_name);
      }
    }

    return $channel_id;
  }
}

if (!function_exists('struninntwitch_channel_url_get')) {
  /**
   * Returns channel URL.
   * 
   * @since 1.0.0
   * 
   * @param string  $endpoint           Channel endpoint.
   * @return string $channel_url        Channel URL.
   */
  function struninntwitch_channel_url_get($endpoint = false) {
    $channel_url = '#';

    $channel_name = struninntwitch_customizer_setting_value_get('struninntwitch_setting_channel_name');

    if ($channel_name) {
      $channel_url = 'https://twitch.tv/' . $channel_name;

      if ($endpoint) {
        $channel_url .= '/' . $endpoint;
      }
    }

    return $channel_url;
  }
}

if (!function_exists('struninntwitch_channel_subscribe_url_get')) {
  /**
   * Returns channel subscribe URL.
   * 
   * @since 1.0.0
   * 
   * @return string $channel_subscribe_url        Channel subscribe URL.
   */
  function struninntwitch_channel_subscribe_url_get() {
    $channel_subscribe_url = struninntwitch_channel_url_get('subscribe');

    return $channel_subscribe_url;
  }
}

if (!function_exists('struninntwitch_channel_schedule_url_get')) {
  /**
   * Returns channel subscribe URL.
   * 
   * @since 1.0.0
   * 
   * @return string $channel_schedule_url        Channel subscribe URL.
   */
  function struninntwitch_channel_schedule_url_get() {
    $channel_schedule_url = struninntwitch_channel_url_get('schedule');

    return $channel_schedule_url;
  }
}

if (!function_exists('struninntwitch_schedule_constants_get')) {
  /**
   * Returns plugin constants as a string.
   * 
   * @since 1.0.0
   * 
   * @return string $constants        Plugin constants.
   */
  function struninntwitch_schedule_constants_get() {
    $constants_values = [
      'restURL'             => get_rest_url(null, 'struninntwitch/v1/'),
      'channelScheduleURL'  => struninntwitch_channel_schedule_url_get()
    ];

    $constants = 'const struninntwitchScheduleConstants = ' . json_encode($constants_values) . ';';

    return $constants;
  }
}

?>