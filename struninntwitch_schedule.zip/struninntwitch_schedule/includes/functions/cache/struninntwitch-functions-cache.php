<?php
/**
 * Cache
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_cache_channel_file_path_get')) {
  /**
   * Returns channel cache file path.
   * 
   * @return string $channeL_cache_file_path        Channel cache file path.
   */
  function struninntwitch_cache_channel_file_path_get() {
    $channel_cache_file_directory = STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/cache/';
    $channel_cache_file_name = 'struninntwitch-cache.json';
    $channel_cache_file_path = $channel_cache_file_directory . $channel_cache_file_name;

    return $channel_cache_file_path;
  }
}

if (!function_exists('struninntwitch_cache_channel_file_get')) {
  /**
   * Returns cache file content.
   * 
   * @since 1.0.0
   * 
   * @return array|bool $file_content       False if file doesn't exist, file content otherwise.
   */
  function struninntwitch_cache_channel_file_get() {
    $file_content = false;

    $channel_cache_file_path = struninntwitch_cache_channel_file_path_get();

    if (file_exists($channel_cache_file_path)) {
      $file_content = json_decode(file_get_contents($channel_cache_file_path), true);      
    }

    return $file_content;
  }
}

if (!function_exists('struninntwitch_cache_channel_file_update')) {
  /**
   * Updates cache file content.
   * 
   * @since 1.0.0
   * 
   * @param array $file_content       Content to update cache file with.
   * @return int|bool $result         Number of bytes that were written to the file, or false on failure.
   */
  function struninntwitch_cache_channel_file_update($file_content) {
    $channel_cache_file_path = struninntwitch_cache_channel_file_path_get();

    $result = file_put_contents($channel_cache_file_path, json_encode($file_content));

    return $result;
  }
}

if (!function_exists('struninntwitch_cache_channel_endpoint_get')) {
  /**
   * Returns cached channel endpoint.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id                    ID of the channel to retrieve cached endpoint data of.
   * @param string $endpoint                      Name of the endpoint to retrieve.
   * @param array  $filters                       Filters associated with the endpoint. Optional.
   * @return array|bool $channel_endpoint         Cached channel endpoint, or false if no data found.
   */
  function struninntwitch_cache_channel_endpoint_get($channel_id, $endpoint, $filters = false) {
    $channel_endpoint = false;

    if ($channel_id) {
      $cached_data = struninntwitch_cache_channel_file_get();

      // there is a saved cached file with data
      if ($cached_data) {
        $channel_id_has_data = array_key_exists($channel_id, $cached_data);
        $channel_id_has_endpoint = $channel_id_has_data && array_key_exists($endpoint, $cached_data[$channel_id]);

        // the channel id has data associated and the endpoint exists
        if ($channel_id_has_data && $channel_id_has_endpoint) {
          $channel_endpoint_items = $cached_data[$channel_id][$endpoint];

          // cached data has filters associated
          if ($filters) {
            // search cached data for complete filters match
            foreach ($channel_endpoint_items as $channel_endpoint_item) {
              if (count(array_keys($filters)) !== count(array_keys($channel_endpoint_item['filters']))) {
                continue;
              }

              $filter_match_count = 0;

              foreach ($filters as $filter_name => $filter_value) {
                $filter_name_exists = array_key_exists($filter_name, $channel_endpoint_item['filters']);
                $filter_is_equal = $filter_name_exists && ($channel_endpoint_item['filters'][$filter_name] === $filter_value);

                if ($filter_is_equal) {
                  $filter_match_count++;
                }
              }

              // if all filters match, the data was found
              if ($filter_match_count === count(array_keys($filters))) {
                $channel_endpoint = $channel_endpoint_item;
                break;
              }
            }
          // cached data doesn't have filters associated, return no filters data if it exists
          } else {
            foreach ($channel_endpoint_items as $channel_endpoint_item) {
              if (count(array_keys($channel_endpoint_item['filters'])) === 0) {
                $channel_endpoint = $channel_endpoint_item;
                break;
              }
            }
          }
        }
      }
    }

    return $channel_endpoint;
  }
}

if (!function_exists('struninntwitch_cache_channel_endpoint_resource_get')) {
  /**
   * Returns cached channel endpoint resource data.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id                              ID of the channel to retrieve cached endpoint data of.
   * @param string $resource                                Name of the resource to retrieve data of.
   * @param string $endpoint                                Name of the endpoint to retrieve resource data from.
   * @param array  $filters                                 Filters associated with the data. Optional.
   * @return array|bool $channel_endpoint_resource_data     Cached channel endpoint data, or false if no data found.
   */
  function struninntwitch_cache_channel_endpoint_resource_get($channel_id, $resource, $endpoint, $filters = false) {
    $channel_endpoint_resource_data = false;

    $channel_endpoint = struninntwitch_cache_channel_endpoint_get($channel_id, $endpoint, $filters);

    if ($channel_endpoint && array_key_exists($resource, $channel_endpoint)) {
      $channel_endpoint_resource_data = $channel_endpoint[$resource];
    }

    return $channel_endpoint_resource_data;
  }
}

if (!function_exists('struninntwitch_cache_channel_endpoint_data_get')) {
  /**
   * Returns cached channel endpoint data.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id                    ID of the channel to retrieve cached endpoint data of.
   * @param string $endpoint                      Name of the endpoint to retrieve data from.
   * @param array  $filters                       Filters associated with the data. Optional.
   * @return array|bool $channel_endpoint_data    Cached channel endpoint data, or false if no data found.
   */
  function struninntwitch_cache_channel_endpoint_data_get($channel_id, $endpoint, $filters = false) {
    $channel_endpoint_data = struninntwitch_cache_channel_endpoint_resource_get($channel_id, 'data', $endpoint, $filters);

    return $channel_endpoint_data;
  }
}

if (!function_exists('struninntwitch_cache_channel_endpoint_data_creation_date_get')) {
  /**
   * Returns cached channel endpoint data.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id                                  ID of the channel to retrieve cached endpoint data of.
   * @param string $endpoint                                    Name of the endpoint to retrieve data from.
   * @param array  $filters                                     Filters associated with the data. Optional.
   * @return array|bool $channel_endpoint_data_creation_date    Cached channel endpoint data creation date, or false if no data found.
   */
  function struninntwitch_cache_channel_endpoint_data_creation_date_get($channel_id, $endpoint, $filters = false) {
    $channel_endpoint_data_creation_date = struninntwitch_cache_channel_endpoint_resource_get($channel_id, 'creation_date', $endpoint, $filters);

    return $channel_endpoint_data_creation_date;
  }
}

if (!function_exists('struninntwitch_cache_channel_data_update')) {
  /**
   * Update channel data into cache file.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id      ID of the channel to retrieve cached endpoint data of.
   * @param array $data             Data to insert into cache file.
   * @param string $endpoint        Name of the endpoint to insert data into.
   * @param array  $filters         Filters associated with the data. Optional.
   * @return int|bool $result       Number of bytes that were written to the file, or false on failure.
   */
  function struninntwitch_cache_channel_data_update($channel_id, $data, $endpoint, $filters = false) {
    $result = false;

    if ($channel_id) {
      $cached_data = struninntwitch_cache_channel_file_get();

      if (!$cached_data) {
        $cached_data = [];
      }

      $channel_id_has_data = array_key_exists($channel_id, $cached_data);

      // channel id doesn't have any data, create data structure for channel id
      if (!$channel_id_has_data) {
        $cached_data[$channel_id] = [];
      }

      $channel_id_has_endpoint = array_key_exists($endpoint, $cached_data[$channel_id]);

      // channel id doesn't have endpoint data, create data structure for channel id endpoint
      if (!$channel_id_has_endpoint) {
        $cached_data[$channel_id][$endpoint] = [];
      }

      $endpoint_data = [
        'creation_date' => (new DateTime())->format('Y-m-d H:i:s'),
        'filters'       => $filters ? $filters : [],
        'data'          => $data
      ];

      // no filters, replace no filter endpoint data, otherwise create it
      if (!$filters) {
        $filter_endpoint_data_found = false;

        for ($i = 0; $i < count($cached_data[$channel_id][$endpoint]); $i++) {
          if (count(array_keys($cached_data[$channel_id][$endpoint][$i]['filters'])) === 0) {
            $cached_data[$channel_id][$endpoint][$i] = $endpoint_data;
            $filter_endpoint_data_found = true;
            break;
          }
        }

        if (!$filter_endpoint_data_found) {
          $cached_data[$channel_id][$endpoint][] = $endpoint_data;
        }

      // if filter exists, replace data, otherwise create it
      } else {
        $filter_match_count = 0;

        for ($i = 0; $i < count($cached_data[$channel_id][$endpoint]); $i++) {
          $filter_match_count = 0;

          foreach ($filters as $filter_name => $filter_value) {
            $filter_name_exists = array_key_exists($filter_name, $cached_data[$channel_id][$endpoint][$i]['filters']);
            $filter_is_equal = $filter_name_exists && ($cached_data[$channel_id][$endpoint][$i]['filters'][$filter_name] === $filter_value);

            if ($filter_is_equal) {
              $filter_match_count++;
            } else {
              break;
            }
          }

          // if all filters match, replace data
          if ($filter_match_count === count($filters)) {
            $cached_data[$channel_id][$endpoint][$i] = $endpoint_data;
            break;
          }
        }

        // filter match was not found, create data
        if ($filter_match_count !== count($filters)) {
          $cached_data[$channel_id][$endpoint][] = $endpoint_data;
        }
      }

      $result = struninntwitch_cache_channel_file_update($cached_data);
    }

    return $result;
  }
}

if (!function_exists('struninntwitch_cache_channel_data_age_get')) {
  /**
   * Returns cached channel data age.
   * 
   * @since 1.0.0
   * 
   * @param string $channel_id                      ID of the channel to retrieve cached data age of.
   * @param string $time_unit                       Unit of time to retrieve age value. One of: 'days', 'hours', 'minutes'.
   * @param string $endpoint                        Name of the endpoint to get data age of.
   * @param array  $filters                         Filters associated with the data. Optional.
   * @return int|bool $cache_channel_data_age       Cache channel data age value in time unit, or false if no data found.
   */
  function struninntwitch_cache_channel_data_age_get($channel_id, $time_unit, $endpoint, $filters = false) {
    $cache_channel_data_age = false;

    $cache_channel_data_creation_date = struninntwitch_cache_channel_endpoint_data_creation_date_get($channel_id, $endpoint, $filters);

    if ($cache_channel_data_creation_date) {
      $cache_channel_data_creation_date_time = (new DateTime())->createFromFormat('Y-m-d H:i:s', $cache_channel_data_creation_date);

      $cache_channel_data_creation_date_time_diff = $cache_channel_data_creation_date_time->diff(new DateTime());

      switch ($time_unit) {
        case 'days':
          $cache_channel_data_age = $cache_channel_data_creation_date_time_diff->days;
          break;
        case 'hours':
          $cache_channel_data_age = ($cache_channel_data_creation_date_time_diff->days * 24) + $cache_channel_data_creation_date_time_diff->h;
          break;
        case 'minutes':
        default:
          $cache_channel_data_age = ($cache_channel_data_creation_date_time_diff->days * 24 * 60) + ($cache_channel_data_creation_date_time_diff->h * 60) + $cache_channel_data_creation_date_time_diff->i;
      }
    }

    return $cache_channel_data_age;
  }
}

if (!function_exists('struninntwitch_cache_channel_data_is_stale')) {
  /**
   * Returns wether cached channel data is stale.
   * 
   * @since 1.0.0
   * 
   * @param string  $channel_id                         ID of the channel to retrieve cached data status from.
   * @param int     $valid_age                          Cache data valid age.
   * @param string  $time_unit                          Unit of time of the age value. One of: 'days', 'hours', 'minutes', 'weekly'.
   * @param string  $endpoint                           Name of the endpoint to check cache data of.
   * @param array   $filters                            Filters associated with the data. Optional.
   * @return bool   $cache_channel_data_is_stale        True if cache data is stale, false otherwise.
   */
  function struninntwitch_cache_channel_data_is_stale($channel_id, $valid_age, $time_unit, $endpoint, $filters = false) {
    $cache_channel_data_is_stale = true;

    if ($time_unit === 'weekly') {
      $cache_channel_data_creation_date = struninntwitch_cache_channel_endpoint_data_creation_date_get($channel_id, $endpoint, $filters);

      if ($cache_channel_data_creation_date) {
        // cache channel data is stale if it was created before monday this week
        $cache_channel_data_is_stale = (new DateTime('monday this week')) > (new DateTime($cache_channel_data_creation_date));
      }
    } else {
      $cache_channel_data_age = struninntwitch_cache_channel_data_age_get($channel_id, $time_unit, $endpoint, $filters);
  
      if ($cache_channel_data_age !== false) {
        $cache_channel_data_is_stale = $cache_channel_data_age >= $valid_age;
      }
    }

    return $cache_channel_data_is_stale;
  }
}

?>