<?php
/**
 * Functions - Plugin
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_plugin_elementor_is_active')) {
  /**
   * Checks if the Elementor plugin is active.
   * 
   * @since 1.0.0
   * 
   * @return bool $plugin_is_active     True if the Elementor plugin is active, false otherwise.
   */
  function struninntwitch_plugin_elementor_is_active() {
    $plugin_is_active = class_exists('Elementor\Plugin');

    return $plugin_is_active;
  }
}

?>