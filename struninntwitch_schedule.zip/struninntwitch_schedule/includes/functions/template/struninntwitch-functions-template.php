<?php
/**
 * Functions - Template
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Filters
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/template/struninntwitch-functions-template-filters.php';

/**
 * GLobal
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/template/struninntwitch-functions-template-global.php';

?>