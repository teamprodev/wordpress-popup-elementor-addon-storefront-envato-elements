<?php
/**
 * Functions - Template - Filters
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_safe_style_css_filter')) {
  /**
   * Filters safe style css.
   * 
   * @since 1.0.0
   * 
   * @param array $attr       Array of allowed CSS attributes.
   * @return array $attr      Filtered array of allowed CSS attributes.
   */
  function struninntwitch_safe_style_css_filter($attr) {
    $color_options = struninntwitch_customizer_color_options_get();

    foreach ($color_options as $color_option_name => $color_option) {
      $attr[] = $color_option_name;
    }

    return $attr;
  }
}

add_filter('safe_style_css', 'struninntwitch_safe_style_css_filter');

?>