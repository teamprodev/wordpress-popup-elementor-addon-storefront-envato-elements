<?php
/**
 * Functions - Template - Global
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_template_channel_subscribe_button_args_default_get')) {
  /**
   * Returns channel subscribe button template default args.
   * 
   * @since 1.0.0
   * 
   * @return array $channel_subcribe_button_args_default        Default channel subscribe button template args.
   */
  function struninntwitch_template_channel_subscribe_button_args_default_get() {
    $channel_subcribe_button_args_default = [
      'additional_wrapper_classes'  => [],
      'text'                        => esc_html__('Subscribe!', 'struninntwitch_schedule'),
      'before_text'                 => '',
      'after_text'                  => '',
      'href'                        => struninntwitch_channel_subscribe_url_get(),
      'target'                      => '_blank',
      'styles'                      => false
    ];

    return $channel_subcribe_button_args_default;
  }
}

if (!function_exists('struninntwitch_template_channel_subscribe_button_get')) {
  /**
   * Returns channel subscribe button HTML.
   * 
   * @since 1.0.0
   * 
   * @param array $args {
   *   @type array  $additional_wrapper_classes     Additional classes for the wrapper.
   *   @type string $text                           Button text.
   *   @type string $before_text                    Content to insert before text.
   *   @type string $after_text                     Content to insert after text.
   *   @type string $href                           Button link URL.
   *   @type string $target                         Button target.
   *   @type string $styles                         Additional inline styles for the wrapper. Default: false.
   * }
   * @return string $template       Channel subscribe button HTML.
   */
  function struninntwitch_template_channel_subscribe_button_get($args = []) {
    $defaults = struninntwitch_template_channel_subscribe_button_args_default_get();

    $options = array_merge($defaults, $args);

    /**
     * Filters template additional wrapper classes.
     * 
     * @since 1.0.0
     * 
     * @param array $additional_wrapper_classes
    */
    $additional_wrapper_classes = apply_filters('struninntwitch_template_channel_subscribe_button_additional_wrapper_classes', $options['additional_wrapper_classes']);
    $additional_wrapper_classes = implode(' ', $additional_wrapper_classes);

    $channel_subscribe_button_text = $options['text'];

    if ($options['before_text']) {
      $channel_subscribe_button_text = $options['before_text'] . $channel_subscribe_button_text;
    }

    if ($options['after_text']) {
      $channel_subscribe_button_text .= $options['after_text'];
    }

    /**
     * Filters channel subscribe button text allowed HTML.
     * 
     * @since 1.0.0
     * 
     * @param array $channel_subscribe_button_text_allowed_html
     */
    $channel_subscribe_button_text_allowed_html = apply_filters('struninntwitch_channel_subscribe_button_text_allowed_html', []);

    ob_start();

  ?>
    <!-- STRUNINNTWITCH BUTTON -->
    <a  class="struninntwitch-button struninntwitch-button_subscribe <?php echo esc_attr($additional_wrapper_classes); ?>"
        href="<?php echo esc_url($options['href']); ?>"
        target="<?php echo esc_attr($options['target']); ?>"
        style="<?php echo esc_attr($options['styles']); ?>"
    >
    <?php
    
      echo wp_kses($channel_subscribe_button_text, $channel_subscribe_button_text_allowed_html);

    ?>
    </a>
    <!-- /STRUNINNTWITCH BUTTON -->
  <?php

    $template = ob_get_clean();

    return $template;
  }
}

if (!function_exists('struninntwitch_template_channel_subscribe_button')) {
  /**
   * Displays channel subscribe button HTML.
   * 
   * @since 1.0.0
   * 
   * @param array $args {
   *   @type array  $additional_wrapper_classes     Additional classes for the wrapper.
   *   @type string $text                           Button text.
   *   @type string $before_text                    Content to insert before text.
   *   @type string $after_text                     Content to insert after text.
   *   @type string $href                           Button link URL.
   *   @type string $target                         Button target.
   *   @type string $styles                         Additional inline styles for the wrapper. Default: false.
   * }
   */
  function struninntwitch_template_channel_subscribe_button($args = []) {
    $channel_subscribe_button = struninntwitch_template_channel_subscribe_button_get($args);

    $channel_subscribe_button_text_allowed_html = apply_filters('struninntwitch_channel_subscribe_button_text_allowed_html', []);

    $channel_subscribe_button_allowed_html = [
      'a' => [
        'class'   => [],
        'href'    => [],
        'target'  => [],
        'style'   => []
      ]
    ];

    $channel_subscribe_button_allowed_html = array_merge($channel_subscribe_button_allowed_html, $channel_subscribe_button_text_allowed_html);
    
    echo wp_kses($channel_subscribe_button, $channel_subscribe_button_allowed_html);
  }
}

if (!function_exists('struninntwitch_template_channel_schedule_args_default_get')) {
  /**
   * Returns channel schedule template default args.
   * 
   * @since 1.0.0
   * 
   * @return array $channel_schedule_args_default        Default channel schedule template args.
   */
  function struninntwitch_template_channel_schedule_args_default_get() {
    $channel_schedule_args_default = [
      'additional_wrapper_classes'  => [],
      'template'                    => 'table',
      'hide_more_button'            => false,
      'styles'                      => false
    ];

    return $channel_schedule_args_default;
  }
}

if (!function_exists('struninntwitch_template_channel_schedule_get')) {
  /**
   * Returns channel schedule HTML.
   * 
   * @since 1.0.0
   * 
   * @param array $args {
   *   @type array  $additional_wrapper_classes     Additional classes for the wrapper.
   *   @type string $template                       Schedule template to return, one of: 'table', 'grid', 'album'. Default: 'table'.
   *   @type string $hide_more_button               True to hide more button, false otherwise. Default: false.
   *   @type string $styles                         Additional inline styles for the wrapper. Default: false.
   * }
   * @return string $template                       Channel schedule HTML.
   */
  function struninntwitch_template_channel_schedule_get($args = []) {
    $defaults = struninntwitch_template_channel_schedule_args_default_get();

    $options = array_merge($defaults, $args);

    /**
     * Filters template wrapper additional classes.
     * 
     * @since 1.0.0
     * 
     * @param array $additional_wrapper_classes
    */
    $additional_wrapper_classes = apply_filters('struninntwitch_template_channel_schedule_additional_wrapper_classes', $options['additional_wrapper_classes']);
    $additional_wrapper_classes = implode(' ', $additional_wrapper_classes);

    ob_start();

  ?>
    <!-- STRUNINN SCHEDULE -->
    <div  class="struninntwitch-schedule <?php echo esc_attr($additional_wrapper_classes); ?>"
          data-template="<?php echo esc_attr($options['template']); ?>"
          data-hide-more-button="<?php echo esc_attr($options['hide_more_button']); ?>"
          style="<?php echo esc_attr($options['styles']); ?>"
    >
    </div>
    <!-- /STRUNINN SCHEDULE -->
  <?php

    $template = ob_get_clean();

    return $template;
  }
}

if (!function_exists('struninntwitch_template_channel_schedule')) {
  /**
   * Displays channel schedule HTML.
   * 
   * @since 1.0.0
   * 
   * @param array $args {
   *   @type array  $additional_wrapper_classes     Additional classes for the wrapper.
   *   @type string $template                       Schedule template to return, one of: 'table', 'grid', 'album'. Default: 'table'.
   *   @type string $hide_more_button               True to hide more button, false otherwise. Default: false.
   *   @type string $styles                         Additional inline styles for the wrapper. Default: false.
   * }
   */
  function struninntwitch_template_channel_schedule($args = []) {
    $channel_schedule = struninntwitch_template_channel_schedule_get($args);

    $channel_schedule_allowed_html = [
      'div' => [
        'class'                 => [],
        'data-template'         => [],
        'data-hide-more-button' => [],
        'style'                 => []
      ]
    ];
    
    echo wp_kses($channel_schedule, $channel_schedule_allowed_html);
  }
}

?>