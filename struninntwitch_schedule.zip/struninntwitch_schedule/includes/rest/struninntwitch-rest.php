<?php
/**
 * REST
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_schedule_rest_routes_register')) {
  /**
   * Register REST routes.
   * 
   * @since 1.0.0
   */
  function struninntwitch_schedule_rest_routes_register() {
    register_rest_route('struninntwitch/v1', '/schedule', [
      'methods'   => 'GET',
      'callback'  => function () {
        return struninntwitch_channel_schedule_get();
      },
      'permission_callback' => '__return_true'
    ]);
  }
}

add_action('rest_api_init', 'struninntwitch_schedule_rest_routes_register');

?>