<?php
/**
 * Customizer - Panel
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_panel')) {
  /**
   * Creates the customizer main panel
   * 
   * @param WP_Customize_Manager $wp_customize    Customize Manager instance.
   */
  function struninntwitch_customizer_panel($wp_customize) {
    /**
     * Panel
     */
    $wp_customize->add_panel('struninntwitch_customizer', [
      'title'       => esc_html_x('Struninn for Twitch', '(Customizer) Struninn Twitch Panel - Title', 'struninntwitch_schedule'),
      'description' => esc_html_x('From here, you can customize plugin options.', '(Customizer) Struninn Twitch Panel - Description', 'struninntwitch_schedule'),
      'priority'    => 500
    ]);
  }
}

add_action('customize_register', 'struninntwitch_customizer_panel');

?>