<?php
/**
 * Customizer - Utils
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_setting_channel_id_update')) {
  /**
   * Updates Twitch channel id setting by using a channel name.
   * 
   * @since 1.0.0
   * 
   * @param object $channel_name          Twitch channel name.
   * @return bool  $channel_id_updated    True if channel id was updated, false otherwise. 
   */
  function struninntwitch_customizer_setting_channel_id_update($channel_name) {
    $channel_id = '';
    $channel_data = struninntwitch_endpoint_data_get('users', ['login' => $channel_name]);

    if (!is_wp_error($channel_data)) {
      $channel_data_has_data = array_key_exists('data', $channel_data) && is_array($channel_data['data']) && (count($channel_data['data']) > 0);
      $channel_data_has_data_id = $channel_data_has_data && is_array($channel_data['data'][0]) && array_key_exists('id', $channel_data['data'][0]);
  
      if ($channel_data_has_data_id) {
        $channel_id = $channel_data['data'][0]['id'];
      }
    }

    $channel_id_updated = update_option('struninntwitch_setting_channel_id', $channel_id);

    return $channel_id_updated;
  }
}

if (!function_exists('struninntwitch_customizer_setting_channel_id_update_on_customize_save')) {
  /**
   * Updates Twitch channel id setting when the Twitch channel name setting changes.
   * 
   * @since 1.0.0
   * 
   * @param object $channel_name_setting      Twitch channel name customizer setting.
   * @return bool  $channel_id_updated        True if channel id was updated, false otherwise. 
   */
  function struninntwitch_customizer_setting_channel_id_update_on_customize_save($channel_name_setting) {
    $channel_name = $channel_name_setting->post_value();
    
    $channel_id_updated = struninntwitch_customizer_setting_channel_id_update($channel_name);

    return $channel_id_updated;
  }
}

add_action('customize_save_struninntwitch_setting_channel_name', 'struninntwitch_customizer_setting_channel_id_update_on_customize_save');

?>