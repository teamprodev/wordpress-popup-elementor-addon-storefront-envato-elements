<?php
/**
 * Customizer - Schedule
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_schedule')) {
  /**
   * Registers customizer sections, controls and settings.
   * 
   * @since 1.0.0
   * 
   * @param WP_Customize_Manager $wp_customize    Customize Manager instance.
   */
  function struninntwitch_customizer_schedule($wp_customize) {
    /**
     * Options section
     */
    $wp_customize->add_section('struninntwitch_schedule_section', [
      'title'       => esc_html_x('Schedule', '(Customizer) Schedule Section - Title', 'struninntwitch_schedule'),
      'description' => esc_html_x('From here, you can customize schedule options.', '(Customizer) Schedule Section - Description', 'struninntwitch_schedule'),
      'priority'    => 150,
      'panel'       => 'struninntwitch_customizer'
    ]);

    /**
     * Schedule - Cache Unit
     */
    $wp_customize->add_setting('struninntwitch_setting_schedule_cache_unit', [
      'type'              => 'option',
      'capability'        => 'manage_options',
      'sanitize_callback' => 'sanitize_text_field',
      'default'           => struninntwitch_customizer_setting_value_default_get('struninntwitch_setting_schedule_cache_unit')
    ]);

    $wp_customize->add_control('struninntwitch_setting_schedule_cache_unit', [
      'label'       => esc_html_x('Schedule - Cache Unit', '(Customizer) Schedule Option - Label', 'struninntwitch_schedule'),
      'description' => sprintf(
        esc_html_x('Unit of time used to refresh cache (e.g. if unit is "Days" and age is "1", cache is refreshed once per day / 24 hours).%sData fetched from Twitch endpoints is cached to avoid making unnecessary requests and improve loading times.%s', '(Customizer) Schedule Option - Description', 'struninntwitch_schedule'),
        '<br><br><strong>',
        '</strong>'
      ),
      'type'        => 'radio',
      'choices'     => [
        'weekly'  => esc_html__('Weekly', 'struninntwitch_schedule'),
        'days'    => esc_html__('Days', 'struninntwitch_schedule'),
        'hours'   => esc_html__('Hours', 'struninntwitch_schedule'),
        'minutes' => esc_html__('Minutes', 'struninntwitch_schedule')
      ],
      'section'     => 'struninntwitch_schedule_section'
    ]);

    /**
     * Schedule - Cache Age
     */
    $wp_customize->add_setting('struninntwitch_setting_schedule_cache_age', [
      'type'              => 'option',
      'capability'        => 'manage_options',
      'sanitize_callback' => 'absint',
      'default'           => struninntwitch_customizer_setting_value_default_get('struninntwitch_setting_schedule_cache_age')
    ]);

    $wp_customize->add_control('struninntwitch_setting_schedule_cache_age', [
      'label'       => esc_html_x('Schedule - Cache Age', '(Customizer) Schedule Option - Label', 'struninntwitch_schedule'),
      'description' => sprintf(
        esc_html_x('Amount of time used to refresh cache (e.g. if unit is "Days" and age is "1", cache is refreshed once per day / 24 hours).%sIf "Weekly" unit is selected in the option above, this option has no effect (cache will refresh on Mondays).%sData fetched from Twitch endpoints is cached to avoid making unnecessary requests and improve loading times.%s', '(Customizer) Schedule Option - Description', 'struninntwitch_schedule'),
        '<br><br>',
        '<br><br><strong>',
        '</strong>'
      ),
      'type'        => 'number',
      'input_attrs' => [
        'min'   => 1,
        'step'  => 1
      ],
      'section'     => 'struninntwitch_schedule_section'
    ]);
  }
}

add_action('customize_register', 'struninntwitch_customizer_schedule');

?>