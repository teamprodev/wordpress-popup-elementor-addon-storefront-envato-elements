<?php
/**
 * Customizer
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Settings
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-settings.php';

/**
 * Utils
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-utils.php';

/**
 * Panel
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-panel.php';

/**
 * Application
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-application.php';

/**
 * Color Utils
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-color-utils.php';

/**
 * Color
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-color.php';

/**
 * Schedule
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer-schedule.php';

?>