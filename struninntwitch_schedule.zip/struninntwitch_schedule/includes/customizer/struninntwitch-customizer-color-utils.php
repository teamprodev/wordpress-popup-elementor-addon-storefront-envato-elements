<?php
/**
 * Customizer - Color Utils
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_color_options_get')) {
  /**
   * Returns color settings.
   * 
   * @since 1.0.0
   * 
   * @return array $color_settings     Color settings.
   */
  function struninntwitch_customizer_color_options_get() {
    $color_settings = [
      /**
       * Global
       */
      '--struninntwitch-global-primary-color' => [
        'label'   => esc_html_x('Global (Primary Color)', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => '#9147ff'
      ],

      /**
       * Box
       */
      '--struninntwitch-box-background-color' => [
        'label'   => esc_html_x('Box (Background)', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => 'transparent'
      ],

      /**
       * Border
       */
      '--struninntwitch-border-color' => [
        'label'   => esc_html_x('Border', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => '#d8d8d8'
      ],

      /**
       * Text
       */
      '--struninntwitch-text-primary-color' => [
        'label'   => esc_html_x('Text', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => '#1f1f23'
      ],
      '--struninntwitch-text-bold-color'    => [
        'label'   => esc_html_x('Text (Bold)', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => '#1f1f23'
      ],

      /**
       * Button
       */
      '--struninntwitch-button-color' => [
        'label'   => esc_html_x('Button (Text)', 'Color Option - Label', 'struninntwitch_schedule'),
        'type'    => 'color',
        'default' => '#ffffff'
      ]
    ];

    /**
     * Filters color settings.
     * 
     * @since 1.0.0
     * 
     * @param array   $color_settings
     */
    $color_settings = apply_filters('struninntwitch_color_settings', $color_settings);

    return $color_settings;
  }
}

if (!function_exists('struninntwitch_customizer_color_styles_get')) {
  /**
   * Returns current color style variables.
   * 
   * @since 1.0.0
   * 
   * @return string $color_styles      Current color style variables.
   */
  function struninntwitch_customizer_color_styles_get() {
    $current_color_options = struninntwitch_customizer_color_options_get();

    $custom_user_colors = get_option('struninntwitch_color', []);

    foreach ($current_color_options as $color_name => $color_data) {
      $user_entered_custom_color = array_key_exists($color_name, $custom_user_colors);

      // if user entered a color for this, use it
      if ($user_entered_custom_color) {
        $color_value = $custom_user_colors[$color_name];
      } else {
      // set color default otherwise
        $color_value = $color_data['default'];
      }
      
      $custom_user_colors[$color_name] = $color_value;
    }

    $color_styles = ':root {';

    foreach ($custom_user_colors as $color_name => $color_value) {
      $color_styles .= $color_name . ': ' . $color_value . ';';
    }

    $color_styles .= '}';

    return $color_styles;
  }
}

?>