<?php
/**
 * Customizer - Color
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_color')) {
  /**
   * Registers customizer sections, controls and settings.
   * 
   * @since 1.0.0
   * 
   * @param WP_Customize_Manager $wp_customize    Customize Manager instance.
   */
  function struninntwitch_customizer_color($wp_customize) {
    $color_options = struninntwitch_customizer_color_options_get();

    /**
     * Options section
     */
    $wp_customize->add_section('struninntwitch_color_section', [
      'title'       => esc_html_x('Colors', '(Customizer) Color Options - Title', 'struninntwitch_schedule'),
      'description' => esc_html_x('From here, you can change plugin colors.', '(Customizer) Color Options - Description', 'struninntwitch_schedule'),
      'priority'    => 100,
      'panel'       => 'struninntwitch_customizer'
    ]);

    foreach($color_options as $color_name => $color_data) {
      $color_settings_name = 'struninntwitch_color[' . $color_name . ']';

      $wp_control_data = [
        'label'       => $color_data['label'],
        'section'     => 'struninntwitch_color_section'
      ];

      if (array_key_exists('description', $color_data)) {
        $wp_control_data['description'] = $color_data['description'];
      }

      /**
       * Setting
       */
      $wp_customize->add_setting($color_settings_name, [
        'type'              => 'option',
        'capability'        => 'manage_options',
        'default'           => $color_data['default'],
        'sanitize_callback' => 'sanitize_hex_color'
      ]);

      /**
       * Control
       */
      $wp_customize->add_control(
        new WP_Customize_Color_Control(
          $wp_customize,
          $color_settings_name,
          $wp_control_data
        )
      );
    }
  }
}

add_action('customize_register', 'struninntwitch_customizer_color');