<?php
/**
 * Customizer - Options
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer')) {
  /**
   * Registers customizer sections, controls and settings.
   * 
   * @since 1.0.0
   * 
   * @param WP_Customize_Manager $wp_customize    Customize Manager instance.
   */
  function struninntwitch_customizer($wp_customize) {
    /**
     * Options section
     */
    $wp_customize->add_section('struninntwitch_application_section', [
      'title'       => esc_html_x('Twitch Application', '(Customizer) Twitch Application Section - Title', 'struninntwitch_schedule'),
      'description' => esc_html_x('From here, you can customize your Twitch channel and application information.', '(Customizer) Twitch Application Section - Description', 'struninntwitch_schedule'),
      'priority'    => 50,
      'panel'       => 'struninntwitch_customizer'
    ]);

    /**
     * Twitch - Channel Name
     */
    $wp_customize->add_setting('struninntwitch_setting_channel_name', [
      'type'              => 'option',
      'capability'        => 'manage_options',
      'sanitize_callback' => 'sanitize_text_field',
      'default'           => struninntwitch_customizer_setting_value_default_get('struninntwitch_setting_channel_name')
    ]);
  
    $wp_customize->add_control('struninntwitch_setting_channel_name', [
      'label'       => esc_html_x('Twitch - Channel Name', '(Customizer) Twitch Option - Label', 'struninntwitch_schedule'),
      'description' => sprintf(
        esc_html_x('The name of your Twitch channel: https://www.twitch.tv/%syourChannelName%s.', '(Customizer) Twitch Option - Description', 'struninntwitch_schedule'),
        '<strong>',
        '</strong>'
      ),
      'type'        => 'text',
      'section'     => 'struninntwitch_application_section'
    ]);

    /**
     * Twitch Application - Client ID
     */
    $wp_customize->add_setting('struninntwitch_setting_app_client_id', [
      'type'              => 'option',
      'capability'        => 'manage_options',
      'sanitize_callback' => 'sanitize_text_field',
      'default'           => struninntwitch_customizer_setting_value_default_get('struninntwitch_setting_app_client_id')
    ]);
  
    $wp_customize->add_control('struninntwitch_setting_app_client_id', [
      'label'       => esc_html_x('Twitch Application - Client ID', '(Customizer) Twitch Option - Label', 'struninntwitch_schedule'),
      'description' => sprintf(
        esc_html_x('The Client ID of your %sTwitch Application%s.', '(Customizer) Twitch Option - Description', 'struninntwitch_schedule'),
        '<a href="https://dev.twitch.tv/console/apps" target="_blank">',
        '</a>'
      ),
      'type'        => 'password',
      'section'     => 'struninntwitch_application_section'
    ]);

    /**
     * Twitch Application - Client Secret
     */
    $wp_customize->add_setting('struninntwitch_setting_app_client_secret', [
      'type'              => 'option',
      'capability'        => 'manage_options',
      'sanitize_callback' => 'sanitize_text_field',
      'default'           => struninntwitch_customizer_setting_value_default_get('struninntwitch_setting_app_client_secret')
    ]);
  
    $wp_customize->add_control('struninntwitch_setting_app_client_secret', [
      'label'       => esc_html_x('Twitch Application - Client Secret', '(Customizer) Twitch Option - Label', 'struninntwitch_schedule'),
      'description' => sprintf(
        esc_html_x('The Client Secret of your %sTwitch Application%s.', '(Customizer) Twitch Option - Description', 'struninntwitch_schedule'),
        '<a href="https://dev.twitch.tv/console/apps" target="_blank">',
        '</a>'
      ),
      'type'        => 'password',
      'section'     => 'struninntwitch_application_section'
    ]);
  }
}

add_action('customize_register', 'struninntwitch_customizer');