<?php
/**
 * Customizer - Settings
 * 
 * @package Struninn Twitch
 * 
 * @since 1.0.0
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

if (!function_exists('struninntwitch_customizer_setting_value_default_get')) {
  /**
   * Returns a customizer setting default value.
   * 
   * @since 1.0.0
   * 
   * @param string $setting_name              Name of the customizer setting.
   * @return mixed $setting_default_value     Default value of the customizer setting if found, null otherwise.
   */
  function struninntwitch_customizer_setting_value_default_get($setting_name) {
    $setting_default_values = [
      /**
       * Twitch Application
       */
      'struninntwitch_setting_channel_name'       => '',
      'struninntwitch_setting_app_client_id'      => '',
      'struninntwitch_setting_app_client_secret'  => '',
      'struninntwitch_setting_app_access_token'   => '',
      'struninntwitch_setting_channel_id'         => '',

      /**
       * Schedule
       */
      'struninntwitch_setting_schedule_cache_unit'  => 'weekly',
      'struninntwitch_setting_schedule_cache_age'   => 1
    ];

    /**
     * Filters setting default values.
     * 
     * @since 1.0.0
     * 
     * @param array   $setting_default_values
     * @param string  $setting_name
     */
    $setting_default_values = apply_filters('struninntwitch_settings_default_values', $setting_default_values, $setting_name);

    $setting_default_value = array_key_exists($setting_name, $setting_default_values) ? $setting_default_values[$setting_name] : null;

    return $setting_default_value;
  }
}

if (!function_exists('struninntwitch_customizer_setting_value_get')) {
  /**
   * Returns a customizer setting value.
   * 
   * @since 1.0.0
   * 
   * @param string $setting_name        Name of the customizer setting.
   * @return mixed $setting_value       Value of the customizer setting.
   */
  function struninntwitch_customizer_setting_value_get($setting_name) {
    $setting_default_value = struninntwitch_customizer_setting_value_default_get($setting_name);

    if (!is_null($setting_default_value)) {
      $setting_value = get_option($setting_name, $setting_default_value);
    } else {
      $setting_value = get_option($setting_name);
    }

    return $setting_value;
  }
}

?>