module.exports = function(grunt) {

  const sass = require('node-sass');

  grunt.initConfig({
    sass: {
      options: {
        implementation: sass,
        sourceMap: true
      },
      build: {
        options: {
          outputStyle: 'expanded'
        },
        files: {
          'css/style.css': 'sass/main.scss'
        }
      }
    },
    postcss: {
      autoprefix: {
        options: {
          processors: [
            require('autoprefixer')()
          ],
          map: {
            inline: false
          }
        },
        files: {
          'css/style.css': 'css/style.css'
        }
      }
    },
    browserify: {
      options: {
        browserifyOptions: {
          extensions: ['.js']
        },
        transform: [
          [
            'babelify',
            {
              presets: ['@babel/env', '@babel/preset-react'],
              compact: true
            }
          ]
        ]
      },
      build: {
        files: {
          'js/source/bundle/app.bundle.js': 'js/source/app.js',
          'js/source/elementor/widget/schedule/channelSchedule.bundle.js': 'js/source/elementor/widget/schedule/channelSchedule.js'
        }
      }
    },
    watch: {
      sass: {
        files: ['sass/**'],
        tasks: ['styles']
      },
      js: {
        files: ['js/**/*.js', '!js/**/*.min.js', '!js/**/*.bundle.js'],
        tasks: ['scripts']
      }
    }
  });

  // Load tasks
  grunt.loadNpmTasks('grunt-postcss');
  grunt.loadNpmTasks('grunt-sass');
  grunt.loadNpmTasks('grunt-browserify');
  grunt.loadNpmTasks('grunt-contrib-watch');

  // Register global tasks
  grunt.registerTask('default', ['styles', 'scripts', 'launch']);

  // Register custom tasks
  grunt.registerTask('styles', ['sass:build', 'postcss:autoprefix']);
  grunt.registerTask('scripts', ['browserify:build']);
  grunt.registerTask('launch', ['watch']);
};