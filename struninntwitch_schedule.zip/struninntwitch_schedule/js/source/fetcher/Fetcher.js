const Fetcher = () => {};

Fetcher.query = (method, url, config = {}) => {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();

    let openURL = url;

    if (config.params) {
      const params = [];

      for (const key in config.params) {
        params.push(`${key}=${config.params[key]}`);
      }

      openURL = `${openURL}?${params.join('&')}`;
    }

    request.open(method, openURL);

    const headerDefaults = {
      'Content-Type': 'application/json'
    };
    const headers = Object.assign(headerDefaults, config.headers || {});

    if (headers) {
      for (const header in headers) {
        request.setRequestHeader(header, headers[header]);
      }
    }

    request.onload = () => {
      if (request.status === 200) {
        if (headers['Content-Type'] === 'application/json') {
          resolve(JSON.parse(request.response));
        } else {
          resolve(request.response);
        }
      } else {
        reject(new Error(request.statusText));
      }
    };

    request.onerror = () => {
      reject(new Error('Network Error'));
    };

    request.send(config.body || null);
  });
};

Fetcher.get = (url, config) => {
  return Fetcher.query('GET', url, config);
};

Fetcher.post = (url, config) => {
  return Fetcher.query('POST', url, config);
};

export { Fetcher as default };