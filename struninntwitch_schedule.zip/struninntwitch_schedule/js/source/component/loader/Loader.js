import React from 'react';

const Loader = (props) => {
  return (
    <div className="struninntwitch-loader-wrap">
      <div className="struninntwitch-loader">
        <div className="struninntwitch-loader-content">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    </div>
  )
};

export { Loader as default };