import React from 'react';

const ErrorMessage = (props) => {
  return (
    <p className="struninntwitch-error-message"><strong>{props.data.error}</strong>: {props.data.message}</p>
  );
};

export { ErrorMessage as default };