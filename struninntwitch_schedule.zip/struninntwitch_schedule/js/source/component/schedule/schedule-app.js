import loadChannelScheduleComponent from './ScheduleDOM';

const channelScheduleElements = document.querySelectorAll('*:not(.elementor) .struninntwitch-schedule, .elementor-shortcode .struninntwitch-schedule');

loadChannelScheduleComponent(channelScheduleElements);