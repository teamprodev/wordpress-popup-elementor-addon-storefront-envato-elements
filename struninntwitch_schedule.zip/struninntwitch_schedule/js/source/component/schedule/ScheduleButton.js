import React from 'react';

const ScheduleButton = (props) => {
  return (
    <div className="struninntwitch-button-wrap">
      <a className="struninntwitch-button" href={struninntwitchScheduleConstants.channelScheduleURL} target="_blank">{struninntwitchScheduleTranslation.view_the_full_schedule}</a>
    </div>
  );
};

export { ScheduleButton as default };