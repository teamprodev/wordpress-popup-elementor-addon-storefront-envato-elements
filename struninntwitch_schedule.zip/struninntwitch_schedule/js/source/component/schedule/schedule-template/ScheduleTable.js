import React from 'react';

import { groupScheduleDataByDate } from '../schedule-utils';

const ScheduleTable = (props) => {
  const scheduleDataByDate = groupScheduleDataByDate(props.data);

  return (
    <div className="struninntwitch-schedule-tables">
    {
      Object
      .keys(scheduleDataByDate)
      .map((date) => {
        const scheduleItemDate = new Date(date);

        // set as user locale to display dates format in user locale (e.g. 'es-ES', 'en-US', etc)
        const scheduleItemDateLocale = undefined;
        // const scheduleItemDateLocale = 'es-ES';
        // const scheduleItemDateLocale = 'ko-KR';
        // const scheduleItemDateLocale = 'ar-EG';
        // const scheduleItemDateLocale = 'de-DE';

        const scheduleItemDayName = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {weekday: 'short'});
        const scheduleItemDayMonthNumber = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {day: '2-digit', month: '2-digit'});
        const scheduleItemDayFull = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {weekday: 'long', month: 'long', day: '2-digit', year: 'numeric'});

        return (
          <table className="struninntwitch-schedule-table" key={date}>
            <tbody>
            {
              scheduleDataByDate[date].map((scheduleItem, i) => {
                const scheduleItemStartTime = new Date(scheduleItem.start_time);
                const scheduleItemEndTime = new Date(scheduleItem.end_time);

                const scheduleItemStartTimeString = scheduleItemStartTime.toLocaleTimeString(scheduleItemDateLocale, {hour: '2-digit', minute: '2-digit'});
                const scheduleItemEndTimeString = scheduleItemEndTime.toLocaleTimeString(scheduleItemDateLocale, {hour: '2-digit', minute: '2-digit'});
                const timezoneOffset = scheduleItemStartTime.getTimezoneOffset() / 60;
                const timezoneOffsetString = timezoneOffset > 0 ? `GMT-${timezoneOffset}` : `GMT+${timezoneOffset}`;

                const scheduleItemTitle = scheduleItem.title !== '' ? scheduleItem.title : '-';
                const scheduleItemCategoryName = scheduleItem.category ? scheduleItem.category.name : '-';

                const scheduleItemCategoryBoxArtURL = scheduleItem.category ? scheduleItem.category.box_art_url : false;
                const scheduleItemCategoryBoxArtURLSized = scheduleItemCategoryBoxArtURL ? scheduleItemCategoryBoxArtURL.replace('{width}x{height}', '44x59') : false;

                return (
                  <tr key={scheduleItem.id}>
                    <td>
                    {
                      (i === 0) &&
                        <React.Fragment>
                          <p className="struninntwitch-schedule-table-day"><strong>{scheduleItemDayName}</strong> {scheduleItemDayMonthNumber}</p>
                          <p className="struninntwitch-schedule-table-date">{scheduleItemDayFull}</p>
                        </React.Fragment>
                    }
                    </td>

                    <td>
                      <p className="struninntwitch-schedule-table-time">{scheduleItemStartTimeString} - {scheduleItemEndTimeString}</p>
                      <p className="struninntwitch-schedule-table-timezone">{timezoneOffsetString}</p>
                    </td>

                    <td>
                      <p className="struninntwitch-schedule-table-title">{scheduleItemTitle}</p>
                      <p className="struninntwitch-schedule-table-subtitle">{scheduleItemCategoryName}</p>
                    </td>

                    <td>
                    {
                      scheduleItemCategoryBoxArtURLSized &&
                        <img src={scheduleItemCategoryBoxArtURLSized} alt={scheduleItemCategoryName}></img>
                    }
                    {
                      !scheduleItemCategoryBoxArtURLSized &&
                        <div className="struninntwitch-schedule-stream-image"></div>
                    }
                    </td>
                  </tr>
                );
              })
            }
            </tbody>
          </table>
        );
      })
    }
    </div>
  );
};

export { ScheduleTable as default };