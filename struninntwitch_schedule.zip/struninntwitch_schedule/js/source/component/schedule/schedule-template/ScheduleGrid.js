import React from 'react';

import { groupScheduleDataByDate } from '../schedule-utils';

const ScheduleGrid = (props) => {
  const scheduleDataByDate = groupScheduleDataByDate(props.data);

  return (
    <div className="struninntwitch-schedule-grid">
    {
      Object
      .keys(scheduleDataByDate)
      .map((date) => {
        const scheduleItemDate = new Date(date);

        // set as user locale to display dates format in user locale (e.g. 'es-ES', 'en-US', etc)
        const scheduleItemDateLocale = undefined;
        // const scheduleItemDateLocale = 'es-ES';
        // const scheduleItemDateLocale = 'ko-KR';
        // const scheduleItemDateLocale = 'ar-EG';
        // const scheduleItemDateLocale = 'de-DE';

        const scheduleItemDayName = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {weekday: 'short'});
        const scheduleItemDayNumber = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {day: '2-digit'});
        const scheduleItemMonthName = scheduleItemDate.toLocaleDateString(scheduleItemDateLocale, {month: 'short'});

        return (
          <div className="struninntwitch-schedule-segment" key={date}>
            <div className="struninntwitch-schedule-segment-date">
              <p className="struninntwitch-schedule-segment-day-name">{scheduleItemDayName}</p>
              <p className="struninntwitch-schedule-segment-day-number">{scheduleItemDayNumber}</p>
              <p className="struninntwitch-schedule-segment-month-name">{scheduleItemMonthName}</p>
            </div>

            <div className="struninntwitch-schedule-segment-items">
            {
              scheduleDataByDate[date].map((scheduleItem) => {
                const scheduleItemStartTime = new Date(scheduleItem.start_time);
                const scheduleItemEndTime = new Date(scheduleItem.end_time);

                const scheduleItemStartTimeString = scheduleItemStartTime.toLocaleTimeString(scheduleItemDateLocale, {hour: '2-digit', minute: '2-digit'});
                const scheduleItemEndTimeString = scheduleItemEndTime.toLocaleTimeString(scheduleItemDateLocale, {hour: '2-digit', minute: '2-digit'});
                const timezoneOffset = scheduleItemStartTime.getTimezoneOffset() / 60;
                const timezoneOffsetString = timezoneOffset > 0 ? `GMT-${timezoneOffset}` : `GMT+${timezoneOffset}`;

                const scheduleItemTitle = scheduleItem.title !== '' ? scheduleItem.title : '-';
                const scheduleItemCategoryName = scheduleItem.category ? scheduleItem.category.name : '-';

                const scheduleItemCategoryBoxArtURL = scheduleItem.category ? scheduleItem.category.box_art_url : false;
                const scheduleItemCategoryBoxArtURLSized = scheduleItemCategoryBoxArtURL ? scheduleItemCategoryBoxArtURL.replace('{width}x{height}', '44x59') : false;
                  
                return (
                  <div className="struninntwitch-schedule-segment-item" key={scheduleItem.id}>
                    <div className="struninntwitch-schedule-segment-image">
                    {
                      scheduleItemCategoryBoxArtURLSized &&
                        <img src={scheduleItemCategoryBoxArtURLSized} alt={scheduleItemCategoryName}></img>
                    }
                    {
                      !scheduleItemCategoryBoxArtURLSized &&
                        <div className="struninntwitch-schedule-stream-image"></div>
                    }
                    </div>
                    
                    <div className="struninntwitch-schedule-segment-info">
                      <p className="struninntwitch-schedule-segment-title">{scheduleItemTitle}</p>
                      <p className="struninntwitch-schedule-segment-subtitle">{scheduleItemCategoryName}</p>
                      <p className="struninntwitch-schedule-segment-time"><strong>{scheduleItemStartTimeString} - {scheduleItemEndTimeString}</strong> {timezoneOffsetString}</p>
                    </div>
                  </div>
                );
              })
            }
            </div>
          </div>
        )
      })
    }
    </div>
  );
};

export { ScheduleGrid as default };