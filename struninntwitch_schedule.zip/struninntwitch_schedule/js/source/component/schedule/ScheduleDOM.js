import React from 'react';
import ReactDOM from 'react-dom';

import Schedule from './Schedule';

const loadChannelScheduleComponent = (channelScheduleElements) => {
  if (channelScheduleElements.length) {
    for (const channelScheduleElement of channelScheduleElements) {
      const channelScheduleTemplate = channelScheduleElement.getAttribute('data-template') || false;
      const hideMoreButton = Boolean(channelScheduleElement.getAttribute('data-hide-more-button'));

      ReactDOM.render(
        <Schedule
          template={channelScheduleTemplate}
          hideMoreButton={hideMoreButton}
        />,
        channelScheduleElement
      );
    }
  }
};

export { loadChannelScheduleComponent as default };