import ScheduleTable from './schedule-template/ScheduleTable';
import ScheduleGrid from './schedule-template/ScheduleGrid';
import ScheduleAlbum from './schedule-template/ScheduleAlbum';

const getScheduleTemplate = (template = 'table', onMobile = false) => {
  if (onMobile) {
    return ScheduleAlbum;
  }

  switch (template) {
    case 'grid':
      return ScheduleGrid;
    case 'album':
      return ScheduleAlbum;
    default:
      return ScheduleTable;
  }
};

const groupScheduleDataByDate = (scheduleData) => {
  const groupedData = {};

  const dateSeparator = '/';

  for (const scheduleItem of scheduleData) {
    const scheduleItemDate = new Date(scheduleItem.start_time);
    const scheduleItemDateKey = `${scheduleItemDate.getMonth() + 1}${dateSeparator}${scheduleItemDate.getDate()}${dateSeparator}${scheduleItemDate.getFullYear()}`;

    if (!groupedData[scheduleItemDateKey]) {
      groupedData[scheduleItemDateKey] = [];
    }

    groupedData[scheduleItemDateKey].push(scheduleItem);
  }

  return groupedData;
};

export {
  getScheduleTemplate,
  groupScheduleDataByDate
};