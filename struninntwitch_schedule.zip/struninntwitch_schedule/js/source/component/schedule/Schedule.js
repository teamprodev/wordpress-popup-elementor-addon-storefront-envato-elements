import React, { useState, useEffect } from 'react';

import ScheduleButton from './ScheduleButton';

import ErrorMessage from '../error/ErrorMessage';

import Loader from '../loader/Loader';

import twitchEndpointDataGet from '../../endpoint/endpoint';

import { getScheduleTemplate } from './schedule-utils';

const Schedule = (props) => {
  const [scheduleData, setScheduleData] = useState(false);
  const [loadingScheduleData, setLoadingScheduleData] = useState(false);
  const [errorData, setErrorData] = useState({});

  const [onMobile, setOnMobile] = useState(false);

  const getScheduleData = () => {
    const scheduleData = twitchEndpointDataGet('schedule');

    setLoadingScheduleData(true);

    scheduleData
    .then((response) => {
      // console.log('Schedule - getScheduleData - response: ', response);

      if (response.message) {
        setErrorData(response);
      } else {
        setScheduleData(response);
      }
    })
    .catch((error) => {
      // console.error('Schedule - getScheduleData - error: ', error);
    })
    .finally(() => {
      setLoadingScheduleData(false);
    });
  };

  const getOnMobile = () => {
    if (window.innerWidth <= 1024) {
      setOnMobile(true);
    } else {
      setOnMobile(false);
    }
  };

  useEffect(() => {
    getScheduleData();
  }, []);

  useEffect(() => {
    getOnMobile();

    window.addEventListener('resize', getOnMobile);

    return () => {
      window.removeEventListener('resize', getOnMobile);
    };
  });

  const template = props.template || 'table';
  const ScheduleTemplate = getScheduleTemplate(template, onMobile);

  return (
    <React.Fragment>
    {
      loadingScheduleData &&
        <Loader />
    }
    {
      !loadingScheduleData &&
        <React.Fragment>
        {
          scheduleData &&
            <React.Fragment>
              <ScheduleTemplate data={scheduleData} />
              
              {
                !props.hideMoreButton &&
                  <ScheduleButton />
              }
            </React.Fragment>
        }
        {
          !scheduleData &&
            <ErrorMessage data={errorData} />
        }
        </React.Fragment>
    }
    </React.Fragment>
  );
};

export { Schedule as default };