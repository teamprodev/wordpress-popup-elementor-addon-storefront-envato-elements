import loadChannelScheduleComponent from '../../../component/schedule/ScheduleDOM';

class StruninnTwitch_Elementor_Handler_Channel_Schedule extends elementorModules.frontend.handlers.Base {
  getDefaultElements() {
    const channelScheduleElement = this.$element[0].querySelector('.struninntwitch-schedule');

    if (channelScheduleElement) {
      loadChannelScheduleComponent([channelScheduleElement]);
    }

    return {
      channelSchedule: channelScheduleElement
    };
  }
}

window.addEventListener('elementor/frontend/init', () => {
  const addHandler = ($element) => {
    elementorFrontend.elementsHandler.addHandler(StruninnTwitch_Elementor_Handler_Channel_Schedule, {$element});
  };

  elementorFrontend.hooks.addAction('frontend/element_ready/struninntwitch_elementor_widget_channel_schedule.default', addHandler);
});