import Fetcher from '../fetcher/Fetcher';

const twitchEndpointURLGet = (endpoint) => {
  return `${struninntwitchScheduleConstants.restURL}${endpoint}`;
};

const twitchEndpointDataGet = (endpoint) => {
  const endpointURL = twitchEndpointURLGet(endpoint);

  return Fetcher.get(endpointURL);
};

export { twitchEndpointDataGet as default };