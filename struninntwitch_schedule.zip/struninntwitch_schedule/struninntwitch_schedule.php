<?php
/**
 * Plugin Name: Struninn - Schedule for Twitch
 * Plugin URI: https://odindesignthemes.com/
 * Description: Schedule and subscribe button widgets for Twitch.
 * Version: 1.0.1
 * Author: Odin Design Themes
 * Author URI: https://themeforest.net/user/odin_design
 * License: https://themeforest.net/licenses/
 * License URI: https://themeforest.net/licenses/
 * Text Domain: struninntwitch_schedule
 * Domain Path: /languages
 */

/**
 * Paths and urls
 * 
 * @since 1.0.0
 */
if (!defined('STRUNINNTWITCH_SCHEDULE_PATH')) {
  define('STRUNINNTWITCH_SCHEDULE_PATH', plugin_dir_path(__FILE__));
}

if (!defined('STRUNINNTWITCH_SCHEDULE_URL')) {
  define('STRUNINNTWITCH_SCHEDULE_URL', plugin_dir_url(__FILE__));
}

if (!function_exists('struninntwitch_schedule_scripts_load')) {
  /**
   * Load plugin styles and scripts.
   * 
   * @since 1.0.0
   */
  function struninntwitch_schedule_scripts_load() {
    /**
     * Styles
     */

    // Main
    wp_enqueue_style('struninntwitch_schedule-styles', STRUNINNTWITCH_SCHEDULE_URL . 'css/style.css', [], '1.0.0');

    // Load current color CSS variables
    $color_styles = struninntwitch_customizer_color_styles_get();

    // add user custom theme colors
    wp_add_inline_style('struninntwitch_schedule-styles', $color_styles);

    /**
     * Scripts
     */

     // Main
     wp_enqueue_script('struninntwitch_schedule-script', STRUNINNTWITCH_SCHEDULE_URL . 'js/app.bundle.min.js', [], '1.0.1', true);
     // Translation
     wp_localize_script('struninntwitch_schedule-script', 'struninntwitchScheduleTranslation', struninntwitch_schedule_translation_get());
     // Variables
     wp_add_inline_script('struninntwitch_schedule-script', struninntwitch_schedule_constants_get(), 'before');
  }
}

add_action('wp_enqueue_scripts', 'struninntwitch_schedule_scripts_load');

if (!function_exists('struninntwitch_schedule_translations_load')) {
  /**
   * Load translations.
   * 
   * @since 1.0.0
   */
  function struninntwitch_schedule_translations_load() {
    load_plugin_textdomain('struninntwitch_schedule', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }
}

add_action('init', 'struninntwitch_schedule_translations_load');

/**
 * Load customizer options
 * 
 * @since 1.0.0
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/customizer/struninntwitch-customizer.php';

/**
 * Load functions
 * 
 * @since 1.0.0
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/functions/struninntwitch-functions.php';

/**
 * Load REST custom endpoints
 * 
 * @since 1.0.0
 */
require_once STRUNINNTWITCH_SCHEDULE_PATH . 'includes/rest/struninntwitch-rest.php';

?>