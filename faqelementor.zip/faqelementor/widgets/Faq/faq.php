<?php
namespace ElementorFaq\Widgets;

use \Elementor\Controls_Manager as Controls_Manager;
use \Elementor\Frontend;
use \Elementor\Group_Control_Border as Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow as Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography as Group_Control_Typography;
use \Elementor\Utils as Utils;
use \Elementor\Widget_Base as Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Faq
 *
 * Elementor widget for team vision
 *
 * @since 1.0.0
 */
class Faq extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'adte-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Faq', 'faqelementor' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-help-o';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'faqelementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Faq', 'faqelementor' ),
			]
		);

		$this->add_control(
			'open_faqs',
			[
				'label' => esc_html__( 'Open FAQ By Default', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'		=> esc_html__( 'Default', 'faqelementor' ),
					'open_all' 		=> esc_html__( 'Open All', 'faqelementor' ),					
					'close_all' 	=> esc_html__( 'Close All', 'faqelementor' )					
				]
			]
		);

		$this->add_control(
			'faqs',
			[
				'label' => esc_html__( 'FAQ', 'faqelementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'faqelementor' ),
						'type' => Controls_Manager::TEXT,
						'default' => esc_html__( 'Title FAQ' , 'faqelementor' ),
						'label_block' => true,
					],
					[
						'name' => 'text',
						'label' => esc_html__( 'Text', 'faqelementor' ),
						'type' =>  \Elementor\Controls_Manager::WYSIWYG,
						'default' => '',
						'placeholder' => esc_html__( 'Your Faq Text', 'faqelementor' )
					]					
				],
				'title_field' => '{{{ title }}}',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_animation',
			[
				'label' => esc_html__( 'Animations', 'faqelementor' )
			]
		);
		
		$this->add_control(
			'addon_animate',
			[
				'label' => esc_html__( 'Animate', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'off',
				'options' => [
					'off'	=> 'Off',
					'on' 	=> 'On'					
				]
			]
		);		

		$this->add_control(
			'effect',
			[
				'label' => esc_html__( 'Animate Effects', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'fade-in',
				'options' => [
							'fade-in'			=> esc_html__( 'Fade In', 'faqelementor' ),
							'fade-in-up' 		=> esc_html__( 'fade in up', 'faqelementor' ),					
							'fade-in-down' 		=> esc_html__( 'fade in down', 'faqelementor' ),					
							'fade-in-left' 		=> esc_html__( 'fade in Left', 'faqelementor' ),					
							'fade-in-right' 	=> esc_html__( 'fade in Right', 'faqelementor' ),					
							'fade-out'			=> esc_html__( 'Fade In', 'faqelementor' ),
							'fade-out-up' 		=> esc_html__( 'Fade Out up', 'faqelementor' ),					
							'fade-out-down' 	=> esc_html__( 'Fade Out down', 'faqelementor' ),					
							'fade-out-left' 	=> esc_html__( 'Fade Out Left', 'faqelementor' ),					
							'fade-out-right' 	=> esc_html__( 'Fade Out Right', 'faqelementor' ),
							'bounce-in'			=> esc_html__( 'Bounce In', 'faqelementor' ),
							'bounce-in-up' 		=> esc_html__( 'Bounce in up', 'faqelementor' ),					
							'bounce-in-down' 	=> esc_html__( 'Bounce in down', 'faqelementor' ),					
							'bounce-in-left' 	=> esc_html__( 'Bounce in Left', 'faqelementor' ),					
							'bounce-in-right' 	=> esc_html__( 'Bounce in Right', 'faqelementor' ),					
							'bounce-out'		=> esc_html__( 'Bounce In', 'faqelementor' ),
							'bounce-out-up' 	=> esc_html__( 'Bounce Out up', 'faqelementor' ),					
							'bounce-out-down' 	=> esc_html__( 'Bounce Out down', 'faqelementor' ),					
							'bounce-out-left' 	=> esc_html__( 'Bounce Out Left', 'faqelementor' ),					
							'bounce-out-right' 	=> esc_html__( 'Bounce Out Right', 'faqelementor' ),	
							'zoom-in'			=> esc_html__( 'Zoom In', 'faqelementor' ),
							'zoom-in-up' 		=> esc_html__( 'Zoom in up', 'faqelementor' ),					
							'zoom-in-down' 		=> esc_html__( 'Zoom in down', 'faqelementor' ),					
							'zoom-in-left' 		=> esc_html__( 'Zoom in Left', 'faqelementor' ),					
							'zoom-in-right' 	=> esc_html__( 'Zoom in Right', 'faqelementor' ),					
							'zoom-out'			=> esc_html__( 'Zoom In', 'faqelementor' ),
							'zoom-out-up' 		=> esc_html__( 'Zoom Out up', 'faqelementor' ),					
							'zoom-out-down' 	=> esc_html__( 'Zoom Out down', 'faqelementor' ),					
							'zoom-out-left' 	=> esc_html__( 'Zoom Out Left', 'faqelementor' ),					
							'zoom-out-right' 	=> esc_html__( 'Zoom Out Right', 'faqelementor' ),
							'flash' 			=> esc_html__( 'Flash', 'faqelementor' ),
							'strobe'			=> esc_html__( 'Strobe', 'faqelementor' ),
							'shake-x'			=> esc_html__( 'Shake X', 'faqelementor' ),
							'shake-y'			=> esc_html__( 'Shake Y', 'faqelementor' ),
							'bounce' 			=> esc_html__( 'Bounce', 'faqelementor' ),
							'tada'				=> esc_html__( 'Tada', 'faqelementor' ),
							'rubber-band'		=> esc_html__( 'Rubber Band', 'faqelementor' ),
							'swing' 			=> esc_html__( 'Swing', 'faqelementor' ),
							'spin'				=> esc_html__( 'Spin', 'faqelementor' ),
							'spin-reverse'		=> esc_html__( 'Spin Reverse', 'faqelementor' ),
							'slingshot'			=> esc_html__( 'Slingshot', 'faqelementor' ),
							'slingshot-reverse'	=> esc_html__( 'Slingshot Reverse', 'faqelementor' ),
							'wobble'			=> esc_html__( 'Wobble', 'faqelementor' ),
							'pulse' 			=> esc_html__( 'Pulse', 'faqelementor' ),
							'pulsate'			=> esc_html__( 'Pulsate', 'faqelementor' ),
							'heartbeat'			=> esc_html__( 'Heartbeat', 'faqelementor' ),
							'panic' 			=> esc_html__( 'Panic', 'faqelementor' )				
				],
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);			

		$this->add_control(
			'delay',
			[
				'label' => esc_html__( 'Animate Delay (ms)', 'faqelementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => '1000',
				'condition'	=> [
					'addon_animate'	=> 'on'
				]
			]
		);	
		
		$this->end_controls_section();


		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style', 'faqelementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'header_icon',
			[
				'label' => esc_html__( 'Header Icon', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
						'value' => 'fas fa-plus',
						'library' => 'solid',
				]
			]
		);

		$this->add_control(
			'header_active_icon',
			[
				'label' => esc_html__( 'Header Active Icon', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
						'value' => 'fas fa-minus',
						'library' => 'solid',
				]
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'	=> esc_html__( 'Style 1', 'faqelementor' ),
					'style2' 	=> esc_html__( 'Style 2', 'faqelementor' ),				
					'style3' 	=> esc_html__( 'Style 3', 'faqelementor' )			
				]
			]
		);

		$this->add_control(
			'active_color',
			[
				'label' => esc_html__( 'Active Background Color', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#003eff'
			]
		);

		$this->add_control(
			'title_active_text_color',
			[
				'label' => esc_html__( 'Title Active Text Color', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FFFFFF'
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FFFFFF'
			]
		);

		$this->add_control(
			'default_color',
			[
				'label' => esc_html__( 'Default Color', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#003eff'
			]
		);

		$this->add_control(
			'default_text_color',
			[
				'label' => esc_html__( 'Default Text Color', 'faqelementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FFFFFF'
			]
		);

		$this->add_control(
			'font_size_title',
			[
				'label' => esc_html__( 'Title Font Size', 'faqelementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => '15px'
			]
		);	

		$this->add_control(
			'font_size_text',
			[
				'label' => esc_html__( 'Content Font Size', 'faqelementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => '12px'
			]
		);	

		$this->add_control(
			'border',
			[
				'label' => esc_html__( 'Border Type', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'square',
				'options' => [
					'square'	=> esc_html__( 'Square', 'faqelementor' ),
					'rounded' 	=> esc_html__( 'Rounded', 'faqelementor' )			
				]
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Rounded (px)', 'faqelementor' ),
				'type' => Controls_Manager::TEXT,
				'default' => '5px',
				'condition'	=> [
					'border'	=> 'rounded'
				]
			]
		);

		$this->add_control(
			'rtl',
			[
				'label' => esc_html__( 'RTL', 'faqelementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'ltr',
				'options' => [
					'ltr'	=> esc_html__( 'LTR', 'faqelementor' ),
					'rtl' 		=> esc_html__( 'RTL', 'faqelementor' )			
				]
			]
		);

		$this->end_controls_section();
		
	}

	 
	 /**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		static $instance = 0;
		$instance++;		
		$settings = $this->get_settings_for_display();
		
        $open_faqs					= esc_html($settings['open_faqs']);
        $style						= esc_html($settings['style']);
        $active_color				= esc_html($settings['active_color']);
		$title_active_text_color	= esc_html($settings['title_active_text_color']);
		$default_color				= esc_html($settings['default_color']);
		$default_text_color			= esc_html($settings['default_text_color']);
		$background_color			= esc_html($settings['background_color']);		
		$font_size_title			= esc_html($settings['font_size_title']);		
		$font_size_text				= esc_html($settings['font_size_text']);		
		$border						= esc_html($settings['border']);		
		$border_radius				= esc_html($settings['border_radius']);		
		$rtl						= esc_html($settings['rtl']);		
		
		// Animations
		$addon_animate				= esc_html($settings['addon_animate']);
		$effect						= esc_html($settings['effect']);
		$delay						= esc_html($settings['delay']);
		
		wp_enqueue_script( 'faq' );		
		wp_enqueue_script( 'appear' );			
		wp_enqueue_script( 'animate' );
		wp_enqueue_script( 'jquery-ui-core');
		wp_enqueue_script( 'jquery-ui-accordion' );
		wp_enqueue_style( 'animations' );
		wp_enqueue_style('jquery-ui.min');
		wp_enqueue_style('jquery-ui.theme.min');
		wp_enqueue_style( 'elementor-icons' );
		wp_enqueue_style( 'font-awesome' );
		wp_enqueue_style( 'elementor-editor' );
		wp_enqueue_style( 'elementor-icons' );	
		
		echo '<script type=\'text/javascript\'>
						jQuery(document).ready(function($){
							var icons = {
							  header: "'.$settings['header_icon']['value'].'",
							  activeHeader: "'.$settings['header_active_icon']['value'].'"
							};							
								$(\'#adte-faq-'.esc_html($instance).'\').accordion({
									icons: icons,
									collapsible: true,
									heightStyle: "content"';
									if($open_faqs == 'close_all') {	
										echo ',active: false';							
									}	
						echo	'});
								';
								if($open_faqs == 'open_all') {	
									echo '$(\'#adte-faq-'.esc_html($instance).' .ui-accordion-content\').show()';							
								}		
						echo '});	
				</script>';
			echo '<style type="text/css">';
			
			if($style == 'style1') {
				echo '.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-widget-content .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-widget-header .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-button, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:hover, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:active	{		
						border: 1px solid '.esc_html($default_color).';
						background: '.esc_html($default_color).';
						color: '.esc_html($default_text_color).';
						font-size: '.esc_html($font_size_title).';
					}			
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-widget-content .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-widget-header .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 a.ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-button.ui-state-active:hover {
						border: 1px solid '.esc_html($active_color).';
						background: '.esc_html($active_color).';
						color: '.esc_html($title_active_text_color).';	
					}
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style1 .ui-widget-content {
						background: '.esc_html($background_color).';
						border: 1px solid '.esc_html($active_color).';
						font-size: '.esc_html($font_size_text).';
					}';
			}

			if($style == 'style2') {
				echo '.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-widget-content .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-widget-header .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-button, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:hover, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:active	{		
						border: 1px solid '.esc_html($default_color).';
						background: '.esc_html($default_color).';
						color: '.esc_html($default_text_color).';
						font-size: '.esc_html($font_size_title).';
					}			
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-widget-content .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-widget-header .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 a.ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-button.ui-state-active:hover {
						border: 1px solid '.esc_html($active_color).';
						background: '.esc_html($active_color).';
						color: '.esc_html($title_active_text_color).';	
					}
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style2 .ui-widget-content {
						background: '.esc_html($background_color).';
						border: 1px solid '.esc_html($active_color).';
						font-size: '.esc_html($font_size_text).';
					}';
			}

			if($style == 'style3') {
				echo '.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-widget-content .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-widget-header .ui-state-default, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-button, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:hover, 
					html .adte-faq.adte-faq-'.esc_html($instance).' .ui-button.ui-state-disabled:active	{		
						border: 0;
						background: none;
						color: '.esc_html($default_text_color).';
						font-size: '.esc_html($font_size_title).';
					}			
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-widget-content .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-widget-header .ui-state-active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 a.ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-button:active, 
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-button.ui-state-active:hover {
						border: 0;
						background: none;
						color: '.esc_html($title_active_text_color).';	
					}
					.adte-faq.adte-faq-'.esc_html($instance).'.adte-faq-style3 .ui-widget-content {
						background: none;
						border: 0;
						padding:.5em .5em .5em .7em;
						font-size: '.esc_html($font_size_text).';
					}';
			}
			
			if($border == 'square') {
				echo '.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-all, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-bottom, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-right, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-left, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-br,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-tr,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-tl,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-top {
					border-radius:0!important;
				}';
			} else {
				echo '.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-all, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-bottom, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-right, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-left, 
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-br,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-tr,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-tl,
				.adte-faq.adte-faq-'.esc_html($instance).' .ui-corner-top {
					border-radius:'.esc_html($border_radius).'!important;
				}';							
			}
			
			
			echo '</style>';
		
		
		echo '<div id="adte-faq-'.esc_html($instance).'" class="adte-faq adte-faq-'.esc_html($instance).' adte-faq-'.esc_html($rtl).' adte-faq-'.esc_html($style).' '.faq_animate_class($addon_animate,$effect,$delay).'>';
		
		foreach($settings['faqs'] as $faq) {
			echo '<h3>'.$faq['title'].'</h3>';
			echo '<div>'.$faq['text'].'</div>';
		}
		
		echo '</div>';
		

		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {}
}
