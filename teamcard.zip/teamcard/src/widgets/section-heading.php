<?php
namespace  ElementorTeamCard\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class sectionHeading extends Widget_Base {

	public function get_name() {
		return 'tc-section-heading';
	}

	public function get_title() {
		return __( 'Section Heading', 'teamcard' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}


	public function get_categories() {
		return [ 'TeamCard' ];
	}


	protected function _register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'teamcard' ),
			]
		);

		
		$this->add_control(
			'title',
			[
				'label'       => __( 'Heading Title', 'teamcard' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Team Member 1','teamcard' ),
				'label_block' => 'true'
			]
		);
		$this->add_control(
			'header_size',
			[
				'label'   => __( 'HTML Tag', 'teamcard' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'h1'   => __( 'H1', 'teamcard' ),
					'h2'   => __( 'H2', 'teamcard' ),
					'h3'   => __( 'H3', 'teamcard' ),
					'h4'   => __( 'H4', 'teamcard' ),
					'h5'   => __( 'H5', 'teamcard' ),
					'h6'   => __( 'H6', 'teamcard' ),
					'div'  => __( 'div', 'teamcard' ),
					'span' => __( 'span', 'teamcard' ),
					'p'    => __( 'p', 'teamcard' ),
				],
				'default' => 'h2',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_subtitle',
			[
				'label' => __( 'Subtitle', 'teamcard' ),
			]
		);
		

		$this->add_control(
			'show_subtitle',
			[
				'label'        => __( 'Show Subtitle', 'teamcard' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'teamcard' ),
				'label_off'    => __( 'Hide', 'teamcard' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Heading Subtitle', 'teamcard' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Expert Members','teamcard' ),
				'label_block' => 'true',
				'condition'   => ['show_subtitle' => 'yes'],
			]
		);

		$this->add_control(
			'subtitle_position',
			[
				'label'   => __( 'Sub Title Position', 'teamcard' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'before',
				'options' => [
					'before' => __( 'Before Title', 'teamcard' ),
					'after'  => __( 'After Title', 'teamcard' ),
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_desc',
			[
				'label' => __( 'Title Description', 'teamcard' ),
			]
		);

		
		$this->add_control(
			'show_desc',
			[
				'label'        => __( 'Show Description', 'teamcard' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'teamcard' ),
				'label_off'    => __( 'Hide', 'teamcard' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);
		$this->add_control(
			'desc',
			[
				'label'     => __( 'Heading Description', 'teamcard' ),
				'type'      => \Elementor\Controls_Manager::WYSIWYG,
				'condition' => ['show_desc' => 'yes'],
				'default'   => __('The ultimate planning solution for busy people who want to reach their personal goals','teamcard' )
			]
		);
		
	

		$this->end_controls_section();


		//  Style tab Section
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'General', 'teamcard' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'text_align',
			[
				'label'   => __( 'Content Alignment', 'eduhash-toolkit' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'eduhash-toolkit' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'eduhash-toolkit' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'eduhash-toolkit' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'heading_margin',
			[
				'label'      => __( 'Heading Margin', 'teamcard' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} .heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_subtitle_style',
			[
				'label' => __( 'Subtitle', 'teamcard' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'subtitle_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}}  .heading .subheading' => 'color: {{VALUE}}',
				],
			]
		);

		

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'subtitle_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .heading .subheading',
			]
		);

		$this->add_control(
			'subtitle_margin',
			[
				'label'      => __( 'Margin', 'teamcard' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} .heading .subheading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'teamcard' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}}  .heading-title' => 'color: {{VALUE}}',
				],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'title_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .heading-title',
			]
		);
		
		
		$this->add_control(
			'title_margin',
			[
				'label'      => __( 'Margin', 'teamcard' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} .heading-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_desc_style',
			[
				'label' => __( 'Description', 'teamcard' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => __( 'Color', 'teamcard' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .heading p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'desc_padding',
			[
				'label'      => __( 'Padding', 'teamcard' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} .heading p  ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'desc_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .heading p ',
			]
		);
		

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$show_subtitle     = $settings['show_subtitle'];
		$subtitle          = $settings['subtitle'] ;
		$subtitle_position = $settings['subtitle_position'] ;

		$title     = $settings['title'] ;
		$show_desc = $settings['show_desc'];
		$desc      = $settings['desc'] ;


		echo '<div class="heading">';
					

			if ( ('yes' === $show_subtitle)  && ($subtitle_position == "before")) {
				echo '<span class="subheading">' . $subtitle  . '</span>';
			}

			if ( empty( $title ) ) {
				return;
			}
	
			$this->add_render_attribute( 'title', 'class', 'heading-title' );
	
			$title_html = sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['header_size'], $this->get_render_attribute_string( 'title' ), $title );

			echo $title_html;

			
			if ( ('yes' === $show_subtitle)  && ($subtitle_position == "after")) {
				echo '<span class="subheading">' . $subtitle  . '</span>';
			}


			if ( 'yes' === $show_desc ) {
				echo '<p>' . $desc  . '</p>';
			}

		echo '</div>';


	
	}


	
}
