<div class="team-item team-style-7">
    <div class="team-img">
        <img src="<?php echo esc_url($settings['image']['url'])?>" alt="<?php the_title_attribute( );?>" class="img-fluid">
        <div class="team-socials ">
            <ul class="team-socials-links">
                <?php foreach($lists as $list_item){ 
                    
                    ?>
                    <li>
                        <a  class="elementor-repeater-item-<?php echo $item['_id']?>" href="<?php echo esc_url($settings['link']['url'], 'teamcard');?>" <?php echo '".$target. $nofollow"';?> >
                            <i class="<?php echo esc_attr($list_item['icon']['value'], 'teamcard');?>"></i>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
    <div class="team-info">
        <h4><?php echo esc_html($title,'teamcard');?></h4>
        <span><?php echo esc_html($designation,'teamcard');?></span>
		<p><?php echo esc_html($desc,'teamcard');?></p>
    </div>
</div>