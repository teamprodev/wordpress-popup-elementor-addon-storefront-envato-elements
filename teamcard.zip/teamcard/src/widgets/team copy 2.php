<?php
namespace  ElementorTeamCard\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Team extends Widget_Base {

	public function get_name() {
		return 'tc-team-member';
	}

	public function get_title() {
		return __( 'Team Member', 'team-card' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}


	public function get_categories() {
		return [ 'TeamCard' ];
	}


	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Team Member Content', 'team-card' ),
			]
		);


		$this->add_control(
			'select_style',
			[
				'label' => __( 'Team Style', 'team-card' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style1'  => __( 'Overlay Hover Socials', 'team-card' ),
					'style2' => __( 'Hover Image Scaling', 'team-card' ),
					'style3' => __( 'Rounded Overlay Hover Socials', 'team-card' ),
					'style4' => __( 'Overlay RIgth Hover Socials', 'team-card' ),
					'style5' => __( 'Right Hover Socials ', 'team-card' ),
					'style6' => __( 'Mid Socials', 'team-card' ),
					'style7' => __( 'Bottom Hover Socials', 'team-card' ),
					'style8' => __( 'Rounded Hover Socials ', 'team-card' ),
					'style9' => __( 'List Style ', 'team-card' ),
					'style10' => __( 'Overlay Content ', 'team-card' ),
				],
				'default' => 'style1',
			]
		);
		

		$this->add_control(
			'image',
			[
				'label' => __( 'Team Image', 'team-card' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		
		$this->add_control(
			'title',
			[
				'label' => __( 'Name', 'team-card' ),
				'type' => Controls_Manager::TEXT,
				'default' =>__( 'John Doe', 'team-card' ),
			]
		);

		$this->add_control(
			'designation',
			[
				'label' => __( 'Designation ', 'team-card' ),
				'type' => Controls_Manager::TEXT,
				'default' =>__( 'Web Designer', 'team-card' ),
			]
		);

		$this->add_control(
			'show_desc',
			[
				'label'        => __( 'Show Description', 'team-card' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'team-card' ),
				'label_off'    => __( 'Hide', 'team-card' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => array(
					'select_style' => ['style2','style5','style6','style7','style8','style9','style10'],
				),
			]
		);
		$this->add_control(
			'desc',
			[
				'label'     => __( 'Heading Description', 'team-card' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'condition' => ['show_desc' => 'yes'],
				'default'   => __('The ultimate planning solution for busy people who want to reach their personal goals','team-card' )
			]
		);
	


		$this->end_controls_section();

		$this->start_controls_section(
			'section_socials',
			[
				'label' => __( 'Social Profiles', 'team-card' ),
			]
		);

		$this->add_control(
			'show_socials',
			[
				'label'        => __( 'Display Socials Profiles', 'team-card' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'team-card' ),
				'label_off'    => __( 'Hide', 'team-card' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$social = new \Elementor\Repeater();

		$social->add_control(
			'icon',
			[
				'label'   => __( 'Icon', 'team-card' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
                ],
			]
		);

		$social->add_control(
			'title',
			[
				'label'   => __( 'Label', 'team-card' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Facebook','team-card' ),
			]
		);

		$social->add_control(
			'link',
			[
				'label'   => __( 'Link', 'team-card' ),
				'type'    => Controls_Manager::URL,
				'default' => __('#','team-card' ),
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],

			]
		);


		$social->start_controls_tabs(
			'style_tabs'
		);



		$social->start_controls_tab(
			'icon_normal_style',
			[
				'label' => __( 'Normal', 'team-card' ),
			]
		);

		$social->add_control(
			'icon_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$social->add_control(
			'icon_bg_color',
			[
				'label' => __( 'Background Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'background: {{VALUE}}',
				],
			]
		);
		
	
		$social->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'label' => __( 'Border', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-socials a',
			]
		);

        
		$social->add_control(
			'icon_border_radius',
			[
				'label' => __( 'Border Radius', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$social->end_controls_tab();



		$social->start_controls_tab(
			'icon_hover_style',
			[
				'label' => __( 'Hover', 'team-card' ),
			]
		);

		$social->add_control(
			'icon_hov_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a:hover' => 'color: {{VALUE}}',
				],
			]
		);
        
		$social->add_control(
			'icon_hov_bg',
			[
				'label' => __( 'Background Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a:hover' => 'background: {{VALUE}}',
				],
			]
		);
     
		$social->add_control(
			'icon_hov_border',
			[
				'label' => __( 'Border Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

	

		$social->end_controls_tab();
        //end hover tab

        $social->end_controls_tabs();


		$this->add_control(
			'lists',
			[
				'label'       => __( 'Add Icon', 'team-card' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $social->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'title' => __( 'Title #1', 'team-card' ),
					],
					[
						'title' => __( 'Title #2', 'team-card' ),
					],
				],
				'condition' => ['show_socials' => 'yes'],

			]
		);

		$this->end_controls_section();
		


		//  Box Wrapper Style

		$this->start_controls_section(
			'section_style_box',
			[
				'label' => __( 'Content Wrapper', 'team-card' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_box',
			[
				'label' => __( 'Normal', 'team-card' ),
			]
		);


		$this->add_control(
			'bg_color',
			[
				'label' => __( 'Background Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .team-block .team-info' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team-block .team-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		

		$this->add_control(
			'box_padding',
			[
				'label' => __( 'Box Padding', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => ['select_style' => 'style1'],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item',
				'selector' => '{{WRAPPER}} .team-block',
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __( 'Box Shadow', 'team-card' ),
				'selectors' => [
					'{{WRAPPER}} .team-item' ,
					'{{WRAPPER}} .team-block',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_box',
			[
				'label' => __( 'Hover', 'team-card' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_box_border',
				'label' => __( 'Border', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item:hover',
				'selectors' => [
					'{{WRAPPER}} .team-item:hover' ,
					'{{WRAPPER}} .team-block:hover',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'hover_box_shadow',
				'label' => __( 'Box Shadow', 'team-card' ),
				'selectors' => [
					'{{WRAPPER}} .team-item:hover' ,
					'{{WRAPPER}} .team-block:hover',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();


		$this->start_controls_section(
			'img_style',
			[
				'label' => __( 'Image', 'team-card' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'img_size',
			[
				'label' => __( 'Image Size', 'team-card' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'img_gap',
			[
				'label' => __( 'Margin', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img  ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'img_border',
				'label' => __( 'Border', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-img img',
			]
		);

		
		$this->add_control(
			'img_border_radius',
			[
				'label' => __( 'Image Border Radius', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'img_box_shadow',
				'label' => __( 'Box Shadow', 'team-card' ),
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img ' ,
				],
			]
		);

		$this->add_control(
			'img_heading',
			[
				'label' => __( 'Overlay', 'team-card' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'img_overlay',
				'label' => __( 'Background Type', 'team-card' ),
				'types' => [ 'classic','gradient'],
				'selector' => '{{WRAPPER}} .team-item .team-img:after',
			]
		);


		$this->end_controls_section();

		//  Style Boxtab Section

		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Name', 'team-card' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'title_size',
				'label'    => __( 'Typography', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-info h4',
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);


		$this->start_controls_tab(
			'style_normal_title',
			[
				'label' => __( 'Normal', 'team-card' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_title',
			[
				'label' => __( 'Hover', 'team-card' ),
			]
		);
		$this->add_control(
			'title_hov_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info:hover h4' => 'color: {{VALUE}}',
				],
			]
		);
		
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

	
		$this->add_control(
			'title_gap',
			[
				'label' => __( 'Margin', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		


		//  Designation Section

		$this->start_controls_section(
			'position_style',
			[
				'label' => __( 'Position', 'team-card' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'desigantion_size',
				'label'    => __( 'Typography', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-info span',
			]
		);

		$this->start_controls_tabs(
			'style_tabs_position'
		);

		$this->start_controls_tab(
			'style_normal_position',
			[
				'label' => __( 'Normal', 'team-card' ),
			]
		);
		$this->add_control(
			'desigantion_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_position',
			[
				'label' => __( 'Hover', 'team-card' ),
			]
		);
		$this->add_control(
			'desigantion_hov_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'color: {{VALUE}}',
				],
			]
		);
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

		

		$this->add_control(
			'desigantion_gap',
			[
				'label' => __( 'Margin', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();
		


		//  Style Description Section

		$this->start_controls_section(
			'desc_style',
			[
				'label' => __( 'Description', 'team-card' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'desc_size',
				'label'    => __( 'Typography', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-info p',
			]
		);


		$this->start_controls_tabs(
			'style_tabs_desc'
		);

		$this->start_controls_tab(
			'style_normal_desc',
			[
				'label' => __( 'Normal', 'team-card' ),
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_desc',
			[
				'label' => __( 'Hover', 'team-card' ),
			]
		);
		$this->add_control(
			'desc_hov_color',
			[
				'label' => __( 'Color', 'team-card' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'color: {{VALUE}}',
				],
			]
		);
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

	
		$this->add_control(
			'desc_gap',
			[
				'label' => __( 'Margin', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		//  Socials Profiles

		$this->start_controls_section(
			'social_style',
			[
				'label' => __( 'Socials Profile', 'team-card' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_align',
			[
				'label'   => __( 'Alignment', 'team-card' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'team-card' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'team-card' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'team-card' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'display_style',
			[
				'label' => __( 'Display', 'team-card' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'inline'  => __( 'Inline Block', 'team-card' ),
					'block' => __( 'Block', 'team-card' ),
					
				],
				'default' => 'inline',
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Icon Size', 'team-card' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'icon_typo',
				'label'    => __( 'Typography', 'team-card' ),
				'selector' => '{{WRAPPER}} .team-item .team-info p',
			]
		);
		
		$this->add_responsive_control(
			'icon_gap',
			[
				'label' => __( 'Margin', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img  ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label' => __( 'Padding', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img  ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'icon_border_radius',
			[
				'label' => __( 'Border Radius', 'team-card' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'icon_box_shadow',
				'label' => __( 'Box Shadow', 'team-card' ),
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img ' ,
				],
			]
		);

		$this->add_control(
			'show_icon_size',
			[
				'label'        => __( 'Use Width Height', 'team-card' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'team-card' ),
				'label_off'    => __( 'Hide', 'team-card' ),
				'return_value' => 'yes',
				'default'      => 'no',
				// 'condition' => array(
				// 	'select_style' => ['style2','style5','style6','style7','style8','style9','style10'],
				// ),
			]
		);
		$this->add_responsive_control(
			'icon_width',
			[
				'label' => __( 'Width', 'team-card' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'default' => '',
				'condition' => ['show_icon_size' => 'yes'],
			]
		);

		$this->add_responsive_control(
			'icon_height',
			[
				'label' => __( 'Height', 'team-card' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['show_icon_size' => 'yes'],
				'default' => '',
			]
		);

		$this->add_responsive_control(
			'icon_lh',
			[
				'label' => __( 'Line Height', 'team-card' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['show_icon_size' => 'yes'],
				'default' => '',
			]
		);

		$this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$select_style = $settings['select_style'];
		$lists = $settings['lists'];
		$title = $settings['title'];
		$designation = $settings['designation'];
		$desc = $settings['desc'];
		$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';


		if ($select_style=='style1'){
			require_once( __DIR__ . '/style/team-style-1.php' );
		}
		// if ($select_style=='style2'){
		// 	require_once( __DIR__ . '/style/team-style-2.php' );
		// }

		// if ($select_style=='style3'){
		// 	require_once( __DIR__ . '/style/team-style-3.php' );
		// }
		// if ($select_style=='style4'){
		// 	require_once( __DIR__ . '/style/team-style-4.php' );
		// }
		// if ($select_style=='style5'){
		// 	require_once( __DIR__ . '/style/team-style-5.php' );
		// }

		// if ($select_style=='style6'){
		// 	require_once( __DIR__ . '/style/team-style-6.php' );
		// }
		// if ($select_style=='style7'){
		// 	require_once( __DIR__ . '/style/team-style-7.php' );
		// }

		// if ($select_style=='style8'){
		// 	require_once( __DIR__ . '/style/team-style-8.php' );
		// }
		// if ($select_style=='style9'){
		// 	require_once( __DIR__ . '/style/team-style-9.php' );
		// }
		// if ($select_style=='style10'){
		// 	require_once( __DIR__ . '/style/team-style-10.php' );
		// }

	}


}
