<?php
namespace  ElementorTeamCard\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Team extends Widget_Base {

	public function get_name() {
		return 'tc-team-member';
	}

	public function get_title() {
		return __( 'Team Member', 'teamcard' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}


	public function get_categories() {
		return [ 'TeamCard' ];
	}


	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Team Member Content', 'teamcard' ),
			]
		);


		$this->add_control(
			'select_style',
			[
				'label' => __( 'Team Style', 'teamcard' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style1'  => __( 'Overlay Hover Socials', 'teamcard' ),
					'style2' => __( 'Hover Image Scaling', 'teamcard' ),
					'style3' => __( 'Rounded Overlay Hover Socials', 'teamcard' ),
					'style4' => __( 'Overlay RIgth Hover Socials', 'teamcard' ),
					'style5' => __( 'Right Hover Socials ', 'teamcard' ),
					'style6' => __( 'Mid Socials', 'teamcard' ),
					'style7' => __( 'Bottom Hover Socials', 'teamcard' ),
					'style8' => __( 'Rounded Hover Socials ', 'teamcard' ),
					'style9' => __( 'List Style ', 'teamcard' ),
					'style10' => __( 'Overlay Content ', 'teamcard' ),
				],
				'default' => 'style1',
			]
		);
		

		$this->add_control(
			'image',
			[
				'label' => __( 'Team Image', 'teamcard' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		
		$this->add_control(
			'title',
			[
				'label' => __( 'Name', 'teamcard' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' =>__( 'John Doe', 'teamcard' ),
			]
		);

		$this->add_control(
			'designation',
			[
				'label' => __( 'Designation ', 'teamcard' ),
				'type' => Controls_Manager::TEXT,
				'default' =>__( 'Web Designer', 'teamcard' ),
			]
		);

		$this->add_control(
			'show_desc',
			[
				'label'        => __( 'Show Description', 'teamcard' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'teamcard' ),
				'label_off'    => __( 'Hide', 'teamcard' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => array(
					'select_style' => ['style2','style5','style6','style7','style8','style9','style10'],
				),
			]
		);
		$this->add_control(
			'desc',
			[
				'label'     => __( 'Heading Description', 'teamcard' ),
				'type'      => Controls_Manager::TEXTAREA,
				'condition' => ['show_desc' => 'yes'],
				'default'   => __('The ultimate planning solution for busy people who want to reach their personal goals','teamcard' )
			]
		);
	


		$this->end_controls_section();

		
		// Socials Links

		$this->start_controls_section(
			'section_socials',
			[
				'label' => __( 'Social Profiles', 'teamcard' ),
			]
		);

		$this->add_control(
			'show_socials',
			[
				'label'        => __( 'Display Socials Profiles', 'teamcard' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'teamcard' ),
				'label_off'    => __( 'Hide', 'teamcard' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$social = new \Elementor\Repeater();

		$social->add_control(
			'icon',
			[
				'label'   => __( 'Icon', 'teamcard' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
                ],
			]
		);

		$social->add_control(
			'title',
			[
				'label'   => __( 'Label', 'teamcard' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Facebook','teamcard' ),
			]
		);

		$social->add_control(
			'link',
			[
				'label'   => __( 'Link', 'teamcard' ),
				'type'    => Controls_Manager::URL,
				'default' => __('#','teamcard' ),
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],

			]
		);


		$social->start_controls_tabs(
			'style_tabs'
		);



		$social->start_controls_tab(
			'icon_normal_style',
			[
				'label' => __( 'Normal', 'teamcard' ),
			]
		);

		$social->add_control(
			'icon_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
				],
			]
		);
		
		$social->add_control(
			'icon_bg_color',
			[
				'label' => __( 'Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
			
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'background: {{VALUE}}'
				],
			]
		);
		
	
		$social->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'label' => __( 'Border', 'teamcard' ),
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}'
				],
			]
		);

        
		$social->add_control(
			'icon_border_radius',
			[
				'label' => __( 'Border Radius', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$social->end_controls_tab();



		$social->start_controls_tab(
			'icon_hover_style',
			[
				'label' => __( 'Hover', 'teamcard' ),
			]
		);

		$social->add_control(
			'icon_hov_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'color: {{VALUE}}'
				],
			]
		);
        
		$social->add_control(
			'icon_hov_bg',
			[
				'label' => __( 'Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
			
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'background: {{VALUE}}'
				],
				
			]
		);
     
		$social->add_control(
			'icon_hov_border',
			[
				'label' => __( 'Border Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

	

		$social->end_controls_tab();
        //end hover tab

        $social->end_controls_tabs();


		$this->add_control(
			'lists',
			[
				'label'       => __( 'Add Icon', 'teamcard' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $social->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => [
					[
						'title' => __( 'Title #1', 'teamcard' ),
					],
					[
						'title' => __( 'Title #2', 'teamcard' ),
					],
				],
				'condition' => ['show_socials' => 'yes'],

			]
		);

		$this->end_controls_section();
		//  Box Wrapper Style

		$this->start_controls_section(
			'section_style_box',
			[
				'label' => __( 'Content Wrapper', 'teamcard' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_box',
			[
				'label' => __( 'Normal', 'teamcard' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bg_color',
				'label' => __( 'Background Type', 'teamcard' ),
				'types' => [ 'classic','gradient'],
				'selector' => '{{WRAPPER}} .team-item ',
			]
		);
		

		$this->add_control(
			'box_padding',
			[
				'label' => __( 'Box Padding', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item',
			]
		);

	


		// COntent
		$this->add_responsive_control(
			'text_align',
			[
				'label'   => __( 'Content Alignment', 'teamcard' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'teamcard' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'teamcard' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'teamcard' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'separator'   => 'before',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info' => 'text-align: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'content_bg_color',
			[
				'label' => __( 'Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info' => 'background: {{VALUE}}',
				],
				'condition' => array(
					'select_style!' => ['style3','style4'],
				),
			]
		);

		
		$this->add_control(
			'content_padding',
			[
				'label' => __( 'Content Padding', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'content_border',
				'label' => __( 'Border', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-info' ,
				'condition' => array(
					'select_style!' => ['style3','style4'],
				),
			]
		);

		$this->add_control(
			'content_border_radius',
			[
				'label' => __( 'Border Radius', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => array(
					'select_style!' => ['style3','style4'],
				),
			]
		);
		
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_box_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-info',
				'condition' => array(
					'select_style!' => ['style3'],
				),
			]
		);


		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_box',
			[
				'label' => __( 'Hover', 'teamcard' ),
			]
		);
	
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bg_hov_color',
				'label' => __( 'Background Type', 'teamcard' ),
				'types' => [ 'classic','gradient'],
				'selector' => '{{WRAPPER}} .team-item:hover ',
			]
		);
		
		$this->add_control(
			'box_hov_border',
			[
				'label' => __( 'Border Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item:hover ' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_hov_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item:hover',
			]
		);


		$this->add_control(
			'content_heading',
			[
				'label' => __( 'Content', 'teamcard' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array(
					'select_style!' => ['style3'],
				),
			]
		);

		$this->add_control(
			'content_hov_color',
			[
				'label' => __( 'Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item:hover .team-info' => 'background: {{VALUE}}',
				],
				'condition' => array(
					'select_style!' => ['style3','style4'],
				),
			]
		);

		$this->add_control(
			'content_hov_bg',
			[
				'label' => __( 'Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item:hover .team-info:before' => 'background: {{VALUE}}',
				],
				'condition' => array(
					'select_style' => ['style4'],
				),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_hov_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item:hover .team-info',
				'condition' => array(
					'select_style!' => ['style3'],
				),
			]
		);

		
		$this->add_control(
			'content_hov_border',
			[
				'label' => __( 'Border Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item:hover .team-info' => 'border-color: {{VALUE}}',
				],
				'condition' => array(
					'select_style!' => ['style3'],
				),
			]
		);

		$this->add_control(
			'content_bottom_border',
			[
				'label' => __( 'Border Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info::before' => 'background: {{VALUE}}',
				],
				'condition' => array(
					'select_style' => ['style1'],
				),
			]
		);

		$this->add_control(
			'socials_hov_bg',
			[
				'label' => __( 'Socials Background Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials' => 'background: {{VALUE}}',
				],
				'condition' => array(
					'select_style' => ['style5','style6','style7','style8'],
				),
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();


		// Image styles

		$this->start_controls_section(
			'img_style',
			[
				'label' => __( 'Image', 'teamcard' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'img_size',
			[
				'label' => __( 'Image Size', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'range'  => [
                    'px' => [
                        'min'   => 10,
                        'max'   => 300,
                    ],
                ],
				'selectors' => [
					'{{WRAPPER}} .team-style-1 .team-img img,
					{{WRAPPER}} .team-style-2 .team-img img,
					{{WRAPPER}} .team-style-3 .team-img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
				'default' => [
					'unit' => '%'
				]

			]
		);


		$this->add_control(
			'img_gap',
			[
				'label' => __( 'Margin', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img  ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'img_border',
				'label' => __( 'Border', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-img img',
			]
		);

		
		$this->add_control(
			'img_border_radius',
			[
				'label' => __( 'Image Border Radius', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

	
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'img_box_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selectors' => [
					'{{WRAPPER}} .team-item .team-img ' ,
				],
			]
		);

		$this->add_control(
			'img_heading',
			[
				'label' => __( 'Overlay', 'teamcard' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'img_overlay',
				'label' => __( 'Background Type', 'teamcard' ),
				'types' => [ 'classic','gradient'],
				'selector' => '{{WRAPPER}} .team-item .team-img:after',
			]
		);


		$this->end_controls_section();


		//  Style Boxtab Section

		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Name', 'teamcard' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'title_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-info h4',
			]
		);

		$this->start_controls_tabs(
			'style_tabs_title'
		);


		$this->start_controls_tab(
			'style_normal_title',
			[
				'label' => __( 'Normal', 'teamcard' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_title',
			[
				'label' => __( 'Hover', 'teamcard' ),
			]
		);
		$this->add_control(
			'title_hov_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info:hover h4' => 'color: {{VALUE}}',
				],
			]
		);
		
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

	
		$this->add_control(
			'title_gap',
			[
				'label' => __( 'Margin', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		
		//  Designation Section

		$this->start_controls_section(
			'position_style',
			[
				'label' => __( 'Position', 'teamcard' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'desigantion_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-info span',
			]
		);

		$this->start_controls_tabs(
			'style_tabs_position'
		);

		$this->start_controls_tab(
			'style_normal_position',
			[
				'label' => __( 'Normal', 'teamcard' ),
			]
		);
		$this->add_control(
			'desigantion_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_position',
			[
				'label' => __( 'Hover', 'teamcard' ),
			]
		);
		$this->add_control(
			'desigantion_hov_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'color: {{VALUE}}',
				],
			]
		);
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

		

		$this->add_control(
			'desigantion_gap',
			[
				'label' => __( 'Margin', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();


		//  Style Description Section

		$this->start_controls_section(
			'desc_style',
			[
				'label' => __( 'Description', 'teamcard' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'desc_size',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-info p',
			]
		);


		$this->start_controls_tabs(
			'style_tabs_desc'
		);

		$this->start_controls_tab(
			'style_normal_desc',
			[
				'label' => __( 'Normal', 'teamcard' ),
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();



		$this->start_controls_tab(
			'style_hover_desc',
			[
				'label' => __( 'Hover', 'teamcard' ),
			]
		);
		$this->add_control(
			'desc_hov_color',
			[
				'label' => __( 'Color', 'teamcard' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'color: {{VALUE}}',
				],
			]
		);
	
		$this->end_controls_tab();

		$this->end_controls_tabs();

	
		$this->add_control(
			'desc_gap',
			[
				'label' => __( 'Margin', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-info p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		//  Socials Profiles

		$this->start_controls_section(
			'social_style',
			[
				'label' => __( 'Socials Profile', 'teamcard' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_align',
			[
				'label'   => __( 'Alignment', 'teamcard' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'teamcard' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'teamcard' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'teamcard' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => 'center',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'display_style',
			[
				'label' => __( 'Display', 'teamcard' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'initial'  => __( 'Default', 'teamcard' ),
					'inline-block'  => __( 'Inline Block', 'teamcard' ),
					'block' => __( 'Block', 'teamcard' ),
					
				],
				'default' => 'initial',
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials li'  => 'display: {{VALUE}};',
				],
			]
		);

		
		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Icon Size', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => ['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography:: get_type(),
			[
				'name'     => 'icon_typo',
				'label'    => __( 'Typography', 'teamcard' ),
				'selector' => '{{WRAPPER}} .team-item .team-socials a',
			]
		);

		$this->add_responsive_control(
			'icon_gap',
			[
				'label' => __( 'Margin', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label' => __( 'Padding', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_border_radius',
			[
				'label' => __( 'Border Radius', 'teamcard' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'icon_box_shadow',
				'label' => __( 'Box Shadow', 'teamcard' ),
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' ,
				],
			]
		);

		$this->add_control(
			'show_icon_size',
			[
				'label'        => __( 'Use Width Height', 'teamcard' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'teamcard' ),
				'label_off'    => __( 'Hide', 'teamcard' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_responsive_control(
			'icon_width',
			[
				'label' => __( 'Width', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}}  .team-item .team-socials a' => 'width: {{SIZE}}{{UNIT}};',
				],
				'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => 'px',
                ],
				'condition' => ['show_icon_size' => 'yes'],
			]
		);

		$this->add_responsive_control(
			'icon_height',
			[
				'label' => __( 'Height', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}}  .team-item .team-socials a' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['show_icon_size' => 'yes'],
				'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => 'px',
                ],
			]
		);

		$this->add_responsive_control(
			'icon_lh',
			[
				'label' => __( 'Line Height', 'teamcard' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units'  =>['px','%','em'],
				'selectors' => [
					'{{WRAPPER}} .team-item .team-socials a' => 'line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => ['show_icon_size' => 'yes'],
				'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => 'px',
                ],
			]
		);


		$this->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$select_style = $settings['select_style'];
		$lists = $settings['lists'];
		$title = $settings['title'];
		$designation = $settings['designation'];
		$desc = $settings['desc'];
		$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';


		if ($select_style=='style1'){
			require( __DIR__ . '/style/team-style-1.php' );
		}
		if ($select_style=='style2'){
			require( __DIR__ . '/style/team-style-2.php' );
		}

		if ($select_style=='style3'){
			require( __DIR__ . '/style/team-style-3.php' );
		}
		if ($select_style=='style4'){
			require( __DIR__ . '/style/team-style-4.php' );
		}
		if ($select_style=='style5'){
			require( __DIR__ . '/style/team-style-5.php' );
		}

		if ($select_style=='style6'){
			require( __DIR__ . '/style/team-style-6.php' );
		}
		if ($select_style=='style7'){
			require( __DIR__ . '/style/team-style-7.php' );
		}

		if ($select_style=='style8'){
			require( __DIR__ . '/style/team-style-8.php' );
		}
		if ($select_style=='style9'){
			require( __DIR__ . '/style/team-style-9.php' );
		}
		if ($select_style=='style10'){
			require( __DIR__ . '/style/team-style-10.php' );
		}

	}


}
