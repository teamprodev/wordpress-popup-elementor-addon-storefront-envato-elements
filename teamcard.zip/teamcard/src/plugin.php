<?php
namespace ElementorTeamCard;

use ElementorTeamCard\Widgets\Team;
use ElementorTeamCard\Widgets\sectionHeading;

class Plugin {
	
	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}


	public function widget_styles() {
		wp_enqueue_style( 'team-style', plugins_url( '/assets/css/style.css', __FILE__ ));
	}


	
	public function editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'editor_scripts_as_a_module' ], 10, 2 );

		wp_enqueue_script(
			'elementor-hello-world-editor',
			plugins_url( '/assets/js/editor/editor.js', __FILE__ ),
			[
				'elementor-editor',
			],
			'1.2.1',
			true
		);
	}


	public function editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'elementor-hello-world-editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/section-heading.php' );
		require_once( __DIR__ . '/widgets/team.php' );
	}

	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Team() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\sectionHeading() );
	}

	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/manager.php' );
	}


	public function __construct() {

		// Register widget scripts
		// add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Enqueue widget Styles
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		// Register editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'editor_scripts' ] );
		// Register New Category
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories' ]  );
		
	}


	function add_elementor_widget_categories( $elements_manager ) {
	
		$elements_manager->add_category(
			'TeamCard',
			[
				'title' => __( 'Team Card', 'team-card' ),
				'icon' => 'fa fa-plug',
			]
		);
	}

}

// Instantiate Plugin Class
Plugin::instance();
