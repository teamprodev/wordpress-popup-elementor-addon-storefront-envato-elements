<?php
namespace ElementorTMNET;

class TMNETLoadElementor {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/table.php' );
	}

	public function widget_styles() {
        wp_register_style( 'tmnet-data-table', plugins_url( '/css/data-table.css', __FILE__ ), false, '1.0' );
		wp_register_style( 'tmnet', plugins_url( '/css/style.css', __FILE__ ), false, '1.0' );
	}

	public function register_widgets() {
		$this->include_widgets_files();

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TMNET_Table() );
	}

    public function widget_scripts() {
		wp_register_script( 'tmnet-data-table', plugins_url( '/js/data-table.js', __FILE__ ), [ 'jquery' ], false, true );
		wp_register_script( 'tmnet-table', plugins_url( '/js/tmnet-table.js', __FILE__ ), [ 'jquery' ], false, true );
		$tmnet_param = array(
			"lengthMenu" => esc_html__( 'Display _MENU_ records per page', 'tmnet' ),
			"zeroRecords" => esc_html__( 'Nothing found - sorry', 'tmnet' ),
			"info" => esc_html__( 'Showing page _PAGE_ of _PAGES_', 'tmnet' ),
			"infoEmpty" => esc_html__( 'No records available', 'tmnet' ),
			"infoFiltered" => esc_html__( '(filtered from _MAX_ total records)', 'tmnet' ),
			"searchPlaceholder" => esc_html__( 'Search...', 'tmnet' ),
			"processing" => esc_html__( 'Processing...', 'tmnet' ),
			"csvHtml5" => esc_html__( 'CSV', 'tmnet' ),
			"excelHtml5" => esc_html__( 'Excel', 'tmnet' ),
			"pdfHtml5" => esc_html__( 'PDF', 'tmnet' ),
			"print" => esc_html__( 'Print', 'tmnet' )
		);
		wp_localize_script('tmnet-table', 'tmnet_vars', $tmnet_param);
	}

	public function widget_category($elements_manager) {
		$elements_manager->add_category(
			'tmnet-widgets',
			[
				'title' => esc_html__( 'TMNET', 'tmnet' ),
				'icon' => 'fa fa-plug',
			]
		);
	}

	public function __construct() {
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'widget_category' ] );
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}
}

TMNETLoadElementor::instance();