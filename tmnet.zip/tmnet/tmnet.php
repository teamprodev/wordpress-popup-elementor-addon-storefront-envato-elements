<?php
/**
 * Plugin Name: TMNET
 * Plugin URI: http://codecanyon.net/
 * Description: WordPress Multisite Network Site List For Elementor
 * Version: 1.0
 * Author: Egemenerd
 * Author URI: http://codecanyon.net/user/egemenerd
 * License: http://codecanyon.net/licenses
 * Text Domain: tmnet
 * Domain Path: /languages/
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'TMNET_PLUGIN_URL' ) ) {
	define( 'TMNET_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/* ---------------------------------------------------------
Elementor
----------------------------------------------------------- */

include_once('elementor.php');