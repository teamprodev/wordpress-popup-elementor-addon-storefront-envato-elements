( function( $ ) {
    "use strict";
	$( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/tmnet-table.default', function($scope){
            var $container = $scope.find('.tmnet-table-container');  
            var $buttons = $container.data('buttons');
            if ($buttons == true) {
                var $dom = 'Bfrtip';
            } else {
                var $dom = 'frtip';
            }

            var count_headings = $scope.find("table thead tr th").length;
            $scope.find("table tbody tr").each(function() {
                if ($(this).find('td').length < count_headings) {
                    var n = count_headings - $(this).find('td').length;
                    $(this).append(new Array(++n).join('<td></td>'));
                }
            });

            $scope.find('.tmnet-table').DataTable({
                dom: $dom,
                paging: $container.data('paging'),
                pagingType: 'numbers',
                pageLength: $container.data('pagelength'),
                info: $container.data('info'),
                scrollX: true,
                searching: $container.data('searching'),
                ordering:  $container.data('ordering'),
                buttons: [
                    {
                        extend: 'csvHtml5',
                        text: tmnet_vars.csvHtml5
                    },
                    {
                        extend: 'excelHtml5',
                        text: tmnet_vars.excelHtml5
                    },
                    {
                        extend: 'pdfHtml5',
                        text: tmnet_vars.pdfHtml5
                    },
                    {
                        extend: 'print',
                        text: tmnet_vars.print
                    }
                ],
                language: {
                    lengthMenu: tmnet_vars.lengthMenu,
                    zeroRecords: tmnet_vars.zeroRecords,
                    info: tmnet_vars.info,
                    infoEmpty: tmnet_vars.infoEmpty,
                    infoFiltered: tmnet_vars.infoFiltered,
                    search: "",
                    searchPlaceholder: tmnet_vars.searchPlaceholder,
                    processing: tmnet_vars.processing
                }
            });
            $scope.find('.tmnet-table').css('visibility', 'visible');
        });        
    });
} )( jQuery );