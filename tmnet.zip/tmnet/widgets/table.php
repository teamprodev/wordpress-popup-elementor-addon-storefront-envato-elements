<?php
namespace ElementorTMNET\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;

class TMNET_Table extends Widget_Base {

	public function get_name() {
		return 'tmnet-table';
	}

	public function get_title() {
		return esc_html__( 'TMNET', 'tmnet' );
	}

    public function get_icon() {
		return 'eicon-table';
    }

	public function get_categories() {
		return [ 'tmnet-widgets' ];
	}
    
    public function get_style_depends(){
		return [ 'elementor-icons-fa-solid', 'tmnet-data-table', 'tmnet' ];
	}
    
    public function get_script_depends() {
		return [ 'tmnet-data-table', 'tmnet-table' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
			'data_fields_section',
			[
				'label' => esc_html__( 'Data Fields', 'tmnet' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'data_label', [
				'label' => esc_html__( 'Label', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Site Name', 'tmnet' ),
				'label_block' => true
			]
		);

		$repeater->add_control(
			'data_field',
			[
				'label' => esc_html__( 'Data', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
                    'name' => esc_html__( 'Site Name', 'tmnet' ),
					'desc' => esc_html__( 'Site Description', 'tmnet' ),
					'site_icon' => esc_html__( 'Site Icon', 'tmnet' ),
					'post_count' => esc_html__( 'Post Count', 'tmnet' ),
					'user_count' => esc_html__( 'User Count', 'tmnet' ),
					'registered' => esc_html__( 'Registered', 'tmnet' ),
					'last_updated' => esc_html__( 'Last Updated', 'tmnet' ),
					'view_site' => esc_html__( 'View Site', 'tmnet' ),
					'blog_option' => esc_html__( 'Blog Option', 'tmnet' ),
				],
				'label_block' => true
			]
		);

		$repeater->add_control(
			'data_blog_opt', [
				'label' => esc_html__( 'Blog Option Name', 'tmnet' ),
				'description' => esc_html__( 'You must enter a valid blog option name. Output will be string. For more information, please read the documentation.', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => ['data_field' => 'blog_option'],
				'default' => 'admin_email'
			]
		);

        $repeater->add_control(
			'table_header_style_column',
			[
				'label' => esc_html__( 'Style This Column', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
				'default' => '',
			]
        );
        
        $repeater->add_responsive_control(
			'table_header_style_column_width',
			[
				'label' => esc_html__( 'Width', 'tmnet' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vw', 'rem' ],
				'range' => [
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
                    'px' => [
						'min' => 0,
						'max' => 1000,
					],
                    'rem' => [
						'min' => 0,
						'max' => 100,
					],
                ],
                'condition' => ['table_header_style_column' => 'yes'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}} !important;'
				]
			]
        );

		$repeater->add_responsive_control(
			'table_header_style_column_min_width',
			[
				'label' => esc_html__( 'Minumum Width', 'tmnet' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vw', 'rem' ],
				'range' => [
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
                    'px' => [
						'min' => 0,
						'max' => 1000,
					],
                    'rem' => [
						'min' => 0,
						'max' => 100,
					],
                ],
                'condition' => ['table_header_style_column' => 'yes'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'min-width: {{SIZE}}{{UNIT}} !important;'
				]
			]
        );

		$repeater->add_control(
			'table_header_style_text_align',
			[
				'label' => esc_html__( 'Text Align', 'tmnet' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'tmnet' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'tmnet' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'tmnet' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'condition' => ['table_header_style_column' => 'yes'],
				'default' => 'left',
                'toggle' => false,
                'selectors' => [
					'{{WRAPPER}} td{{CURRENT_ITEM}}' => 'text-align: {{VALUE}};',
				]
			]
        );

		$repeater->add_control(
			'table_header_style_column_weight',
			[
				'label' => esc_html__( 'Font Weight', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => [
					'lighter' => esc_html__( 'Lighter', 'tmnet' ),
                    'normal' => esc_html__( 'Normal', 'tmnet' ),
                    'bold' => esc_html__( 'Bold', 'tmnet' ),
                    'bolder' => esc_html__( 'Bolder', 'tmnet' )
				],
				'condition' => ['table_header_style_column' => 'yes'],
				'selectors' => [
					'{{WRAPPER}} td{{CURRENT_ITEM}}' => 'font-weight: {{VALUE}} !important;',
				]
			]
		);
        
        $repeater->add_control(
			'table_header_style_column_color',
			[
				'label' => esc_html__( 'Font Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'condition' => ['table_header_style_column' => 'yes'],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} {{CURRENT_ITEM}} a' => 'color: {{VALUE}} !important;'
				]
			]
		);
        
        $repeater->add_control(
			'table_header_style_column_bg',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'condition' => ['table_header_style_column' => 'yes'],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'background-color: {{VALUE}} !important;'
				]
			]
		);

		$this->add_control(
			'data_fields',
			[
				'label' => esc_html__( 'Fields', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
                'show_label' => false,
				'prevent_empty' => true,
				'default' => [
					[
                        'data_label' => esc_html__( 'Site Name', 'tmnet' ),
						'data_field' => 'name',
						'data_blog_opt' => 'admin_email'
					],
					[
                        'data_label' => esc_html__( 'Site Description', 'tmnet' ),
						'data_field' => 'desc',
						'data_blog_opt' => 'admin_email'
					],
					[
                        'data_label' => '',
						'data_field' => 'view_site',
						'data_blog_opt' => 'admin_email'
					],
				],
				'title_field' => '{{{ data_label }}}'
			]
		);

		$this->add_control(
			'add_link',
			[
				'label' => esc_html__( 'Add Link To The Site Icon & Name', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'query_settings_section',
			[
				'label' => esc_html__( 'Query Settings', 'tmnet' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'limit',
			[
				'label' => esc_html__( 'Maximum number of sites', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 99999,
				'step' => 1,
				'default' => 99,
			]
		);

        $this->add_control(
			'exclude', [
				'label' => esc_html__( 'Exclude sites by ID', 'tmnet' ),
                'description' => esc_html__( 'To exclude multiple sites, add comma between IDs.', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'include', [
				'label' => esc_html__( 'Include sites by ID', 'tmnet' ),
                'description' => esc_html__( 'To include multiple sites, add comma between IDs.', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => ''
			]
		);

		$this->add_control(
			'date_format', [
				'label' => esc_html__( 'Registration Format', 'tmnet' ),
                'description' => esc_html__( 'Leave this field blank for human_time_diff format.', 'tmnet' ) . '</br><a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">' . esc_html__( 'Formatting date and time', 'tmnet' ) . '</a>',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => get_option('date_format')
			]
		);

		$this->add_control(
			'last_date_format', [
				'label' => esc_html__( 'Latest Update Format', 'tmnet' ),
                'description' => esc_html__( 'Leave this field blank for human_time_diff format.', 'tmnet' ) . '</br><a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">' . esc_html__( 'Formatting date and time', 'tmnet' ) . '</a>',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => get_option('date_format')
			]
		);

		$this->add_control(
			'site_attrs',
			[
				'label' => esc_html__( 'Site Attributes', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'public',
			[
				'label' => esc_html__( 'Public', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

		$this->add_control(
			'archived',
			[
				'label' => esc_html__( 'Archived', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => ''
			]
        );

		$this->add_control(
			'mature',
			[
				'label' => esc_html__( 'Mature', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => ''
			]
        );

		$this->add_control(
			'spam',
			[
				'label' => esc_html__( 'Spam', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => ''
			]
        );

		$this->add_control(
			'deleted',
			[
				'label' => esc_html__( 'Deleted', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => ''
			]
        );

		$this->end_controls_section();

        $this->start_controls_section(
			'table_settings_section',
			[
				'label' => esc_html__( 'Table Settings', 'tmnet' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        $this->add_control(
			'table_paging',
			[
				'label' => esc_html__( 'Paging', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

        $this->add_control(
            'table_page_length',
            [
                'label' => esc_html__( 'Page Length', 'tmnet' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 20
            ]
        );

        $this->add_control(
			'table_info',
			[
				'label' => esc_html__( 'Info', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

        $this->add_control(
			'table_searching',
			[
				'label' => esc_html__( 'Searching', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

        $this->add_control(
			'table_ordering',
			[
				'label' => esc_html__( 'Ordering', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

		$this->add_control(
			'site_order',
			[
				'label' => esc_html__( 'Order', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ASC',
				'condition' => ['table_ordering' => ''],
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'tmnet' ),
					'DESC' => esc_html__( 'Descending', 'tmnet' )
				],
			]
		);

		$this->add_control(
			'site_orderby',
			[
				'label' => esc_html__( 'Order By', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'registered',
				'condition' => ['table_ordering' => ''],
				'options' => [
					'registered'  => esc_html__( 'Registered', 'tmnet' ),
					'last_updated' => esc_html__( 'Last Updated', 'tmnet' ),
					'id' => esc_html__( 'ID', 'tmnet' ),
					'domain' => esc_html__( 'Domain', 'tmnet' ),
					'path' => esc_html__( 'Path', 'tmnet' ),
				],
			]
		);

        $this->add_control(
			'table_buttons',
			[
				'label' => esc_html__( 'Buttons', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_style_section',
			[
				'label' => esc_html__( 'Table', 'tmnet' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_responsive_control(
			'table_spacing',
			[
				'label' => esc_html__( 'Inner Spacing (px)', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
                'default' => 10,
                'selectors' => [
					'{{WRAPPER}} table.dataTable thead th' => 'padding: {{VALUE}}px;',
					'{{WRAPPER}} table.dataTable.cell-border tbody td' => 'padding: {{VALUE}}px;'
				]
			]
		);

		$this->add_responsive_control(
			'table_top_bottom_spacing',
			[
				'label' => esc_html__( 'Top-Bottom Spacing (px)', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
                'default' => 15,
                'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_scroll' => 'padding: {{VALUE}}px 0;'
				]
			]
		);
        
        $this->add_control(
			'table_border_color',
			[
				'label' => esc_html__( 'Border Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#dddddd',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable.cell-border tbody th' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} table.dataTable.cell-border tbody td' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} table.dataTable thead th' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} table.dataTable thead td' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper.no-footer .dataTables_scrollBody' => 'border-color: {{VALUE}};'
				]
			]
        );
        
        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_header_style_section',
			[
				'label' => esc_html__( 'Table Header', 'tmnet' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_header_typography',
				'selector' => '{{WRAPPER}} table.dataTable thead th',
			]
        );
        
        $this->add_control(
			'table_header_text_align',
			[
				'label' => esc_html__( 'Text Align', 'tmnet' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'tmnet' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'tmnet' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'tmnet' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
                'toggle' => false,
                'selectors' => [
					'{{WRAPPER}} table.dataTable thead th' => 'text-align: {{VALUE}};',
				]
			]
        );
        
        $this->add_control(
			'table_header_sorting_align',
			[
				'label' => esc_html__( 'Sorting Icon Align', 'tmnet' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'tmnet' ),
						'icon' => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'tmnet' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => 'right',
				'selectors' => [
                    '{{WRAPPER}} .dataTables_scrollHead table.dataTable thead .sorting:after' => '{{VALUE}}: {{table_spacing.VALUE}}px;',
                    '{{WRAPPER}} .dataTables_scrollHead table.dataTable thead .sorting_asc:after' => '{{VALUE}}: {{table_spacing.VALUE}}px;',
                    '{{WRAPPER}} .dataTables_scrollHead table.dataTable thead .sorting_desc:after' => '{{VALUE}}: {{table_spacing.VALUE}}px;',
                    '{{WRAPPER}} .dataTables_scrollHead table.dataTable thead .sorting_asc_disabled:after' => '{{VALUE}}: {{table_spacing.VALUE}}px;',
                    '{{WRAPPER}} .dataTables_scrollHead table.dataTable thead .sorting_desc_disabled:after' => '{{VALUE}}: {{table_spacing.VALUE}}px;',
				],
                'toggle' => false
			]
		);

        $this->add_control(
			'table_header_font_color',
			[
				'label' => esc_html__( 'Font Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#252525',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable thead th' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_header_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable thead th' => 'background-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'table_header_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 

        $this->add_responsive_control(
			'table_header_min_width',
			[
				'label' => esc_html__( 'Minumum Width', 'tmnet' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vw', 'rem' ],
				'range' => [
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
                    'px' => [
						'min' => 0,
						'max' => 1000,
					],
                    'rem' => [
						'min' => 0,
						'max' => 100,
					],
                ],
                'selectors' => [
                    '{{WRAPPER}} table.dataTable thead th' => 'min-width: {{SIZE}}{{UNIT}};'
				]
			]
        );

        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_body_style_section',
			[
				'label' => esc_html__( 'Table Body', 'tmnet' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_body_typography',
				'selector' => '{{WRAPPER}} table.dataTable tbody tr',
			]
        );

        $this->add_control(
			'table_body_text_align',
			[
				'label' => esc_html__( 'Text Align', 'tmnet' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'tmnet' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'tmnet' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'tmnet' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
                'toggle' => false,
                'selectors' => [
					'{{WRAPPER}} table.dataTable tbody tr' => 'text-align: {{VALUE}};',
				]
			]
		);

		$this->add_responsive_control(
			'table_body_icon_margin',
			[
				'label' => esc_html__( 'Icon Margin', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody td i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

        $this->add_control(
			'table_body_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 

        $this->start_controls_tabs( 'table_body_styles' );
        
        $this->start_controls_tab(
			'table_body_odd',
			[
				'label' => esc_html__( 'Odd', 'tmnet'),
			]
		);
        
        $this->add_control(
			'table_body_font_color_odd',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#757575',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.odd' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_link_color_odd',
			[
				'label' => esc_html__( 'Link Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.odd a' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_link_hover_color_odd',
			[
				'label' => esc_html__( 'Link Hover Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.odd a:hover' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_odd_bg',
			[
				'label' => esc_html__( 'Row Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#f9f9f9',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.odd' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} table.dataTable tbody tr.odd td' => 'background-color: {{VALUE}};'
				]
			]
        );
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'table_body_even',
			[
				'label' => esc_html__( 'Even', 'tmnet'),
			]
		);

        $this->add_control(
			'table_body_font_color_even',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#757575',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.even' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_link_color_even',
			[
				'label' => esc_html__( 'Link Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.even a' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_link_hover_color_even',
			[
				'label' => esc_html__( 'Link Hover Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.even a:hover' => 'color: {{VALUE}};'
				]
			]
        );

        $this->add_control(
			'table_body_even_bg',
			[
				'label' => esc_html__( 'Row Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} table.dataTable tbody tr.even' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} table.dataTable tbody tr.even td' => 'background-color: {{VALUE}};'
				]
			]
        );

        $this->end_controls_tab();
		$this->end_controls_tabs();

        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_buttons_style_section',
			[
				'label' => esc_html__( 'Buttons', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'table_buttons' => 'yes'
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_btn_typography',
				
				'selector' => '{{WRAPPER}} button.dt-button,{{WRAPPER}} div.dt-button,{{WRAPPER}} a.dt-button',
			]
		);
        
        $this->add_control(
			'table_btn_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);  
        
        $this->start_controls_tabs( 'tabs_table_button_style' );
        
        $this->start_controls_tab(
			'tab_table_button_normal',
			[
				'label' => esc_html__( 'Normal', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_btn_text_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} button.dt-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} div.dt-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} a.dt-button' => 'color: {{VALUE}};',
				]
			]
		);
        
        $this->add_control(
			'table_btn_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} button.dt-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} div.dt-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} a.dt-button' => 'background-color: {{VALUE}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_btn_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} button.dt-button,{{WRAPPER}} div.dt-button,{{WRAPPER}} a.dt-button'
			]
		);
        
        $this->add_responsive_control(
			'table_btn_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.dt-button' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} div.dt-button' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} a.dt-button' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_btn_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} button.dt-button,{{WRAPPER}} div.dt-button,{{WRAPPER}} a.dt-button'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'tab_table_button_hover',
			[
				'label' => esc_html__( 'Hover', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_btn_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
                    '{{WRAPPER}} button.dt-button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} div.dt-button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} a.dt-button:hover' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_btn_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
                    '{{WRAPPER}} button.dt-button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} div.dt-button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} a.dt-button:hover' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_btn_hover_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} button.dt-button:hover,{{WRAPPER}} div.dt-button:hover,{{WRAPPER}} a.dt-button:hover'
			]
		);
        
        $this->add_responsive_control(
			'table_btn_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.dt-button:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} div.dt-button:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} a.dt-button:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_btn_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} button.dt-button:hover,{{WRAPPER}} div.dt-button:hover,{{WRAPPER}} a.dt-button:hover'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'table_btn_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->add_responsive_control(
			'table_btn_padding',
			[
				'label' => esc_html__( 'Padding', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.dt-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} div.dt-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} a.dt-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
        $this->add_responsive_control(
			'table_btn_margin',
			[
				'label' => esc_html__( 'Margin', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} button.dt-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} div.dt-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} a.dt-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        // section start
		$this->start_controls_section(
			'table_pagination_style_section',
			[
				'label' => esc_html__( 'Pagination', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'table_paging' => 'yes'
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_pagination_typography',
				
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button',
			]
		);
        
        $this->add_control(
			'table_pagination_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);  
        
        $this->start_controls_tabs( 'tabs_table_pagination_style' );
        
        $this->start_controls_tab(
			'tab_table_pagination_normal',
			[
				'label' => esc_html__( 'Normal', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_pagination_text_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_pagination_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_pagination_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button'
			]
		);
        
        $this->add_responsive_control(
			'table_pagination_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_pagination_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'tab_table_pagination_hover',
			[
				'label' => esc_html__( 'Hover', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_pagination_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:active' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_pagination_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:active' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_pagination_hover_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:hover,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:active'
			]
		);
        
        $this->add_responsive_control(
			'table_pagination_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:hover' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:active' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_pagination_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:hover,{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button:active'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'table_pagination_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->add_responsive_control(
			'table_pagination_padding',
			[
				'label' => esc_html__( 'Padding', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
        $this->add_responsive_control(
			'table_pagination_margin',
			[
				'label' => esc_html__( 'Margin', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_paginate .paginate_button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_search_style_section',
			[
				'label' => esc_html__( 'Search Box', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'table_searching' => 'yes'
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_search_typography',
				
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input'
			]
		);
        
        $this->add_control(
			'table_search_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		); 
        
        $this->start_controls_tabs( 'table_search_style' );
        
        $this->start_controls_tab(
			'table_search_normal',
			[
				'label' => esc_html__( 'Normal', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_search_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_search_placeholder_color',
			[
				'label' => esc_html__( 'Placeholder Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input::placeholder' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_search_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_search_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input'
			]
		);
        
        $this->add_responsive_control(
			'table_search_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_search_border_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input'
			]
		);
        
        $this->end_controls_tab();

		$this->start_controls_tab(
			'table_search_hover',
			[
				'label' => esc_html__( 'Focus', 'tmnet' ),
			]
		);
        
        $this->add_control(
			'table_search_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input:focus' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'table_search_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input:focus' => 'background-color: {{VALUE}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'table_search_hover_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input:focus'
			]
		);
        
        $this->add_responsive_control(
			'table_search_border_hover_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_filter input:focus' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				]
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'table_search_border_hover_shadow',
				'label' => esc_html__( 'Box Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input:focus'
			]
		);
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        
        $this->add_control(
			'input_hr_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'table_search_padding',
			[
				'label' => esc_html__( 'Padding', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
                    '{{WRAPPER}} .dataTables_wrapper .dataTables_filter input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
        );
        
        $this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'table_info_style_section',
			[
				'label' => esc_html__( 'Info', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'table_info' => 'yes'
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'table_info_typography',
				'selector' => '{{WRAPPER}} .dataTables_wrapper .dataTables_info',
			]
        );

        $this->add_control(
			'table_info_color',
			[
				'label' => esc_html__( 'Text Color', 'tmnet' ),
				'type' => Controls_Manager::COLOR, 
				'selectors' => [
					'{{WRAPPER}} .dataTables_wrapper .dataTables_info' => 'color: {{VALUE}};'
				]
			]
		);

		$this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'site_icon_style_section',
			[
				'label' => esc_html__( 'Site Icon', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE
			]
        );

		$this->add_responsive_control(
			'site_icon_column_size',
			[
				'label' => esc_html__( 'Column Size (px)', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 10,
				'max' => 512,
				'step' => 1,
				'default' => 80,
				'selectors' => [
					'{{WRAPPER}} table.dataTable tbody td.tmnet-site_icon,{{WRAPPER}} table.dataTable thead th.tmnet-site_icon' => 'width: {{VALUE}}px !important;'
				],
			]
		);

		$this->add_responsive_control(
			'site_icon_padding',
			[
				'label' => esc_html__( 'Column Padding (px)', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => '',
                'selectors' => [
					'{{WRAPPER}} table.dataTable tbody td.tmnet-site_icon' => 'padding: {{VALUE}}px !important;'
				],
			]
		);

		$this->add_control(
			'site_icon_size',
			[
				'label' => esc_html__( 'Icon Size (px)', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 10,
				'max' => 512,
				'step' => 1,
				'default' => 512
			]
		);

		$this->add_control(
			'site_icon_default',
			[
				'label' => esc_html__( 'Default Icon', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'site_icon_anim',
			[
				'label' => esc_html__( 'Hover Animation', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION
			]
        );

		$this->add_control(
			'site_icon_hr_1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'site_icon_border',
				'label' => esc_html__( 'Border', 'tmnet' ),
				'selector' => '{{WRAPPER}} img.tmnet-favicon',
			]
		);
        
        $this->add_responsive_control(
			'site_icon_radius',
			[
				'label' => esc_html__( 'Border Radius', 'tmnet' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} img.tmnet-favicon' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-right-radius: {{BOTTOM}}{{UNIT}};border-bottom-left-radius: {{LEFT}}{{UNIT}};'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'site_icon_shadow',
				'label' => esc_html__( 'Shadow', 'tmnet' ),
				'selector' => '{{WRAPPER}} img.tmnet-favicon',
			]
        );

		$this->end_controls_section();
        
        // section start
		$this->start_controls_section(
			'view_site_style_section',
			[
				'label' => esc_html__( 'View Site Link', 'tmnet' ),
                'tab' => Controls_Manager::TAB_STYLE
			]
        );

		$this->add_control(
			'link_label', [
				'label' => esc_html__( 'Link Label', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View Site ', 'tmnet' )
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'view_site_typography',
				'selector' => '{{WRAPPER}} table.dataTable tbody td.tmnet-view_site',
			]
        );

		$this->add_control(
			'new_tab',
			[
				'label' => esc_html__( 'Open Link in New Tab', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tmnet' ),
				'label_off' => esc_html__( 'No', 'tmnet' ),
				'return_value' => 'yes',
                'default' => 'yes'
			]
        );

		$this->add_control(
			'link_icon',
			[
				'label' => esc_html__( 'Icon', 'tmnet' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-long-arrow-alt-right',
					'library' => 'solid',
				],
			]
		);
        
        $this->end_controls_section();
	}
    
    protected function render() {
		if (is_multisite()) {
			$settings = $this->get_settings_for_display(); 
			$widget_id = $this->get_id();
			$limit = isset($settings['limit']) ? $settings['limit'] : 99;
			$exclude = $settings['exclude'];
			$include = $settings['include'];
			$site_order = $settings['site_order'] ? $settings['site_order'] : 'id';
			$site_orderby = $settings['site_orderby'] ? $settings['site_orderby'] : 'ASC';
			$paging = $settings['table_paging'] ? 'true' : 'false';
			$pagelength = $settings['table_page_length'];
			$info = $settings['table_info'] ? 'true' : 'false';
			$searching = $settings['table_searching'] ? 'true' : 'false';
			$ordering = $settings['table_ordering'] ? 'true' : 'false';
			$buttons = $settings['table_buttons'] ? 'true' : 'false';
			$link_label = $settings['link_label'];
			$new_tab = '_self';
			$icon_size = $settings['site_icon_size'] ? $settings['site_icon_size'] : 512;

			if ($settings['new_tab'] == 'yes') {
				$new_tab = '_blank';
			}

			if ($exclude) {
				$exclude = explode( ',', $exclude );
			} else {
				$exclude = array();
			}

			if ($include) {
				$include = explode( ',', $include );
			} else {
				$include = array();
			}

			$site_query = array(
				'orderby' => $site_orderby,
				'order'	=> $site_order,
				'public' => $settings['public'] == 'yes' ? 1 : 0,
				'archived' => $settings['archived'] == 'yes' ? 1 : 0,
				'mature' => $settings['mature'] == 'yes' ? 1 : 0,
				'spam' => $settings['spam'] == 'yes' ? 1 : 0,
				'deleted' => $settings['deleted'] == 'yes' ? 1 : 0,
				'number' => $limit,
				'offset' => 0,
				'site__not_in' => $exclude,
				'site__in' => $include
			);

			$get_sites = get_sites($site_query);
			?>
			<?php if ($settings['data_fields']) { ?>
			<div class="tmnet-table-container" data-paging="<?php echo esc_attr($paging); ?>" data-pagelength="<?php echo esc_attr($pagelength); ?>" data-info="<?php echo esc_attr($info); ?>" data-searching="<?php echo esc_attr($searching); ?>" data-ordering="<?php echo esc_attr($ordering); ?>" data-buttons="<?php echo esc_attr($buttons); ?>">
				<table id="tmnet-table-<?php echo $widget_id; ?>" class="tmnet-table cell-border" style="visibility:hidden;">
					<thead>
						<tr>
							<?php 
							foreach ( $settings['data_fields'] as $item ) { 
								if ($item['data_field'] == 'site_icon' || $item['data_field'] == 'view_site') {
									echo '<th class="elementor-repeater-item-' . $item['_id'] . ' tmnet-' . $item['data_field'] . '" data-orderable="false">' . $item['data_label'] . '</th>';
								} else {
									echo '<th class="elementor-repeater-item-' . $item['_id'] . ' tmnet-' . $item['data_field'] . '">' . $item['data_label'] . '</th>';
								}
							} ?>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($get_sites as $site) { 
							$site_id = get_object_vars($site)["blog_id"];
							$site_url = get_blog_details($site_id)->siteurl;
							$site_name = get_blog_details($site_id)->blogname;
							echo '<tr>';
							foreach ( $settings['data_fields'] as $item ) {
								if ($item['data_field'] == 'site_icon') {
									$link_class = 'tmnet-link';
									if ($settings['site_icon_anim']) {
										$link_class = 'tmnet-link elementor-animation-' . $settings['site_icon_anim'];
									}
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '" data-order="' . esc_attr($site_name) . '">';
									if ($settings['add_link'] == 'yes') {
										echo '<a class="' . esc_attr($link_class) . '" href="' . esc_url($site_url) . '" target="' . esc_attr($new_tab) . '">';
									}
									if (has_site_icon($site_id)) {
										echo '<img class="tmnet-favicon" src="' . get_site_icon_url($icon_size, '', $site_id) . '" alt="' . esc_attr($site_name) . '" />';
									} else if (!empty($settings['site_icon_default']['url'])) {
										echo '<img class="tmnet-favicon" src="' . esc_url($settings['site_icon_default']['url']) . '">';
									}
									if ($settings['add_link'] == 'yes') {
										echo '</a>';
									}
									echo '</td>';
								}
								if ($item['data_field'] == 'name') {
									if ($settings['add_link'] == 'yes') {
										echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '"><a href="' . esc_url($site_url) . '" target="' . esc_attr($new_tab) . '">' . esc_html($site_name) . '</a></td>';
									} else {
										echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '">' . esc_html($site_name) . '</td>';
									}
								}
								else if ($item['data_field'] == 'desc') {
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '">' .  esc_html(get_blog_option($site_id, 'blogdescription')) . '</td>';
								}
								else if ($item['data_field'] == 'post_count') {
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '">' .  esc_html(get_blog_details($site_id)->post_count) . '</td>';
								}
								else if ($item['data_field'] == 'user_count') {
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '">' .  esc_html(count_users('time', $site_id)['total_users']) . '</td>';
								}
								else if ($item['data_field'] == 'registered') {
									$registered = strtotime(get_blog_details($site_id)->registered);
									$registered_date = '';
									$date_format = $settings['date_format'];
									if (empty($date_format)) {
										$registered_date = human_time_diff($registered) . ' ' . esc_html__( 'ago', 'tmnet' );
									} else {
										$registered_date = date($date_format, $registered);
									}
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '" data-sort="' . esc_attr($registered) . '">' .  esc_html($registered_date) . '</td>';
								}
								else if ($item['data_field'] == 'last_updated') {
									$last_updated = strtotime(get_blog_details($site_id)->last_updated);
									$last_updated_date = '';
									$date_format = $settings['last_date_format'];
									if (empty($date_format)) {
										$last_updated_date = human_time_diff($last_updated) . ' ' . esc_html__( 'ago', 'tmnet' );
									} else {
										$last_updated_date = date($date_format, $last_updated);
									}
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '" data-sort="' . esc_attr($last_updated) . '">' .  esc_html($last_updated_date) . '</td>';
								}
								else if ($item['data_field'] == 'blog_option') {
									echo '<td class="elementor-repeater-item-' . esc_attr($item['_id']) . ' tmnet-' . $item['data_field'] . '">' .  esc_html(get_blog_option($site_id, $item['data_blog_opt'])) . '</td>';
								}
								else if ($item['data_field'] == 'view_site') { ?>
								<td class="elementor-repeater-item-<?php echo esc_attr($item['_id']); ?> tmnet-view_site"><a href="<?php echo esc_url($site_url); ?>" target="<?php echo esc_attr($new_tab); ?>">
								<?php echo esc_html($link_label); ?><?php \Elementor\Icons_Manager::render_icon( $settings['link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								</a></td>
								<?php }
							}
							echo '</tr>';
						} ?>
					</tbody>
				</table>   
			</div>
				<?php
			}
		} else {
			echo '<p><strong>' . esc_html__( 'TMNET requires WordPress multisite network.', 'tmnet' ) . '</strong></p>';
		}
	}
}