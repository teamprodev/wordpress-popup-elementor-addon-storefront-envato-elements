<?php
/**
 * Installer class
 *
 * @package InventSlider
 */
namespace DynamicLayers\InventSlider\Classes;

class Installer {

    /**
     * Run the installer
     *
     * @return void
     */
    public function run() {
        $this->add_version();
    }

    /**
     * Add time and version on DB
     */
    public function add_version() {
        $installed = get_option( 'invent_slider_installed' );

        if ( ! $installed ) {
            update_option( 'invent_slider_installed', time() );
        }

        update_option( 'invent_slider_version', INVENT_SLIDER_VERSION );
    }
}
