<?php /** @noinspection PhpUndefinedClassInspection */
/**
 * Avatar for Elementor
 * Avatar best solution for displaying information about the author of an article.
 * Exclusively on https://1.envato.market/avatar-elementor
 *
 * @encoding        UTF-8
 * @version         2.0.0
 * @copyright       (C) 2018 - 2021 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Nemirovskiy Vitaliy (nemirovskiyvitaliy@gmail.com), Alexander Khmelnitskiy (info@alexander.khmelnitskiy.ua), Cherviakov Vlad (vladchervjakov@gmail.com), Dmitry Merkulov (dmitry@merkulov.design)
 * @support         help@merkulov.design
 **/

namespace Merkulove\AvatarElementor;

/** Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
    header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

use Exception;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Merkulove\AvatarElementor\Unity\Plugin as UnityPlugin;

/** @noinspection PhpUnused */
/**
 * Avatar - Custom Elementor Widget.
 **/
class avatar_elementor extends Widget_Base {

    /**
     * Use this to sort widgets.
     * A smaller value means earlier initialization of the widget.
     * Can take negative values.
     * Default widgets and widgets from 3rd party developers have 0 $mdp_order
     **/
    public $mdp_order = 1;

    /**
     * Widget base constructor.
     * Initializing the widget base class.
     *
     * @access public
     * @throws Exception If arguments are missing when initializing a full widget instance.
     * @param array      $data Widget data. Default is an empty array.
     * @param array|null $args Optional. Widget default arguments. Default is null.
     *
     * @return void
     **/
    public function __construct( $data = [], $args = null ) {

        parent::__construct( $data, $args );

        wp_register_style( 'mdp-avatar-elementor-admin', UnityPlugin::get_url() . 'src/Merkulove/Unity/assets/css/elementor-admin' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_style( 'mdp-avatar-elementor', UnityPlugin::get_url() . 'css/avatar-elementor' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );

    }

    /**
     * Return a widget name.
     *
     * @return string
     **/
    public function get_name() {

        return 'mdp-avatar-elementor';

    }

    /**
     * Return the widget title that will be displayed as the widget label.
     *
     * @return string
     **/
    public function get_title() {

        return esc_html__( 'Avatar', 'avatar-elementor' );

    }

    /**
     * Set the widget icon.
     *
     * @return string
     */
    public function get_icon() {

        return 'mdp-avatar-elementor-widget-icon';

    }

    /**
     * Set the category of the widget.
     *
     * @return array with category names
     **/
    public function get_categories() {

        return [ 'general' ];

    }

    /**
     * Get widget keywords. Retrieve the list of keywords the widget belongs to.
     *
     * @access public
     *
     * @return array Widget keywords.
     **/
    public function get_keywords() {

        return [ 'Merkulove', 'Avatar', 'user', 'author', 'person', 'profile', 'admin' ];

    }

    /**
     * Get style dependencies.
     * Retrieve the list of style dependencies the widget requires.
     *
     * @access public
     *
     * @return array Widget styles dependencies.
     **/
    public function get_style_depends() {

        return [ 'mdp-avatar-elementor', 'mdp-avatar-elementor-admin' ];

    }

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @access public
     *
	 * @return array Element scripts dependencies.
	 **/
	public function get_script_depends() {

		return [];

    }

    /**
     * A group of controllers for setting styles.
     *
     * @param $name_Section - The name of the styles section.
     * @param string $css_class - Specifies one or more class names for an element.
     * @param array $condition - Interconnected controllers.
     * @param array $display - Determines which controllers to display. {
     *      @type $key 'margin'             => (boolean) - Use margin.
     *      @type $key 'padding'            => (boolean) - Use padding.
     *      @type $key 'color'              => (boolean) - Use color.
     *      @type $key 'typography'         => (boolean) - Use typography.
     *      @type $key 'text-shadow'        => (boolean) - Use text shadow.
     *      @type $key 'alignment'          => (boolean) - Use alignment.
     *      @type $key 'alignment-justify'  => (boolean) - Use alignment justify.
     *      @type $key 'background'         => (boolean) - Use background.
     *      @type $key 'border'             => (boolean) - Use border.
     *      @type $key 'border-radius'      => (boolean) - Use border radius.
     *      @type $key 'box-shadow'         => (boolean) - Use box shadow.
     *      @type $key 'css-filter'         => (boolean) - Use css filter.
     *
     * }
     *
     * @since 1.0.0
     * @access public
     *
     * @return void
     */
    public function get_settings_style_group( $name_Section, $css_class, $condition = [], $display = [] ) {

        if ( strpos( $css_class, ":hover" ) ) {
            $important = "!important";
        } else {
            $important = "";
        }

        /** Margin. */
        if ( isset($display['margin']) && $display['margin'] === true ) {
            $this->add_responsive_control(
                'avatar_' . $name_Section . '_margin',
                [
                    'label'      => esc_html__( 'Margin', 'avatar-elementor' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} ' . $css_class => 'margin: {{top}}{{unit}} {{right}}{{unit}} {{bottom}}{{unit}} {{left}}{{unit}};',
                    ],
                    'toggle'     => true,
                    'condition'  => $condition,
                ]
            );
        }

        /** Padding. */
        if ( isset($display['padding']) && $display['padding'] === true ) {
            $this->add_responsive_control(
                'avatar_' . $name_Section . '_padding',
                [
                    'label'      => esc_html__( 'Padding', 'avatar-elementor' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} ' . $css_class => 'padding: {{top}}{{unit}} {{right}}{{unit}} {{bottom}}{{unit}} {{left}}{{unit}};',
                    ],
                    'toggle'     => true,
                    'separator'  => 'after',
                    'condition'  => $condition,
                ]
            );
        }

        /** Text Color. */
        if ( isset($display['color']) && $display['color'] === true ) {
            $this->add_control(
                'avatar_' . $name_Section . '_text_color',
                [
                    'label'     => esc_html__( 'Color', 'avatar-elementor' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} ' . $css_class => 'color: {{VALUE}} ' . $important,
                    ],
                    'condition' => $condition,
                ]
            );
        }

        /** Typography */
        if ( isset($display['typography']) && $display['typography'] === true ) {
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'avatar_' . $name_Section . '_typography',
                    'label'     => esc_html__( 'Typography', 'avatar-elementor' ),
                    'scheme'    => Typography::TYPOGRAPHY_1,
                    'selector'  => '{{WRAPPER}} ' . $css_class,
                    'condition' => $condition,
                ]
            );
        }

        /** Text Shadow. */
        if ( isset($display['text-shadow']) && $display['text-shadow'] === true ) {
            $this->add_group_control(
                Group_Control_Text_Shadow::get_type(),
                [
                    'name'      => 'avatar_' . $name_Section . '_text_shadow',
                    'label'     => esc_html__( 'Text Shadow', 'avatar-elementor' ),
                    'selector'  => '{{WRAPPER}} ' . $css_class,
                    'condition' => $condition,
                ]
            );
        }

        /** Alignment. */
        if ( isset($display['alignment']) && $display['alignment'] === true ) {
            $this->add_responsive_control(
                'avatar_' . $name_Section . '_align',
                [
                    'label'     => esc_html__( 'Alignment', 'avatar-elementor' ),
                    'type'      => Controls_Manager::CHOOSE,
                    'options'   => [
                        'left'    => [
                            'title' => esc_html__( 'Left', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center'  => [
                            'title' => esc_html__( 'Center', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'right'   => [
                            'title' => esc_html__( 'Right', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                    ],
                    'default'   => 'center',
                    'selectors' => [
                        '{{WRAPPER}} ' . $css_class => 'text-align: {{header_align}};',
                    ],
                    'toggle'    => true,
                    'condition' => $condition,
                ]
            );
        }

        /** Alignment justify. */
        if ( isset($display['alignment-justify']) && $display['alignment-justify'] === true ) {
            $this->add_responsive_control(
                'avatar_' . $name_Section . '_align_justify',
                [
                    'label'     => esc_html__( 'Alignment', 'avatar-elementor' ),
                    'type'      => Controls_Manager::CHOOSE,
                    'options'   => [
                        'left'    => [
                            'title' => esc_html__( 'Left', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-left',
                        ],
                        'center'  => [
                            'title' => esc_html__( 'Center', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-center',
                        ],
                        'right'   => [
                            'title' => esc_html__( 'Right', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-right',
                        ],
                        'justify' => [
                            'title' => esc_html__( 'Justify', 'avatar-elementor' ),
                            'icon'  => 'fa fa-align-justify',
                        ],
                    ],
                    'default'   => 'center',
                    'selectors' => [
                        '{{WRAPPER}} ' . $css_class => 'text-align: {{header_align}};',
                    ],
                    'toggle'    => true,
                    'condition' => $condition,
                ]
            );
        }

        /** Background. */
        if ( isset($display['background']) && $display['background'] === true ) {
            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'      => 'avatar_' . $name_Section . '_background',
                    'label'     => esc_html__( 'Background', 'avatar-elementor' ),
                    'types'     => [ 'classic', 'gradient' ],
                    'separator' => 'before',
                    'selector'  => '{{WRAPPER}} ' . $css_class,
                    'condition' => $condition,
                ]
            );
        }

        /** Border. */
        if ( isset($display['border']) && $display['border'] === true ) {
            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name'      => 'avatar_' . $name_Section . '_border',
                    'label'     => esc_html__( 'Border', 'avatar-elementor' ),
                    'selector'  => '{{WRAPPER}} ' . $css_class,
                    'separator' => 'before',
                    'condition' => $condition,
                ]
            );
        }

        /** Border Radius. */
        if ( isset($display['border-radius']) && $display['border-radius'] === true ) {
            $this->add_responsive_control(
                'avatar_' . $name_Section . '_border_radius',
                [
                    'label'      => esc_html__( 'Border Radius', 'avatar-elementor' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} ' . $css_class => 'border-radius: {{top}}{{unit}} {{right}}{{unit}} {{bottom}}{{unit}} {{left}}{{unit}};',
                    ],
                    'separator'  => 'after',
                    'toggle'     => true,
                    'condition'  => $condition,
                ]
            );
        }

        /** Box Shadow. */
        if ( isset($display['box-shadow']) && $display['box-shadow'] === true ) {
            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                [
                    'name'      => 'avatar_' . $name_Section . '_box_shadow',
                    'label'     => esc_html__( 'Box Shadow', 'avatar-elementor' ),
                    'selector'  => '{{WRAPPER}} ' . $css_class,
                    'condition' => $condition,
                ]
            );
        }

        /** CSS filter. */
        if ( isset($display['css-filter']) && $display['css-filter'] === true ) {
            $this->add_group_control(
                Group_Control_Css_Filter::get_type(),
                [
                    'name'     => 'avatar_' . $name_Section . '_css_filter',
                    'label'    => esc_html__( 'CSS filter', 'avatar-elementor' ),
                    'selector' => '{{WRAPPER}} ' . $css_class,
                    'condition' => $condition,
                ]
            );
        }
    }

    /**
     *  Returns a list of users.
     *
     * @return array
     */
    private function get_users_list() {

        /** We get the data of all users. */
        $users = get_users();

        /** Contains a list of users. */
        $list_users = array();

        /**  */
        foreach ( $users as  $user ){
            $list_users[ $user->ID ] = $user->user_login;
        }

        return  $list_users;

    }

    /**
     * We determine the author of the post.
     *
     * @return integer
     */
    public function get_author_posts() {

        global $post;

        if ( $post ) {
            $user_id = $post->post_author;
        } else {
            $user_id = 'wordpress';
        }

        return $user_id;

    }

    /**
     *  Content controls for managing layouts.
     *
     * @return void
     */
    public function get_layout_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'layout_content',
            [
                'label' => esc_html__( 'Layout', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        /** Source. */
        $this->add_control(
            'avatar_source',
            [
                'label' => esc_html__( 'Source', 'avatar-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'profile',
                'options' => [
                    'custom'  => esc_html__( 'Custom', 'avatar-elementor' ),
                    'profile' => esc_html__( 'User profile', 'avatar-elementor' ),
                ],
            ]
        );

        /** List users. */
        $this->add_control(
            'avatar_list_users',
            [
                'label' => esc_html__( 'List users', 'avatar-elementor' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => false,
                'default' => $this->get_author_posts(),
                'options' => $this->get_users_list(),
                'condition' => ['avatar_source' => 'profile'],
            ]
        );

        $this->add_responsive_control(
            'avatar_box_align',
            [
                'label'     => esc_html__( 'Alignment', 'avatar-elementor' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start'         => [
                        'title' => esc_html__( 'Left', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center'        => [
                        'title' => esc_html__( 'Center', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'flex-end'           => [
                        'title' => esc_html__( 'Right', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-right',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space between', 'avatar-elementor' ),
                        'icon'  => 'fa fa-expand-arrows-alt',
                    ],
                    'space-around'  => [
                        'title' => esc_html__( 'Space around', 'avatar-elementor' ),
                        'icon'  => 'fa fa-compress-arrows-alt',
                    ],
                ],
                'default'   => 'space-around',
                'selectors' => [
                    '{{WRAPPER}} .mdp-avatar-container' => 'justify-content: {{value}};',
                ],
                'toggle'    => true,
            ]
        );

        $layout = new Repeater();

        /** Layout. */
        $layout->add_control(
            'avatar_layout',
            [
                'label' => esc_html__( 'Layout', 'avatar-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'userpicture',
                'options' => [
                    'userpicture'  => esc_html__( 'Profile Picture', 'avatar-elementor' ),
                    'name'         => esc_html__( 'Name', 'avatar-elementor' ),
                    'biography'    => esc_html__( 'Biography', 'avatar-elementor' ),
                    'posts'        => esc_html__( 'Posts', 'avatar-elementor' ),
                    'buttons'      => esc_html__( 'Buttons', 'avatar-elementor' ),
                ],
            ]
        );

        /** Layout list. */
        $this->add_control(
            'plan_layout',
            [
                'label' => esc_html__( 'Layout list', 'avatar-elementor' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $layout->get_controls(),
                'default' => [
                    ['avatar_layout' => 'userpicture'],
                    ['avatar_layout' => 'name'],
                    ['avatar_layout' => 'biography'],
                    ['avatar_layout' => 'posts'],
                    ['avatar_layout' => 'buttons'],
                ],
                'title_field' => 'Layout  - {{{avatar_layout}}}',
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Content controls for the user's photo.
     *
     * @return void
     */
    public function get_userpicture_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'userpicture_content',
            [
                'label' => esc_html__( 'Profile Picture', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [ 'avatar_source' => 'custom' ]
            ]
        );

        /** Author photo. */
        $this->add_control(
            'userpicture_image',
            [
                'label' =>esc_html__( 'Author photo', 'avatar-elementor' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => ['avatar_source' => 'custom'],
            ]
        );

        /** Image Size. */
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'userpicture_image_size',
                'exclude' => [ 'custom' ],
                'include' => [],
                'default' => 'large',
                'condition' => ['avatar_source' => 'custom'],
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Content controls for username.
     *
     * @return void
     */
    public function get_name_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'name_content',
            [
                'label' => esc_html__( 'Name', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        /** Name type. */
        $this->add_control(
            'name_type',
            [
                'label' => esc_html__( 'Name type', 'avatar-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'publicly',
                'options' => [
                    'publicly'  => esc_html__( 'Name publicly', 'avatar-elementor' ),
                    'first-last' => esc_html__( 'First & Last Name', 'avatar-elementor' ),
                    'nickname' => esc_html__( 'Nickname', 'avatar-elementor' ),
                ],
                'separator' => 'before',
                'condition' => ['avatar_source' => 'profile'],
            ]
        );

        /** Name text. */
        $this->add_control(
            'name_text',
            [
                'label' => esc_html__( 'Name', 'avatar-elementor' ),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Your Name', 'avatar-elementor' ),
                'placeholder' => esc_html__( 'Name', 'avatar-elementor' ),
                'condition' => ['avatar_source' => 'custom'],
            ]
        );

        /** Before text */
        $this->add_control(
            'name_before_text',
            [
                'label' => esc_html__( 'Before text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_html__( 'Before text', 'avatar-elementor' ),
            ]
        );

        /** After text. */
        $this->add_control(
            'name_after_text',
            [
                'label' => esc_html__( 'After text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_html__( 'After text', 'avatar-elementor' ),
            ]
        );

        /** HTML Tag. */
        $this->add_control(
            'name_title_tag',
            [
                'label' => esc_html__( 'HTML Tag', 'avatar-elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h3',
            ]
        );

        /** Link */
        $this->add_control(
            'name_link',
            [
                'label' => esc_html__( 'Link', 'avatar-elementor' ),
                'type' => Controls_Manager::URL,
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'description' => esc_html__( 'Link for the Name and Photo', 'avatar-elementor' ),
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Content controls for user biography.
     *
     * @return void
     */
    public function get_biography_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'biography_content',
            [
                'label' => esc_html__( 'Biography', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        /** Biography text. */
        $this->add_control(
            'biography_text',
            [
                'label' => esc_html__( 'Biography', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 10,
                'placeholder' => esc_html__( 'Biography', 'avatar-elementor' ),
                'condition' => ['avatar_source' => 'custom'],
            ]
        );

        /** Before text */
        $this->add_control(
            'biography_before_text',
            [
                'label' => esc_html__( 'Before text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_html__( 'Before text', 'avatar-elementor' ),
            ]
        );

        /** After text. */
        $this->add_control(
            'biography_after_text',
            [
                'label' => esc_html__( 'After text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_html__( 'After text', 'avatar-elementor' ),
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Content controls for user posts.
     *
     * @return void
     */
    public function get_post_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'posts_content',
            [
                'label' => esc_html__( 'Posts', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        /** Before text */
        $this->add_control(
            'posts_before_text',
            [
                'label' => esc_html__( 'Before text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'default' => esc_html__( 'Posts: ', 'avatar-elementor' ),
                'placeholder' => esc_html__( 'Before text', 'avatar-elementor' ),
            ]
        );

        /** After text. */
        $this->add_control(
            'posts_after_text',
            [
                'label' => esc_html__( 'After text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_html__( 'After text', 'avatar-elementor' ),
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Content controls for social buttons.
     *
     * @return  void
     */
    public function get_buttons_content_controls() {

        /** Start section */
        $this->start_controls_section(
            'buttons_content',
            [
                'label' => esc_html__( 'Buttons', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'buttons_align',
            [
                'label'     => esc_html__( 'Alignment', 'avatar-elementor' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start'         => [
                        'title' => esc_html__( 'Left', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center'        => [
                        'title' => esc_html__( 'Center', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'flex-end'           => [
                        'title' => esc_html__( 'Right', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-right',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space between', 'avatar-elementor' ),
                        'icon'  => 'fa fa-expand-arrows-alt',
                    ],
                    'space-around'  => [
                        'title' => esc_html__( 'Space around', 'avatar-elementor' ),
                        'icon'  => 'fa fa-compress-arrows-alt',
                    ],
                ],
                'default'   => 'space-around',
                'selectors' => [
                    '{{WRAPPER}} .mdp-avatar-box-buttons' => 'justify-content: {{value}};',
                ],
                'toggle'    => true,
            ]
        );

        $buttons = new Repeater();

        /** Button text */
        $buttons->add_control(
            'button_text_text',
            [
                'label' => esc_html__( 'Button text', 'avatar-elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Button text', 'avatar-elementor' ),
            ]
        );

        /** Link */
        $buttons->add_control(
            'button_link',
            [
                'label' => esc_html__( 'Link', 'avatar-elementor' ),
                'type' => Controls_Manager::URL,
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );

        /** Choose Icon */
        $buttons->add_control(
            'button_icon',
            [
                'label' => esc_html__( 'Choose Icon', 'avatar-elementor' ),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'default' => [
                    'value' => 'fas fa-bell',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $buttons->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Color', 'avatar-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'separator' => 'before'
            ]
        );

        $buttons->add_control(
            'button_bg',
            [
                'label'     => esc_html__( 'Background', 'avatar-elementor' ),
                'type'      => Controls_Manager::COLOR,
            ]
        );

        /** Buttons list. */
        $this->add_control(
            'buttons_list',
            [
                'label' => esc_html__( 'Buttons list', 'avatar-elementor' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $buttons->get_controls(),
                'title_field' => 'Buttons  - {{{button_text_text}}}',
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     *  Style controls for the user's photo.
     *
     * @return void
     */
    public function get_userpicture_style_controls() {

        /** Start section */
        $this->start_controls_section( 'style_userpicture',
            [
                'label' => esc_html__( 'Profile Picture', 'avatar-elementor' ), 'tab' => Controls_Manager::TAB_STYLE,
            ] );

        /** User picture width. */
        $this->add_responsive_control(
            'userpicture_width',
            [
                'label' => esc_html__( 'Profile Picture Width', 'avatar-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'separator' => 'after',
                'selectors'  => [
                    '{{WRAPPER}} .mdp-avatar-box-userpicture' => 'width: {{size}}{{unit}};',
                ],
            ]
        );

        $this->get_settings_style_group(
            'userpicture',
            '.mdp-avatar-box-userpicture',
            [],
            [
                'margin' => true,
                'padding' => true,
                'background' => true,
            ]
        );

        $this->add_responsive_control(
            'userpicture_box_align',
            [
                'label'     => esc_html__( 'Alignment', 'avatar-elementor' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start'         => [
                        'title' => esc_html__( 'Left', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center'        => [
                        'title' => esc_html__( 'Center', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'flex-end'           => [
                        'title' => esc_html__( 'Right', 'avatar-elementor' ),
                        'icon'  => 'fa fa-align-right',
                    ],
                ],
                'default'   => 'center',
                'selectors' => [
                    '{{WRAPPER}} .mdp-avatar-box-userpicture' => 'justify-content: {{value}};',
                ],
                'toggle'    => true,
            ]
        );

        $this->get_settings_style_group(
            'userpicture',
            '.mdp-avatar-box-userpicture',
            [],
            [
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
                'css-filter' => true
            ]
        );

        /** End section */
        $this->end_controls_section();
    }

    /**
     * Style controls for username.
     *
     * @return void
     */
    public function get_name_style_controls() {

        /** Start section */
        $this->start_controls_section(
            'style_name',
            [
                'label' => esc_html__( 'Name', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        /** Name width. */
        $this->add_responsive_control(
            'name_width',
            [
                'label' => esc_html__( 'Name Width', 'avatar-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .mdp-avatar-box-name' => 'width: {{size}}{{unit}};',
                ],
                'separator' => 'after'
            ]
        );

        /** Indentation. */
        $this->get_settings_style_group(
            'name',
            '.mdp-avatar-box-name',
            [],
            [
                'margin' => true,
            ]
        );

        /** Font formatting and indentation. */
        $this->get_settings_style_group(
            'name',
            '.mdp-avatar-name',
            [],
            [
                'padding' => true,
                'color' => true,
                'typography' => true,
                'text-shadow' => true,
            ]
        );

        /** Text alignment. */
        $this->get_settings_style_group(
            'name',
            '.mdp-avatar-box-name',
            [],
            [
                'alignment' => true,
            ]
        );

        /** Setting the background of the item. */
        $this->get_settings_style_group(
            'name',
            '.mdp-avatar-box-name',
            [],
            [
                'background' => true,
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Style controls for user biography.
     *
     * @return void
     */
    public function get_biography_style_controls() {

        /** Start section */
        $this->start_controls_section(
            'style_biography',
            [
                'label' => esc_html__( 'Biography', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        /** Biography width. */
        $this->add_responsive_control(
            'biography_width',
            [
                'label' => esc_html__( 'Biography Width', 'avatar-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'separator' => 'after',
                'selectors'  => [
                    '{{WRAPPER}} .mdp-avatar-box-biography' => 'width: {{size}}{{unit}};',
                ],
            ]
        );

        $this->get_settings_style_group(
            'biography',
            '.mdp-avatar-box-biography',
            [],
            [
                'margin' => true,
                'padding' => true,
                'color' => true,
                'typography' => true,
                'text-shadow' => true,
                'alignment-justify' => true,
                'background' => true,
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Style controls for user posts.
     *
     * @return void
     */
    public function get_posts_style_controls() {

        /** Start section */
        $this->start_controls_section(
            'style_posts',
            [
                'label' => esc_html__( 'Posts', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        /** Posts width. */
        $this->add_responsive_control(
            'posts_width',
            [
                'label' => esc_html__( 'Posts Width', 'avatar-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .mdp-avatar-box-posts' => 'width: {{size}}{{unit}};',
                ],
                'separator' => 'after'
            ]
        );

        /**  */
        $this->get_settings_style_group(
            'posts',
            '.mdp-avatar-box-posts',
            [],
            [
                'margin' => true,
            ]
        );


        $this->get_settings_style_group(
            'posts',
            '.mdp-avatar-posts',
            [],
            [
                'padding' => true,
                'color' => true,
                'typography' => true,
                'text-shadow' => true,
            ]
        );

        $this->get_settings_style_group(
            'posts',
            '.mdp-avatar-box-posts',
            [],
            [
                'alignment' => true,
            ]
        );

        $this->get_settings_style_group(
            'posts',
            '.mdp-avatar-box-posts',
            [],
            [
                'background' => true,
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
            ]
        );

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Style controls for social buttons.
     *
     * @return  void
     */
    public function get_buttons_style_controls() {

        /** Start section */
        $this->start_controls_section(
            'style_buttons',
            [
                'label' => esc_html__( 'Buttons', 'avatar-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        /** Buttons width. */
        $this->add_responsive_control(
            'buttons_width',
            [
                'label' => esc_html__( 'Buttons Width', 'avatar-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px' ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'separator' => 'after',
                'selectors'  => [
                    '{{WRAPPER}} .mdp-avatar-box-buttons' => 'width: {{size}}{{unit}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs-avatar-button');

        $this->start_controls_tab( 'tab_button_normal',
            [
                'label' => esc_html__('Normal', 'avatar-elementor')
            ]
        );

        $this->get_settings_style_group(
            'buttons',
            '.mdp-avatar-buttons',
            [],
            [
                'margin' => true,
                'padding' => true,
                'color' => true,
                'typography' => true,
                'text-shadow' => true,
                'alignment' => true,
                'background' => true,
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_button_hover',
            [
                'label' => esc_html__('Hover', 'avatar-elementor')
            ]
        );

        $this->get_settings_style_group(
            'buttons_hover',
            '.mdp-avatar-buttons:hover',
            [],
            [
                'margin' => true,
                'padding' => true,
                'color' => true,
                'typography' => true,
                'text-shadow' => true,
                'alignment' => true,
                'background' => true,
                'border' => true,
                'border-radius' => true,
                'box-shadow' => true,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        /** End section */
        $this->end_controls_section();

    }

    /**
     * Add the widget controls.
     *
     * @since 1.0.0
     * @access protected
     *
     * @return void with category names
     **/
    protected function register_controls() {

        /**
         *  TAB: Content.
         */

        /** Layout section. */
        $this->get_layout_content_controls();

        /** User picture section. */
        $this->get_userpicture_content_controls();

        /** Name section. */
        $this->get_name_content_controls();

        /** Biography section. */
        $this->get_biography_content_controls();

        /** Posts Section */
        $this->get_post_content_controls();

        /** Buttons section. */
        $this->get_buttons_content_controls();

        /**
         *  TAB: Style.
         */

        /** Styles for the user photo section. */
        $this->get_userpicture_style_controls();

        /** Styles for username. */
        $this->get_name_style_controls();

        /** Styles for user biography. */
        $this->get_biography_style_controls();

        /** Styles for user posts. */
        $this->get_posts_style_controls();

        /** Styles for social buttons. */
        $this->get_buttons_style_controls();

    }

    /**
     * Photo of the author from the settings of the elementor.
     *
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_custom_img( $settings ) {

        $target = $settings['name_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['name_link']['nofollow'] ? ' rel="nofollow"' : '';
        ?>

        <div class="mdp-avatar-box-userpicture">

            <a href="<?php echo esc_url( $settings['name_link']['url'] ); ?>"
               class="mdp-avatar-userpicture"
                <?php echo esc_attr( $target ); ?> <?php echo esc_attr( $nofollow ); ?>>

                <?php
                echo Group_Control_Image_Size::get_attachment_image_html(
                    $settings,
                    'userpicture_image_size',
                    'userpicture_image'
                );
                ?>

            </a>

        </div>

        <?php
    }

    /**
     *  Photo of the author from the user profile.
     *
     * @param $user - User profile data.
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_profile_img( $user, $settings ) {

        $target = $settings['name_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['name_link']['nofollow'] ? ' rel="nofollow"' : '';
        ?>

        <div class="mdp-avatar-box-userpicture">

            <a href="<?php echo esc_url( $settings['name_link']['url'] ); ?>"
               class="mdp-avatar-userpicture" <?php echo esc_attr( $target ); ?> <?php echo esc_attr( $nofollow ); ?>>

                <img src="<?php echo $user !== 'wordpress' ? esc_url( get_avatar_url( $user->ID ) ) : esc_url( Utils::get_placeholder_image_src() ); ?>"
                     alt="<?php $user !== 'wordpress' ? esc_attr_e( $user->user_nicename ) : esc_attr_e( $user ) ; ?>" />

            </a>

        </div>

        <?php
    }

    /**
     * Name of the author from the text field.
     *
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_custom_user_name( $settings ) {

        $target = $settings['name_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['name_link']['nofollow'] ? ' rel="nofollow"' : '';

        if( !empty($settings['name_text']) || !empty($settings['name_before_text'])
            || !empty($settings['name_after_text']) ) :
            ?>

            <div class="mdp-avatar-box-name">

            <<?php echo esc_attr( $settings['name_title_tag'] ); ?> class="mdp-avatar-title">

            <a href="<?php echo esc_url($settings['name_link']['url']); ?>"
               class="mdp-avatar-name" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>

                <?php if( !empty($settings['name_before_text']) ) : ?>

                    <span><?php echo esc_html( $settings['name_before_text'] ); ?></span>

                <?php endif; ?>

                <?php
                if( !empty($settings['name_text']) ) {
                    echo esc_html( $settings['name_text'] );
                }
                ?>

                <?php if( !empty($settings['name_after_text']) ) :?>

                    <span><?php echo esc_html( $settings['name_after_text']  ); ?></span>

                <?php endif; ?>

            </a>

            </<?php echo esc_attr( $settings['name_title_tag'] ); ?>>

            </div>

        <?php

        endif;

    }

    /**
     * Author name from user profile.
     *
     * @param $user - User profile data.
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_profile_user_name( $user, $settings ) {

        $target = $settings['name_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['name_link']['nofollow'] ? ' rel="nofollow"' : '';
        ?>

        <div class="mdp-avatar-box-name">

        <<?php echo esc_attr( $settings['name_title_tag'] ); ?> class="mdp-avatar-title">

        <a href="<?php echo esc_url($settings['name_link']['url']); ?>" class="mdp-avatar-name" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>

            <?php if( !empty( $settings['name_before_text'] ) ) : ?>

                <span><?php echo esc_html( $settings['name_before_text'] ); ?></span>

            <?php endif; ?>

            <?php
            if( 'publicly' === $settings['name_type'] ){
                echo $user !== 'wordpress' ? $user->display_name : esc_html__( $user );
            } elseif ( 'first-last' === $settings['name_type'] ) {
                echo $user !== 'wordpress' ? $user->user_firstname . ' '. $user->user_lastname : esc_html__( $user );
            } elseif ( 'nickname' === $settings['name_type'] ) {
                echo $user !== 'wordpress' ? $user->user_nicename : esc_html__( $user );
            }
            ?>

            <?php if( !empty( $settings['name_after_text'] ) ) : ?>

                <span><?php echo esc_html( $settings['name_after_text']  ); ?></span>

            <?php endif; ?>

        </a>

        </<?php echo esc_attr( $settings['name_title_tag'] ); ?>>

        </div>

        <?php
    }

    /**
     * Biography from a custom text field.
     *
     * @param $settings - Get all the values from the admin panel.
     *
     */
    private function get_custom_biography( $settings ) {

        if( !empty($settings['biography_text']) || !empty($settings['biography_before_text'])
            || !empty($settings['biography_after_text']) ) :

            ?>

            <div class="mdp-avatar-box-biography">

                <p class="mdp-avatar-biography">

                    <?php if( !empty($settings['biography_before_text']) ) : ?>

                        <span><?php echo esc_html( $settings['biography_before_text'] ); ?></span>

                    <?php endif; ?>

                    <?php echo esc_html( $settings['biography_text'] ); ?>

                    <?php if( !empty($settings['biography_after_text']) ) : ?>

                        <span><?php echo esc_html( $settings['biography_after_text'] ); ?></span>

                    <?php endif; ?>

                </p>

            </div>

        <?php

        endif;

    }

    /**
     * Biography from user profile.
     *
     * @param $user - User profile data.
     * @param $settings - Get all the values from the admin panel.
     *
     */
    private function get_profile_biography( $user, $settings ) {

        if( !empty($user->user_description) || !empty($settings['biography_before_text'])
            || !empty($settings['biography_after_text']) ) :

            ?>

            <div class="mdp-avatar-box-biography">

                <p class="mdp-avatar-biography">

                    <?php if( !empty($settings['biography_before_text']) ) : ?>

                        <span><?php echo esc_html( $settings['biography_before_text'] ); ?></span>

                    <?php endif; ?>

                    <?php echo esc_html( $user->user_description ); ?>

                    <?php if( !empty($settings['biography_after_text']) ) : ?>

                        <span><?php echo esc_html( $settings['biography_after_text'] ); ?></span>

                    <?php endif; ?>

                </p>

            </div>

        <?php

        endif;

    }

    /**
     * The number of posts posted by the user.
     *
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_count_posts( $settings ) {

        $count_posts = count_user_posts( $settings['avatar_list_users'], 'post', true );
        ?>

        <div class="mdp-avatar-box-posts">

            <span class="mdp-avatar-posts">
			<?php

            if( !empty($settings['posts_before_text']) ) :
                echo esc_html( $settings['posts_before_text'] );
            endif;

            echo esc_html( $count_posts );

            if( !empty($settings['posts_after_text']) ) :
                echo esc_html( $settings['posts_after_text'] );
            endif;

            ?>
            </span>

        </div>

        <?php
    }

    /**
     * Links to the user's social network.
     *
     * @param $settings - Get all the values from the admin panel.
     */
    private function get_buttons( $settings ) {

        $buttons = $settings['buttons_list'];
        ?>

        <div class="mdp-avatar-box-buttons">

            <?php foreach ( $buttons as $button ) :

                $inline_CSS = $button[ 'button_color' ] ? "color: " . $button[ 'button_color' ] . "; " : "";
                $inline_CSS .= $button[ 'button_bg' ] ? "background-color: " . $button[ 'button_bg' ] . ";" : "";

                ?>
                <a href="<?php echo esc_html( $button['button_link']['url'] ); ?>" class="mdp-avatar-buttons" style="<?php esc_attr_e( $inline_CSS ); ?>">

                    <i aria-hidden="true" class="<?php echo esc_attr( $button['button_icon']['value'] ); ?>"></i>

                    <?php echo esc_html( $button['button_text_text'] ); ?>
                </a>
            <?php endforeach; ?>

        </div>

        <?php
    }

    /**
     *  We display information about the author in a given sequence.
     *
     * @param $LayoutSortable - An array of layouts in a specific order.
     * @param $settings - User profile data.
     */
    private function get_custom_avatar( $LayoutSortable, $settings ) {

        $user = get_userdata( $settings['avatar_list_users'] );

        /** We list the layouts in the given order. */
        foreach ($LayoutSortable as $val) {

            switch ( $val['name'] ) {
                case 'userpicture':
                    echo $this->get_custom_img( $settings );
                    break;
                case 'name':
                    echo $this->get_custom_user_name( $settings );
                    break;
                case 'biography':
                    echo $this->get_custom_biography( $settings );
                    break;
                case 'posts':
                    echo $this->get_count_posts( $settings );
                    break;
                case 'buttons':
                    echo $this->get_buttons( $settings );
                    break;
                default:
                    echo "You have not added any items to the layout.";
            }

        }

    }

    /**
     * We display information about the author in a given sequence.
     *
     * @param $LayoutSortable - An array of layouts in a specific order.
     * @param $settings - User profile data.
     */
    private function get_profile_avatar( $LayoutSortable, $settings ) {

        $user = $settings['avatar_list_users'] !== 'wordpress' ? get_userdata( $settings['avatar_list_users'] ) : $settings['avatar_list_users'];

        /** We list the layouts in the given order. */
        foreach ($LayoutSortable as $val) {

            switch ( $val['name'] ) {
                case 'userpicture':
                    echo $this->get_profile_img( $user, $settings );
                    break;
                case 'name':
                    echo $this->get_profile_user_name( $user, $settings );
                    break;
                case 'biography':
                    echo $this->get_profile_biography( $user, $settings );
                    break;
                case 'posts':
                    echo $this->get_count_posts( $settings );
                    break;
                case 'buttons':
                    echo $this->get_buttons( $settings );
                    break;
                default:
                    echo "You have not added any items to the layout.";
            }

        }

    }

    /**
     * We return an array with the names of the layouts.
     *
     * @param $settings - we get an array with all the data.
     *
     * @return array
     */
    private function get_LayoutSortable( $settings ) {

        /** We get all the data on the lists of layouts. */
        $layout = $settings['plan_layout'];

        /** An array in which the names of the layouts and their width will be stored. */
        $res = array();

        /** We write the names of the layouts and their width into an array. */
        foreach ($layout as $key => $val){

            $res[] = [ 'name' => $val['avatar_layout'] ];
        }

        return $res;

    }

    /**
     * Render Frontend Output. Generate the final HTML on the frontend.
     *
     * @since 1.0.0
     * @access protected
     **/
    protected function render() {

        /** Get all the values from the admin panel. */
        $settings = $this->get_settings_for_display();

        /** We return an array with the names of the layouts and their width. */
        $LayoutSortable = $this->get_LayoutSortable( $settings );

        ?>

        <div class="mdp-avatar-container">

            <?php
            if( 'custom' === $settings['avatar_source'] ) {

                $this->get_custom_avatar( $LayoutSortable, $settings );

            } elseif( 'profile' === $settings['avatar_source'] ) {

                $this->get_profile_avatar( $LayoutSortable, $settings );

            }
            ?>

        </div>

        <?php
    }

    /**
     * Return link for documentation
     * Used to add stuff after widget
     *
     * @since 1.0.0
     * @access public
     **/
    public function get_custom_help_url() {
        return 'https://docs.merkulov.design/tag/avatar/';
    }

}
