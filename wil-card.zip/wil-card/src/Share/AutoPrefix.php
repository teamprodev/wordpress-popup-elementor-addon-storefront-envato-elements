<?php

namespace WilokeCard\Share;

class AutoPrefix
{
	public static function namePrefix($name)
	{
		return strpos($name, WILOKE_WILOKECARD_PREFIX) === 0 ? $name : WILOKE_WILOKECARD_PREFIX . $name;
	}

	public static function removePrefix(string $name): string
	{
		if (strpos($name, WILOKE_WILOKECARD_PREFIX) === 0) {
			$name = str_replace(WILOKE_WILOKECARD_PREFIX, '', $name);
		}

		return $name;
	}
}