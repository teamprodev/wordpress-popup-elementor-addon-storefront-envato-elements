<?php
/**
 * Plugin Name: Affiliate Elements for Elementor
 * Description: Affiliate Elements for Elementor is an affiliate marketing featured rich WordPress plugin having all the required features in one place.
 * Plugin URI: https://www.techeshta.com/product/affiliate-elements-for-elementor/
 * Author: Techeshta
 * Version: 1.1
 * Author URI: https://www.techeshta.com
 *
 * Text Domain: affiliate-elements-for-elementor
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Define Plugin URL and Directory Path
 */
define('AEFE_URL', plugins_url('/', __FILE__));  // Define Plugin URL
define('AEFE_PATH', plugin_dir_path(__FILE__));  // Define Plugin Directory Path
define('AEFE_DOMAIN', 'affiliate-elements-for-elementor'); // Define Text Domain

/**
 * Main Plugin affiliate-elements-for-elementor class.
 * 
 * @access public
 * @since  1.0
 */
if (!class_exists('affiliate_elements_elementor')) :
class affiliate_elements_elementor {

	/**
     * AEFE constructor.
     * The main plugin actions registered for WordPress
     * 
     * @access public
     * @since  1.0
    */
    public function __construct() {
		$this->hooks();
		require_once AEFE_PATH . 'widgets/elementor-helper.php';
		require_once AEFE_PATH . 'widgets/elementor-dependency.php';
    }

	/**
	* Initialize
	*/
	public function hooks() {
        add_action('elementor/widgets/widgets_registered', array($this, 'affiliate_elements_widget_register'));
        add_action('wp_enqueue_scripts', array($this, 'affiliate_elements_widget_script_register'));
        add_action('plugins_loaded', array($this, 'affiliate_elements_plugin_load'));
	}

	/**
	 * Register the widgtes file in elementor widgtes.
	 */
	public function affiliate_elements_widget_register() {
		require_once AEFE_PATH . 'widgets/call-to-action.php';
		require_once AEFE_PATH . 'widgets/pros-and-cons.php';
		require_once AEFE_PATH . 'widgets/comparison-table.php';
		require_once AEFE_PATH . 'widgets/featured-product.php';
		require_once AEFE_PATH . 'widgets/product-listing.php';
		require_once AEFE_PATH . 'widgets/top-pick.php';
		require_once AEFE_PATH . 'widgets/single-product.php';
		require_once AEFE_PATH . 'widgets/features-list.php';
		require_once AEFE_PATH . 'widgets/notice-box.php';
		require_once AEFE_PATH . 'widgets/product-rating.php';
	}

	/**
	 * Load scripts and styles
	 */
	public function affiliate_elements_widget_script_register() {
		wp_register_style('aefe-call-to-action', AEFE_URL . 'assets/css/call-to-action.css', false);
		wp_register_style('aefe-pros-and-cons', AEFE_URL . 'assets/css/pros-and-cons.css', false);
		wp_register_style('aefe-comparison-table', AEFE_URL . 'assets/css/comparison-table.css', false);
		wp_register_script('aefe-comparison-table-js', AEFE_URL . 'assets/js/comparison-table.js', array('jquery'), false, true);
		wp_register_style('aefe-featured-product', AEFE_URL . 'assets/css/featured-product.css', false);
		wp_register_style('aefe-product-listing', AEFE_URL . 'assets/css/product-listing.css', false);
		wp_register_script('aefe-product-listing-js', AEFE_URL . 'assets/js/product-listing.js', array('jquery'), false, true);
		wp_register_style('aefe-top-pick', AEFE_URL . 'assets/css/top-pick.css', false);
		wp_register_style('aefe-single-product', AEFE_URL . 'assets/css/single-product.css', false);
		wp_register_style('aefe-features-list', AEFE_URL . 'assets/css/features-list.css', false);
		wp_register_style('aefe-notice-box', AEFE_URL . 'assets/css/notice-box.css', false);
		wp_register_script('aefe-notice-box-js', AEFE_URL . 'assets/js/notice-box.js', array('jquery'), false, true);
		wp_register_style('aefe-product-rating', AEFE_URL . 'assets/css/product-rating.css', false);
	}

	/**
	 * Check for Elementor
	 */
	public function affiliate_elements_plugin_load() {
		// Load plugin textdomain
		load_plugin_textdomain('AEFE_DOMAIN');

		if (!did_action('elementor/loaded')) {
			add_action('admin_notices', array($this, 'affiliate_elements_widget_fail_load'));
			return;
		}
	}

	/**
	 * This notice will appear if Elementor is not installed or activated or both
	 */
	public function affiliate_elements_widget_fail_load() {
		$screen = get_current_screen();
		if (isset($screen->parent_file) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id) {
			return;
		}

		$plugin = 'elementor/elementor.php';

		if (affiliate_elements_elementor_installed()) {
			if (!current_user_can('activate_plugins')) {
				return;
			}
			$activation_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin);

			$message = '<p><strong>' . esc_html__('Affiliate Elements for Elementor', AEFE_DOMAIN).'</strong>'. esc_html__(' not working because you need to activate the Elementor plugin.', AEFE_DOMAIN) . '</p>';
			$message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__('Activate Elementor Now', AEFE_DOMAIN)) . '</p>';
		} else {
			if (!current_user_can('install_plugins')) {
				return;
			}

			$install_url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=elementor'), 'install-plugin_elementor');

			$message = '<p><strong>' . esc_html__('Affiliate Elements for Elementor', AEFE_DOMAIN).'</strong>'. esc_html__(' not working because you need to install the Elementor plugin', AEFE_DOMAIN) . '</p>';
			$message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__('Install Elementor Now', AEFE_DOMAIN)) . '</p>';
		}

		echo esc_html__('<div class="error"><p>' . $message . '</p></div>');
	}
}
endif;

/**
 * Initialize Plugin Class
 *
 * @access public
 * @since  1.0
 */
new affiliate_elements_elementor();