<!-- Start Featured Product Style 1 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-fp fp-style-1">
    <div class="fp-container">
        <div class="elementor--star-style-star_unicode fp-rating">
            <div class="elementor-star-rating"><?php echo $this->render_stars($icon); ?></div>
        </div>
        <div class="fp-title"><?php esc_html_e($settings['fp_title']); ?></div><?php 
        if(!empty($settings['fp_price'])){ ?>
            <div class="fp-price-container">
                <span class="fp-price"><?php esc_html_e($settings['fp_price']); ?></span><?php 
                if(!empty($settings['fp_original_price'])){ ?>
                    <span class="fp-original-price"><?php esc_html_e($settings['fp_original_price']); ?></span><?php 
                } ?>
            </div><?php
        } ?>
        <img class="fp-image" src="<?php echo esc_url($settings['fp_image']['url']); ?>" /><?php 
        if($settings['fp_content_type'] === 'desc'){ ?>
            <div class="fp-content"><?php esc_html_e($settings['fp_description']); ?></div><?php 
        } else { ?>
            <ul class="fp-lists">
            <?php foreach ($settings['fp_product_lists'] as $lists => $list) {?>
                <li class="fp-list">
                    <span class="fp-list-icon"><?php Icons_Manager::render_icon($settings['fp_list_icon'], [ 'aria-hidden' => 'true' ]); ?></span>
                    <span class="fp-content"><?php esc_html_e($list['fp_product_list']); ?></span>
                </li>
            <?php } ?>
            </ul><?php
        } ?>
    </div>
    <div class="fp-button-container">
        <a class="fp-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel); ?>><?php esc_html_e($settings['fp_button']); ?></a>
    </div>
    <?php echo $this->render_ribbons(); ?>
</div>
<!-- End Featured Product Style 1 -->