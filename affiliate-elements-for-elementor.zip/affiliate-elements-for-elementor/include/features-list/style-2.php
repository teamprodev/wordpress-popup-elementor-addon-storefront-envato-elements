<!-- Start Features List Style 2 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-fl fl-style-2">
    <div class="fl-container">
        <<?php esc_attr_e($title_tag); ?> class="fl-title"><?php esc_html_e($settings['fl_title']); ?></<?php esc_attr_e($title_tag); ?>>
        <div class="fl-content-container">
            <ul class="features-list <?php esc_attr_e($settings['fl_list_style']); ?>">
				<?php foreach ($settings['fl_icon_list'] as $pros => $pro) {?>
					<li class="fl-content"><?php Icons_Manager::render_icon($pro['fl_selected_icon'], [ 'aria-hidden' => 'true' ]); ?><?php esc_html_e($pro['fl_text']); ?></li>
				<?php } ?>
            </ul>
        </div>
        <div class="fl-content-grid">
            <div class="fl-image-container">
                <img class="fl-image" src="<?php echo esc_url( $settings['fl_image']['url'] ); ?>" />
            </div>
        </div>
    </div>
</div>
<!-- End Features List Style 2 -->