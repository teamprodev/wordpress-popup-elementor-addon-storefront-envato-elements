<!-- Start Notice Box Style 1 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-nb nb-style-1">
    <div class="nb-container">
        <div class="nb-content-container">
			<div class="notice-box-wrapper">
                <div class="notice-box">
                    <div class="notice-box-icon">
                        <?php Icons_Manager::render_icon($settings['nb_selected_icon'], [ 'aria-hidden' => 'true' ]); ?>
                    </div>
                    <div class="notice-box-content">
                        <div class="notice-box-title">
                            <<?php esc_attr_e($title_tag); ?> class="nb-title"><?php esc_html_e($settings['nb_title']); ?></<?php esc_attr_e($title_tag); ?>>
                        </div>
                        <div class="notice-box-description">
                            <?php esc_html_e($settings['nb_text']); ?>
                        </div>
                    </div>
                </div>
                <div class="nb-close-btn">
                    <i class="fa fa-times" aria-hidden="true"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Notice Box Style 1 -->