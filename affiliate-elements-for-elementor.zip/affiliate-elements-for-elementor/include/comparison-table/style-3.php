<!-- Start Comparison Table Style 3 -->
<div class="affiliate-elements-ct ct-style-3">
    <ul><?php
        for ( $i = 1; $i <= $settings['ct_product_count']; $i++ ) { ?>
            <li class="ct-product-heading ct-product-<?php esc_attr_e($i); ?>"><?php esc_html_e($settings['ct_product_title_' . $i]); ?></li>
        <?php } ?>
    </ul>
    <table>
        <tbody>
            <tr class="ct-header">
                <td class="ct-features-heading"><?php esc_html_e($settings['ct_feature_heading']); ?></td>
                <?php for ( $i = 1; $i <= $settings['ct_product_count']; $i++ ) { ?>
                    <td class="ct-product-heading ct-product-<?php esc_attr_e($i); ?>">
                        <div class="ct-count-box">
                            <div class="ct-count"><?php esc_html_e($i); ?></div>
                        </div>
                        <?php if (!empty($settings['ct_product_title_' . $i])) { ?>
                            <div class="ct-product-title"><?php esc_html_e($settings['ct_product_title_' . $i]); ?></div>
                        <?php } ?>
                        <?php if (!empty($settings['ct_product_image_' . $i]['url'])) { ?>
                            <img class="ct-product-img" src="<?php echo esc_url($settings['ct_product_image_' . $i]['url']); ?>" />
                        <?php } ?>
                    </td>
                <?php } ?>
            </tr>
            <?php
            $count = count( $settings['ct_feature_list'] );
            for ( $x = 1; $x <= $count; $x++ ) { ?>
                <tr>
                    <td class="ct-feature-heading"><?php esc_html_e($settings['ct_feature_list'][ $x - 1 ]['ct_feature']); ?></td>
                    <?php for ( $j = 1; $j <= $settings['ct_product_count']; $j++ ) { ?>
                        <td class="ct-feature ct-product-<?php esc_attr_e($j); ?>"><?php
                        if ( count( $settings[ 'ct_feature_list_' . $j ] ) >= $x ) {
                            if ( $settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type'] !== 'text' && $settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type'] !== 'icon') {
                                if ( $settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type'] === 'fa fa-close' ) { ?>
                                    <i class="ct-mark-no <?php esc_attr_e($settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type']); ?>"></i><?php
                                } else { ?>
                                    <i class="ct-mark-yes <?php esc_attr_e($settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type']); ?>"></i><?php
                                }
                            } elseif ($settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_content_type'] === 'icon') {
                                ?><i class="<?php esc_attr_e($settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_feature_icon']['value']);?>"></i><?php
                            } else {
                                esc_html_e($settings[ 'ct_feature_list_' . $j ][ $x - 1 ]['ct_feature_text']);
                            }
                        } else {
                            echo '';
                        } ?></td>
                    <?php } ?>
                </tr>
            <?php } ?>
            <tr>
                <td class="ct-feature-heading ct-feature-heading-button"><?php esc_html_e($settings['ct_feature_heading_button']); ?></td>
                <?php for ( $i = 1; $i <= $settings['ct_product_count']; $i++ ) { ?>
                    <td class="ct-feature ct-product-price ct-product-<?php esc_attr_e($i); ?>">
                        <?php esc_html_e($settings['ct_product_price_' . $i]); 
                        $button_link    = $settings['ct_product_link_' . $i]['url'];
                        $target         = $settings['ct_product_link_' . $i]['is_external'] ? ' target="_blank"' : '';
                        $rel            = $settings['ct_product_link_' . $i]['nofollow'] ? ' rel="nofollow"' : ''; ?>
                        <div class="ct-feature-button ct-product-<?php esc_attr_e($i); ?>">
                            <?php if ( $settings[ 'ct_button_text_' . $i ] !== '' ) { ?>
                                <a class="ct-product-btn" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel);?>><?php esc_html_e($settings['ct_button_text_' . $i]); ?></a>
                            <?php } ?>
                        </div>
                    </td>
                <?php } ?>
            </tr>
        </tbody>
    </table>
</div>
<!-- End Comparison Table Style 3 -->