<!-- Start Pros and Cons Style 3 -->
<div class="affiliate-elements-pac">
    <div class="pac-style-3">
        <div class="pac-col-mid-res">
            <h2 class="pac-mid-title"><?php esc_html_e($settings['pac_title']); ?></h2>
            <div class="pac-image-container">
                <img class="pac-image" src="<?php echo esc_url( $settings['pac_image']['url'] ); ?>" />
            </div>
        </div>
        <div class="pac-col-pros">
            <div class="pac-title-container">
                <h2 class="pac-pros-title"><?php esc_html_e($settings['pac_pros_title']); ?></h2>
            </div>
            <ol class="pac-pros-list">
            <?php foreach ($settings['pros_lists'] as $pros => $pro) {?>
                <li class="pac-pros-content pac-order-alignment-<?php esc_attr_e($settings['pac_order_alignment']); ?>">
                    <?php esc_html_e($pro['pros_content']); ?>
                </li>
            <?php } ?>
            </ol>
        </div>
        <div class="pac-col-mid">
            <h2 class="pac-mid-title"><?php esc_html_e($settings['pac_title']); ?></h2>
            <div class="pac-image-container">
                <img class="pac-image" src="<?php echo esc_url($settings['pac_image']['url']); ?>" />
            </div>
        </div>
        <div class="pac-col-cons">
            <div class="pac-title-container">
                <h2 class="pac-cons-title"><?php esc_html_e($settings['pac_cons_title']); ?></h2>
            </div>
            <ol class="pac-cons-list">
            <?php foreach ($settings['cons_lists'] as $cons => $con) {?>
                <li class="pac-cons-content pac-order-alignment-<?php esc_attr_e($settings['pac_order_alignment']); ?>">
                    <?php esc_html_e($con['cons_content']); ?>
                </li>
            <?php } ?>
            </ol>
        </div>
    </div>
</div>
<!-- End Pros and Cons Style 3 -->