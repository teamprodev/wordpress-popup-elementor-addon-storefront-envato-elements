<!-- Start Pros and Cons Style 2 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-pac">
    <div class="pac-style-2">
        <div class="pac-col-pros">
            <div class="pac-pros-icon-container">
                <div class="pac-pros-icon">
                    <?php Icons_Manager::render_icon($settings['pac_pro_icon'], [ 'aria-hidden' => 'true' ]); ?>
                </div>
            </div>
            <div class="pac-title-container">
                <h2 class="pac-pros-title"><?php esc_html_e($settings['pac_pros_title']); ?></h2>
            </div>
            <ol class="pac-pros-list">
            <?php foreach ($settings['pros_lists'] as $pros => $pro) {?>
                <li class="pac-pros-content"><?php Icons_Manager::render_icon($settings['pac_pro_list_icon'], [ 'aria-hidden' => 'true' ]); ?><?php esc_html_e($pro['pros_content']); ?></li>
            <?php } ?>
            </ol>
        </div>
        <div class="pac-col-cons">
            <div class="pac-cons-icon-container">
                <div class="pac-cons-icon">
                    <?php Icons_Manager::render_icon($settings['pac_cons_icon'], [ 'aria-hidden' => 'true' ]); ?>
                </div>
            </div>
            <div class="pac-title-container">
                <h2 class="pac-cons-title"><?php esc_html_e($settings['pac_cons_title']); ?></h2>
            </div>
            <ol class="pac-cons-list">
            <?php foreach ($settings['cons_lists'] as $cons => $con) {?>
                <li class="pac-cons-content"><?php Icons_Manager::render_icon($settings['pac_cons_list_icon'], [ 'aria-hidden' => 'true' ]); ?><?php esc_html_e($con['cons_content']); ?></li>
            <?php } ?>
            </ol>
        </div>
    </div>
</div>
<!-- End Pros and Cons Style 2 -->