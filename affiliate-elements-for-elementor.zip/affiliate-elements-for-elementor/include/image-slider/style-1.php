<!-- Start Image Slider Style 1 -->
<?php 
$this->add_render_attribute(
            'ae_slider_setting',
            [
                'id'                   => 'image-slider-' . $this->get_id(),
            ]
        ); ?>

<div class="affiliate-elements-is is-style-1" <?php echo $this->get_render_attribute_string( 'ae_slider_setting' ); ?>>
    <div class="is-container">
        <div class="is-content-grid">
            <div class="dsm_product_slider">
                <div class="main-img">
                    <div class="single-img-slider">
                    <?php foreach ( $settings['is_carousel'] as $index => $attachment ) { ?>
                        <div class="item">
                            <img class="size-full" src="<?php echo esc_url( $attachment['url'] ); ?>" />
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="nav-img">
                    <div class="nav-img-slider">
                        <?php foreach ( $settings['is_carousel'] as $index => $attachment ) { ?>
                        <div class="item">
                            <img class="size-full" src="<?php echo esc_url( $attachment['url'] ); ?>" />
                        </div>
                        <?php } ?>
                    </div>		
                </div>
            </div>
            <div class="is-content-container">
                <<?php esc_attr_e($title_tag); ?> class="is-title"><?php esc_html_e($settings['is_title']); ?></<?php esc_attr_e($title_tag); ?>>
                <<?php esc_attr_e($subtitle_tag); ?> class="is-subtitle"><?php esc_html_e($settings['is_subtitle']); ?></<?php esc_attr_e($subtitle_tag); ?>>                                
                <div class="is-description"><?php esc_html_e($settings['is_description']); ?></div>
                <div class="is-price-container">
                    <div class="is-price"><?php esc_html_e($settings['is_price']); ?></div>
                    <div class="is-original-price"><?php esc_html_e($settings['is_original_price']); ?></div>
                </div>
                <div class="elementor--star-style-star_unicode is-rating">
                    <div class="elementor-star-rating"><?php echo $this->render_stars($icon); ?></div>
                    <?php if($settings['is_show_text_rating'] === 'yes'){ ?>
                        <div class="is-rating-text"><?php esc_html_e($settings['is_rating_text']); ?></div>
                    <?php } ?>
                </div>
                <div class="is-button-wrapper">
                    <a class="is-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel); ?>><?php esc_html_e($settings['is_button']); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Image Slider Style 1 -->