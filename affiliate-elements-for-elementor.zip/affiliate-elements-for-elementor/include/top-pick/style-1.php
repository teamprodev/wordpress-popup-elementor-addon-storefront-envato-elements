<!-- Start Top Pick Style 1 -->
<div class="affiliate-elements-tp tp-style-1">
    <div class="tp-container">
        <div class="tp-content-grid">
            <div class="tp-image-container">
                <img class="tp-image" src="<?php echo esc_url( $settings['tp_image']['url'] ); ?>" />
            </div>
            <div class="tp-content-container">
                <<?php esc_attr_e($title_tag); ?> class="tp-title"><?php esc_html_e($settings['tp_title']); ?></<?php esc_attr_e($title_tag); ?>>
                <<?php esc_attr_e($subtitle_tag); ?> class="tp-subtitle"><?php esc_html_e($settings['tp_subtitle']); ?></<?php esc_attr_e($subtitle_tag); ?>>
                <div class="tp-description"><?php esc_html_e($settings['tp_description']); ?></div>
                <div class="tp-button-wrapper">
                    <?php if($settings['tp_button'] != ''){ ?>
                        <a class="tp-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel); ?>><?php esc_html_e($settings['tp_button']); ?></a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo $this->render_ribbons(); ?>
</div>
<!-- End Top Pick Style 1 -->