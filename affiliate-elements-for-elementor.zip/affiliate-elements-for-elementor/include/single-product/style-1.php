<!-- Start Single Product Style 1 -->
<div class="affiliate-elements-sp sp-style-1">
    <div class="sp-container">
        <div class="sp-content-grid">
            <div class="sp-content-container">
                <<?php esc_attr_e($title_tag); ?> class="sp-title"><?php esc_html_e($settings['sp_title']); ?></<?php esc_attr_e($title_tag); ?>>
                <<?php esc_attr_e($subtitle_tag); ?> class="sp-subtitle"><?php esc_html_e($settings['sp_subtitle']); ?></<?php esc_attr_e($subtitle_tag); ?>>
                <?php if($settings['sp_show_separator'] === 'yes'){ ?>
                    <hr class="sp-separator">
                <?php } ?>
                <div class="sp-description"><?php esc_html_e($settings['sp_description']); ?></div>
                <div class="sp-price-container">
                    <div class="sp-price"><?php esc_html_e($settings['sp_price']); ?></div>
                    <div class="sp-original-price"><?php esc_html_e($settings['sp_original_price']); ?></div>
                </div>
                <div class="elementor--star-style-star_unicode sp-rating">
                    <div class="elementor-star-rating"><?php echo $this->render_stars($icon); ?></div>
                    <?php if($settings['sp_show_text_rating'] === 'yes'){ ?>
                        <div class="sp-rating-text"><?php esc_html_e($settings['sp_rating_text']); ?></div>
                    <?php } ?>
                </div>
                <div class="sp-button-wrapper">
                    <a class="sp-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel); ?>><?php esc_html_e($settings['sp_button']); ?></a>
                </div>
            </div>
            <div class="sp-image-container">
                <img class="sp-image" src="<?php echo esc_url( $settings['sp_image']['url'] ); ?>" />
            </div>
        </div>
    </div>
    <?php if($settings['sp_ribbon'] != ''){ ?>
        <span class="sp-style-1-ribbon"><?php echo $settings['sp_ribbon']; ?></span>
    <?php } ?>
</div>
<!-- End Single Product Style 1 -->