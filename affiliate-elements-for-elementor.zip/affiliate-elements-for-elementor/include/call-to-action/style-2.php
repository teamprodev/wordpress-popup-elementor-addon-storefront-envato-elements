<!-- Start Call to Action Style 2 -->
<div class="affiliate-elements-cta ct-style-2">
    <div class="cta-container">
        <div class="cta-image-container">
            <img class="cta-image" src="<?php echo esc_url( $settings['cta_image']['url'] ); ?>" />
        </div>
        <div class="cta-content-container">
            <<?php esc_attr_e($title_tag); ?> class="cta-title"><?php esc_html_e($settings['cta_title']); ?></<?php esc_attr_e($title_tag); ?>>
            <div class="cta-description"><?php esc_html_e($settings['cta_description']); ?></div>
            <div class="cta-button-wrapper">
                <a class="cta-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel); ?>><?php esc_html_e($settings['cta_button']); ?></a>
            </div>
        </div>
        
    </div>
</div>
<!-- End Call to Action Style 2 -->