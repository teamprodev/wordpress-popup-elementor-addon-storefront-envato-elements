<!-- Start Product Rating Style 1 -->
<div class="affiliate-elements-pr pr-style-1">
    <<?php esc_attr_e($title_tag); ?> class="pr-title"><?php esc_html_e($settings['pr_title']); ?></<?php esc_attr_e($title_tag); ?>>
    <div class="pr-container">
        <?php foreach ($settings['feature_lists'] as $repeaters => $repeater) {?>
            <div class="pr-container-block <?php esc_attr_e($settings['pr_direction']); ?>">
                <div class="pr-rating">
                    (<?php esc_html_e($repeater['pr_rating']); ?><?php _e('/5', AEFE_DOMAIN) ?>)
                </div>
                <div class="pr-progress-bar-container">
                    <div class="pr-progress-bar" style="width:calc(100% * <?php esc_attr_e($repeater['pr_rating']); ?> / 5);"><?php esc_html_e($repeater['pr_feature']); ?></div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<!-- End Product Rating Style 1 -->