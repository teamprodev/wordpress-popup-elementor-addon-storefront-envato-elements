<!-- Start Product Rating Style 4 -->
<div class="affiliate-elements-pr pr-style-4">
    <<?php esc_attr_e($title_tag); ?> class="pr-title"><?php esc_html_e($settings['pr_title']); ?></<?php esc_attr_e($title_tag); ?>>
    <div class="pr-container">
        <?php foreach ($settings['feature_lists'] as $repeaters => $repeater) {?>
            <div class="pr-container-block-in">
                <div class="pr-feature-name"><?php esc_html_e($repeater['pr_feature']); ?></div>
                <div class="pr-rating">
                    (<?php esc_html_e($repeater['pr_rating']); ?><?php _e('/5', AEFE_DOMAIN) ?>)
                </div>
            </div>
            <div class="pr-container-block">
                <div class="pr-progress-bar-container">
                    <div class="pr-progress-bar <?php esc_attr_e($settings['pr_bg_shape']); ?>" style="width:calc(100% * <?php esc_attr_e($repeater['pr_rating']); ?> / 5);"></div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<!-- End Product Rating Style 4 -->