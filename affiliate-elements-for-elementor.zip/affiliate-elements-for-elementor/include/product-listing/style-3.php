<!-- Start Product Listing Style 3 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-pl pl-style-3">
    <ul><?php
        for ( $i = 1; $i <= $settings['pl_product_count']; $i++ ) { ?>
            <li class="pl-product-heading"><?php esc_html_e($settings['pl_product_title_' . $i]); ?></li>
        <?php } ?>
    </ul>
    <table>
        <tbody>
            <tr>
                <td class="pl-header-title"><?php esc_html_e($settings['pl_heading_1']); ?></td>
                <?php for ( $i = 1; $i <= $settings['pl_product_count']; $i++ ) { ?>
                    <td class="pl-products">
                        <img class="pl-product-img" src="<?php echo esc_url($settings['pl_image_' . $i]['url']); ?>" />
                        <?php if (!empty( $settings['pl_product_label_' . $i])) { ?>
                            <div class="pl-product-label-container">
                                <div class="pl-product-label"><?php esc_html_e($settings['pl_product_label_' . $i]); ?></div>
                            </div>
                        <?php } ?>
                        <div class="pl-product-title"><?php esc_html_e($settings['pl_product_title_' . $i]); ?></div>
                        <div class="elementor--star-style-star_unicode pl-rating">
                            <div class="elementor-star-rating">
                                <?php
                                for ($stars = 1; $stars <= 5; $stars++) {
                                    $rating         = (float) $settings['pl_rating_' . $i] > 5 ? 5 : $settings['pl_rating_' . $i];
                                    $stars_html     = '';
                                    $floored_rating = (int) $rating;
                                    if ($stars <= $floored_rating) {
                                        $stars_html .= '<i class="elementor-star-full">' . $icon . '</i>';
                                    } elseif ($floored_rating + 1 === $stars && $rating !== $floored_rating) {
                                        $stars_html .= '<i class="elementor-star-' . ( $rating - $floored_rating ) * 10 . '">' . $icon . '</i>';
                                    } else {
                                        $stars_html .= '<i class="elementor-star-empty">' . $icon . '</i>';
                                    }
                                    _e($stars_html);
                                } ?>
                            </div>
                        </div>
                    </td>
                <?php } ?>
            </tr>
            <tr>
                <td class="pl-header-title"><?php esc_html_e($settings['pl_heading_2']); ?></td>
                <?php for ( $i = 1; $i <= $settings['pl_product_count']; $i++ ) { ?>
                    <td class="pl-product">
                        <div class="pl-product-content">
                        <?php foreach ($settings['pl_product_list_' .$i] as $contents => $content) {?>
                            <div class="pl-content pl-flex">
                                <div class="pl-title"><?php esc_html_e($content['pl_list_title']); ?></div>
                                <div class="pl-description"><?php esc_html_e($content['pl_list_desc']); ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    </td>
                <?php } ?>
            </tr>
            <tr>
                <td class="pl-header-title"><?php esc_html_e($settings['pl_heading_3']); ?></td>
                <?php for ( $i = 1; $i <= $settings['pl_product_count']; $i++ ) { ?>
                <td class="pl-product-buttons"><?php
                        $button_link    = $settings['pl_button_link_' . $i]['url'];
                        $target         = $settings['pl_button_link_' . $i]['is_external'] ? ' target="_blank"' : '';
                        $rel            = $settings['pl_button_link_' . $i]['nofollow'] ? ' rel="nofollow"' : ''; ?>
                        <a class="pl-product-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel);?>><?php Icons_Manager::render_icon($settings['pl_button_icon_' . $i], [ 'aria-hidden' => 'true' ]); ?><?php esc_html_e($settings['pl_button_text_' . $i]); ?></a>
                    </td>
                <?php } ?>
            </tr>
        </tbody>
    </table>
</div>
<!-- End Product Listing Style 3 -->