<!-- Start Product Listing Style 1 -->
<?php use Elementor\Icons_Manager; ?>
<div class="affiliate-elements-pl pl-style-1">
    <table>
        <tbody>
            <tr class="pl-header">
                <td class="pl-header-title pl-first-column"><?php esc_html_e($settings['pl_heading_1']); ?></td>
                <td class="pl-header-title pl-second-column"><?php esc_html_e($settings['pl_heading_2']); ?></td>
                <td class="pl-header-title pl-third-column"><?php esc_html_e($settings['pl_heading_3']); ?></td>
            </tr>
            <?php for ( $i = 1; $i <= $settings['pl_product_count']; $i++ ) { ?>
                <tr class="pl-product">
                    <td class="pl-product-feature">
                        <div class="pl-product-image">
                            <img class="pl-product-img" src="<?php echo esc_url($settings['pl_image_' . $i]['url']); ?>" />
                        </div>
                        <div class="pl-rating"><?php esc_html_e($settings['pl_rating_' . $i]); ?></div>
                    </td>
                    <td class="pl-product-feature">
                        <div class="pl-flex pl-title-label">
                            <div class="pl-product-title"><?php esc_html_e($settings['pl_product_title_' . $i]); ?></div>
                            <div class="pl-product-label"><?php esc_html_e($settings['pl_product_label_' . $i]); ?></div>
                        </div>
                        <div class="pl-flex">
                        <?php foreach ($settings['pl_product_list_' .$i] as $contents => $content) {?>
                                <div class="pl-content pl-flex">
                                    <div class="pl-title"><?php esc_html_e($content['pl_list_title']); ?></div>
                                    <div class="pl-description"><?php esc_html_e($content['pl_list_desc']); ?></div>
                                </div>
                            <?php } ?>
                        </div>
                    </td>
                    <td class="pl-product-feature pl-button"><?php 
                        $button_link    = $settings['pl_button_link_' . $i]['url'];
                        $target         = $settings['pl_button_link_' . $i]['is_external'] ? ' target="_blank"' : '';
                        $rel            = $settings['pl_button_link_' . $i]['nofollow'] ? ' rel="nofollow"' : ''; ?>
                        <a class="pl-product-button" href="<?php echo esc_url($button_link); ?>" <?php esc_attr_e($target); esc_attr_e($rel);?>><?php Icons_Manager::render_icon($settings['pl_button_icon_' . $i], [ 'aria-hidden' => 'true' ]); ?><?php esc_html_e($settings['pl_button_text_' . $i]); ?></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<!-- End Product Listing Style 1 -->