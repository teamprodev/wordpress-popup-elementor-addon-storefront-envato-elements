<?php
namespace Elementor;

use Elementor\Icons_Manager;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;   
}

// Class Pros and Cons
class Pros_and_Cons_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-pros-and-cons';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Pros and Cons', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-columns';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['pros and cons', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-pros-and-cons'];
    }

    // Adding the controls fields for the Pros and Cons Element
    protected function _register_controls() {

        // Start General Section
        $this->start_controls_section(
            'pac_section_general', array(
                'label'         => esc_html__('General', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'pac_style', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Design 3', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
            'pac_icon',
            [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-cogs',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'pac_style' => 'style-1',
                ],
            ]
        );

        $this->add_control(
            'pac_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Business', AEFE_DOMAIN),
                'condition'     => [
                    'pac_style' => 'style-3',
                ],
            ]
        );

        $this->add_responsive_control(
			'pac_image',
			[
                'label'         => esc_html__('Image', AEFE_DOMAIN),
				'type'          => Controls_Manager::MEDIA,
				'default'       => [
					'url'       => AEFE_URL . 'assets/image/lady.png',
				],
                'condition'     => [
                    'pac_style'   => 'style-3',
                ],
			]
		);

        $this->end_controls_section();
        // End General Section

        // Start Pros Section
        $this->start_controls_section(
            'pac_pros_section', array(
                'label'         => esc_html__('Pros', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'pac_pros_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Pros', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'pac_pro_icon',
            [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-thumbs-up',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $pros = new Repeater();

        $pros->add_control(
            'pros_content',
            [
                'type'          => Controls_Manager::TEXTAREA,
                'label_block'   => true,
                'rows'          => 4,
                'default'       => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'pros_lists',
			[
				'label'         => esc_html__('Pros List', AEFE_DOMAIN),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $pros->get_controls(),
                'render_type'   => 'template',
                'default'       => [
                    [
                        'pros_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'pros_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'pros_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'pros_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                ],
                'title_field'   => '{{{ pros_content }}}'
			]
        );

        $this->add_control(
            'pac_pro_list_icon',
            [
                'label'         => esc_html__('List Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-check',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->end_controls_section();
        // End Pros Section

        // Start Cons Section
        $this->start_controls_section(
            'pac_cons_section', array(
                'label'         => esc_html__('Cons', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'pac_cons_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Cons', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'pac_cons_icon',
            [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-thumbs-down',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $cons = new Repeater();

        $cons->add_control(
            'cons_content',
            [
                'type'          => Controls_Manager::TEXTAREA,
                'label_block'   => true,
                'rows'          => 4,
                'default'       => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'cons_lists',
			[
				'label'         => esc_html__('Cons List', AEFE_DOMAIN),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $cons->get_controls(),
                'render_type'   => 'template',
                'default'       => [
                    [
                        'cons_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'cons_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'cons_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'cons_content' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                ],
                'title_field'   => '{{{ cons_content }}}'
			]
        );

        $this->add_control(
            'pac_cons_list_icon',
            [
                'label'         => esc_html__('List Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-times',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->end_controls_section();
        // End Cons Section

        // Start Typography Style Control       
        $this->start_controls_section(
            'pac_typography', [
                'label'         => esc_html__('Typography', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Middle Title', AEFE_DOMAIN),
                'name'          => 'typography_pac_list_title',
                'selector'      => '{{WRAPPER}} .pac-style-3 .pac-mid-title',
                'condition'     => [
                    'pac_style' => 'style-3',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'name'          => 'typography_pac_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pac .pac-pros-title, {{WRAPPER}} .affiliate-elements-pac .pac-cons-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'name'          => 'typography_pac_content',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pac .pac-pros-content, {{WRAPPER}} .affiliate-elements-pac .pac-cons-content',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Order', AEFE_DOMAIN),
                'name'          => 'typography_pac_order',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pac li::before',
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->end_controls_section();
        // End Typography Style Control

        // Start Color Style Control       
        $this->start_controls_section(
            'pac_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'pac_title_color', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-3 .pac-mid-title' => 'color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-3',
                ],
            ]
        );

        $this->start_controls_tabs('pac_color_settings');

        $this->start_controls_tab(
            'pac_pros_color',
            [
                'label'         => esc_html__('Pros', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'pac_pros_icon_color', [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#0AB179',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon svg' => 'fill: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_icon_bg_color', [
                'label'         => esc_html__('Icon Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#F2F2F2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_icon_border_color', [
                'label'         => esc_html__('Icon Border', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#0AB179',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon' => 'border-color: {{VALUE}} !important;',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_title_color', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac .pac-pros-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_title_bg_color', [
                'label'         => esc_html__('Title Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#0AB179',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac .pac-pros-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_order_color', [
                'label'         => esc_html__('Order', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-pros-content::before' => 'color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_order_bg_color', [
                'label'         => esc_html__('Order Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#0AB179',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-pros-content::before' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_content_color', [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-pros-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_content_bg_color', [
                'label'         => esc_html__('Content Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#f2f2f2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 ol li.pac-pros-content, {{WRAPPER}} .pac-style-2 ol.pac-pros-list, {{WRAPPER}} .pac-style-3 ol li.pac-pros-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_pros_list_icon_color', [
                'label'         => esc_html__('List Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#0AB179',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-content i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .pac-style-2 .pac-pros-content svg' => 'fill: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'pac_cons_color',
            [
                'label'         => esc_html__('Cons', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'pac_cons_icon_color', [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FE3954',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .pac-style-2 .pac-cons-icon svg' => 'fill: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_icon_bg_color', [
                'label'         => esc_html__('Icon Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#F2F2F2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_icon_border_color', [
                'label'         => esc_html__('Icon Border', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FE3954',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'border-color: {{VALUE}} !important;',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_title_color', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac .pac-cons-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_title_bg_color', [
                'label'         => esc_html__('Title Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FE3954',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac .pac-cons-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_order_color', [
                'label'         => esc_html__('Order', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-cons-content::before' => 'color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_order_bg_color', [
                'label'         => esc_html__('Order Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FE3954',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-cons-content::before' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_content_color', [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li.pac-cons-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_content_bg_color', [
                'label'         => esc_html__('Content Background', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#f2f2f2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 ol li.pac-cons-content, {{WRAPPER}} .pac-style-2 ol.pac-cons-list,{{WRAPPER}} .pac-style-3 ol li.pac-cons-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pac_cons_list_icon_color', [
                'label'         => esc_html__('List Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FE3954',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-cons-content i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .pac-style-2 .pac-cons-content svg' => 'fill: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Color Style Control

        // Start Content Style Control       
        $this->start_controls_section(
            'pac_content', [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'pac_order_options',
			[
				'label'         => esc_html__('Order', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
			]
		);

        $this->add_control(
            'pac_order_alignment', [
                'label'         => esc_html__('Vertical Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'top'       => esc_html__('Top', AEFE_DOMAIN),
                    'middle'    => esc_html__('Middle', AEFE_DOMAIN),
                    'bottom'    => esc_html__('Botttom', AEFE_DOMAIN),
                ],
                'default'       => 'middle',
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_order_box_size', [
                'label'         => esc_html__('Box Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 65],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li::before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-3 .pac-pros-title' => 'padding-right: calc({{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .pac-style-3 .pac-cons-title' => 'padding-left: calc({{SIZE}}{{UNIT}} / 2);',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_order_box_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 50],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li::before' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
			'pac_title_options',
			[
				'label'         => esc_html__('Title', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
			]
		);

        $this->add_control(
            'pac_title_box_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 50,
                    ],
                ],
                'default'       => ['size'  => 20],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-title-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
			'pac_content_options',
			[
				'label'         => esc_html__('Content', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
                'separator'     => 'before',
			]
		);

        $this->add_responsive_control(
            'pac_content_box_column_gap', [
                'label'         => esc_html__('Column Gap', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 50],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_content_padding', [
                'label'         => esc_html__('Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 ol li, {{WRAPPER}} .pac-style-2 ol' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-3 ol li.pac-pros-content' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-3 ol li.pac-cons-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pac_content_box_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 20],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li' => 'border-radius: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-2 ol' => 'border-bottom-left-radius: {{SIZE}}{{UNIT}}; border-bottom-right-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_content_box_space', [
                'label'         => esc_html__('Space Between List', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 15],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac ol li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Content Style Control

        // Start Icon Style Control       
        $this->start_controls_section(
            'pac_icon_setting', [
                'label'         => esc_html__('Icon', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'pac_style!' => 'style-3',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_color', [
                'label'         => esc_html__('Icon Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#585858',
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container svg' => 'fill: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_box_color', [
                'label'         => esc_html__('Icon Background Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#f2f2f2',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pac .pac-icon-container' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_line_color', [
                'label'         => esc_html__('Line Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#f2f2f2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-vertical, {{WRAPPER}} .pac-horizontal' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_line_dot_color', [
                'label'         => esc_html__('Line Dot Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#C2C2C2',
                'selectors'     => [
                    '{{WRAPPER}} .pac-bottom-circle, {{WRAPPER}} .pac-left-circle, {{WRAPPER}} .pac-right-circle' => 'background-color: {{VALUE}};',
                ],
                'condition'     => [
                    'pac_style!' => 'style-2',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_icon_size', [
                'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'default'       => ['size'  => 50],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container i, {{WRAPPER}} .pac-style-2 .pac-pros-icon, {{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container svg, {{WRAPPER}} .pac-style-2 .pac-pros-icon svg, {{WRAPPER}} .pac-style-2 .pac-cons-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_icon_box_size', [
                'label'         => esc_html__('Box Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'tablet_default'=> ['size' => 90],
                'default'       => ['size'  => 130],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container, {{WRAPPER}} .pac-style-2 .pac-pros-icon, {{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-1 .pac-title-container' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-1 .pac-horizontal' => 'top: calc({{SIZE}}{{UNIT}} / 2)'
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_icon_box_space', [
                'label'         => esc_html__('Bottom Space', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 30],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon-container, {{WRAPPER}} .pac-style-2 .pac-cons-icon-container' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_icon_box_border_width', [
                'label'         => esc_html__('Border Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 20,
                    ],
                ],
                'default'       => ['size'  => 5],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-icon, {{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'border: {{SIZE}}{{UNIT}} solid;',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_box_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size'  => 100],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-1 .pac-icon-container, {{WRAPPER}} .pac-style-2 .pac-pros-icon, {{WRAPPER}} .pac-style-2 .pac-cons-icon' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_icon_list_size', [
                'label'         => esc_html__('List Icon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 50,
                    ],
                ],
                'default'       => ['size'  => 18],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-content i, {{WRAPPER}} .pac-style-2 .pac-cons-content i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pac-style-2 .pac-pros-content svg, {{WRAPPER}} .pac-style-2 .pac-cons-content svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->add_control(
            'pac_icon_list_space', [
                'label'         => esc_html__('List Icon Space', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 50,
                    ],
                ],
                'default'       => ['size'  => 10],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-2 .pac-pros-content i, {{WRAPPER}} .pac-style-2 .pac-pros-content svg, {{WRAPPER}} .pac-style-2 .pac-cons-content i, {{WRAPPER}} .pac-style-2 .pac-cons-content svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'pac_style' => 'style-2',
                ],
            ]
        );

        $this->end_controls_section();
        // End Icon Style Control

        // Start Image and Arrow Style Control
        $this->start_controls_section(
            'pac_img_arrow_setting', [
                'label'         => esc_html__('Image and Arrow', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'pac_style' => 'style-3',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_image_size', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'default'       => ['size'  => 165],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-3 .pac-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pac_arrow_size', [
                'label'         => esc_html__('Arrow Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'default'       => ['size'  => 120],
                'selectors'     => [
                    '{{WRAPPER}} .pac-style-3 .pac-pros-title, {{WRAPPER}} .pac-style-3 .pac-cons-title, {{WRAPPER}} .pac-style-3 .pac-mid-title ' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // Start Image and Arrow Style Control       

    }

    /**
     * Render Pros and Cons Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings();
        
        switch ($settings['pac_style']) {
            case 'style-1':
                include AEFE_PATH . 'include/pros-and-cons/style-1.php'; // Style 1
                break;
            case 'style-2':
                include AEFE_PATH . 'include/pros-and-cons/style-2.php'; // Style 2
                break;
            case 'style-3':
                include AEFE_PATH . 'include/pros-and-cons/style-3.php'; // Style 3
                break;
            default:
                include AEFE_PATH . 'include/pros-and-cons/style-1.php'; // Default
                break;
        }

    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Pros_and_Cons_Elementor_Widget());