<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;   
}

// Class Product Listing
class Product_Listing_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-product-listing';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Product Listing', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-product-tabs';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['product listing', 'aefe', 'affiliate elements'];
	}

	// Funcyion for include js
	public function get_script_depends()
    {
        return ['aefe-product-listing-js'];
    }

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-product-listing'];
    }

    // Adding the controls fields for the Product Listing Element
    protected function _register_controls() {

        // Start General Section
        $this->start_controls_section(
            'pl_section_general', array(
                'label'         => esc_html__('General', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'pl_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Design 3', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
			'pl_product_count',
			[
				'label'         => esc_html__('Products', AEFE_DOMAIN),
				'type'          => Controls_Manager::NUMBER,
				'default'       => 3,
                'max'           => 100,
			]
		);

        $this->end_controls_section();
        // End General Section

        // Start Heading Section
        $this->start_controls_section(
            'pl_section_heading', array(
                'label'         => esc_html__('Heading', AEFE_DOMAIN),
            )
        );

        $this->add_control(
			'pl_heading_1',
			[
				'label'         => esc_html__('First', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Product', AEFE_DOMAIN),
			]
		);

        $this->add_control(
			'pl_heading_2',
			[
				'label'         => esc_html__('Second', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Name and Information', AEFE_DOMAIN),
			]
		);

        $this->add_control(
			'pl_heading_3',
			[
				'label'         => esc_html__('Third', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Price', AEFE_DOMAIN),
			]
		);

        $this->end_controls_section();
        // End Heading Section

        $this->add_product();

    }

    // Function for adding product sections
    public function add_product() {

        $repeater = new Repeater();

        $repeater->add_control(
			'pl_list_title',
			[
				'label'         => esc_html__('Title', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Title', AEFE_DOMAIN),
			]
		);

        $repeater->add_control(
			'pl_list_desc',
			[
				'label'         => esc_html__('Description', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Description', AEFE_DOMAIN),
			]
		);

        for ( $i = 1; $i < 101; $i++ ) {

            $this->start_controls_section(
				'pl_product_section_' . $i,
				[
					'label'     => sprintf( esc_html__('Product %s', AEFE_DOMAIN), $i ),
					'operator'  => '>',
					'condition' => [
						'pl_product_count' => $this->add_condition_value( $i ),
					],
				]
			);

            $this->add_control(
                'pl_image_' . $i,
                [
                    'label'     => esc_html__('Image', AEFE_DOMAIN),
                    'type'      => Controls_Manager::MEDIA,
                    'default'   => [
                        'url'   => Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $this->add_control(
				'pl_product_title_' . $i,
				[
					'label'     => esc_html__('Title', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('Title', AEFE_DOMAIN),
				]
			);

            $this->add_control(
				'pl_product_label_' . $i,
				[
					'label'     => esc_html__('Label', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('Best Seller', AEFE_DOMAIN),
				]
			);

            $this->add_control(
                'pl_rating_' . $i, [
                    'label'         => esc_html__('Rating', AEFE_DOMAIN),
                    'type'          => Controls_Manager::NUMBER,
                    'min'           => 0,
                    'max'           => 5,
                    'step'          => 0.1,
                    'default'       => 4.5,
                ]
            );

            $this->add_control(
                'pl_product_list_' .$i,
                [
                    'label'         => esc_html__('Content', AEFE_DOMAIN),
                    'type'          => Controls_Manager::REPEATER,
                    'fields'        => $repeater->get_controls(),
                    'render_type'   => 'template',
                    'default'       => [
                        [
                            'pl_list_title' => esc_html__('Author:', AEFE_DOMAIN),
                            'pl_list_desc' => esc_html__('Admin', AEFE_DOMAIN),
                        ],
                        [
                            'pl_list_title' => esc_html__('Language:', AEFE_DOMAIN),
                            'pl_list_desc' => esc_html__('English', AEFE_DOMAIN),
                        ],
                        [
                            'pl_list_title' => esc_html__('Pages:', AEFE_DOMAIN),
                            'pl_list_desc' => esc_html__('100', AEFE_DOMAIN),
                        ],
                        [
                            'pl_list_title' => esc_html__('Version:', AEFE_DOMAIN),
                            'pl_list_desc' => esc_html__('1.0', AEFE_DOMAIN),
                        ],
                    ],
                    'title_field'   => '{{{ pl_list_title }}}'
                ]
            );

            $this->add_control(
                'pl_button_icon_' . $i,
                [
                    'label'         => esc_html__('Button Icon', AEFE_DOMAIN),
                    'type'          => Controls_Manager::ICONS,
                    'default'       => [
                        'value'     => 'fas fa-thumbs-up',
                        'library'   => 'fa-solid',
                    ],
                    'separator'     => 'before',
                ]
            );

            $this->add_control(
				'pl_button_text_' . $i,
				[
					'label'     => esc_html__('Button Text', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('Check Price', AEFE_DOMAIN),
				]
			);

            $this->add_control(
				'pl_button_link_' . $i,
				[
					'label'     => esc_html__('Link', AEFE_DOMAIN),
					'type'      => Controls_Manager::URL,
					'default'   => [
						'url'         => '#',
						'is_external' => '',
					],
				]
			);

            $this->end_controls_section();

        }

        // Start General Style Tab
        $this->start_controls_section(
			'pl_section_general_style',
			[
				'label'         => esc_html__('General', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'pl_first_column_width', [
                'label'         => esc_html__('First Column Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'default'       => ['size' => 25, 'unit' => '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-first-column' => 'width: {{SIZE}}{{UNIT}};',
                ],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
            ]
        );

        $this->add_responsive_control(
            'pl_second_column_width', [
                'label'         => esc_html__('Second Column Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'default'       => ['size' => 50, 'unit' => '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-second-column' => 'width: {{SIZE}}{{UNIT}};',
                ],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
            ]
        );

        $this->add_responsive_control(
            'pl_third_column_width', [
                'label'         => esc_html__('Third Column Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'default'       => ['size' => 25, 'unit' => '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-third-column' => 'width: {{SIZE}}{{UNIT}};',
                ],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
            ]
        );

		$this->add_control(
            'pl_product_box_border_heading',
            [
                'label'     	=> esc_html__('Box', AEFE_DOMAIN),
                'type'      	=> Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_table_border',
				'label'         => esc_html__('Table', AEFE_DOMAIN),
				'selector'   	=> '{{WRAPPER}} .affiliate-elements-pl table',
				'condition' 	=> [
					'pl_skin!' => ['style-3'],
				],
			]
		);

		$this->add_control(
            'pl_box_column_spacing', [
                'label'         => esc_html__('Column Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
				'default'       => ['size'  => 15],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table' => 'border-spacing: {{SIZE}}{{UNIT}} 0px;',
                ],
				'condition' 	=> [
					'pl_skin' => ['style-3'],
				],
            ]
        );

		$this->add_control(
            'pl_skin_3_border', [
                'label'         => esc_html__('Border', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '' => esc_html__('None', AEFE_DOMAIN),
                    'solid' => esc_html__('Solid', AEFE_DOMAIN),
                    'double' => esc_html__('Double', AEFE_DOMAIN),
					'dotted' => esc_html__('Dotted', AEFE_DOMAIN),
					'dashed' => esc_html__('Dashed', AEFE_DOMAIN),
					'grove' => esc_html__('Groove', AEFE_DOMAIN),
                ],
                'default'       => '',
				'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table td' => 'border-style: {{VALUE}};',
                ],
				'condition' 	=> [
					'pl_skin' => ['style-3'],
				],
            ]
        );

		$this->add_responsive_control(
			'pl_td_border_3',
			[
				'label'         => esc_html__('Width', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table td' => 'border-width: 0px {{RIGHT}}{{UNIT}} 0px {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table tr:first-child td' => 'border-top-width: {{TOP}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table tr:last-child td' => 'border-bottom-width: {{BOTTOM}}{{UNIT}};',
				],
				'condition' 	=> [
					'pl_skin' => 'style-3',
					'pl_skin_3_border!' => '',
				],
			]
		);

		$this->add_control(
			'pl_td_border_color_3',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table td' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table tr:first-child td' => 'border-top-color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table tr:last-child td' => 'border-bottom-color: {{VALUE}};',
				],
				'condition' 	=> [
					'pl_skin' => 'style-3',
					'pl_skin_3_border!' => '',
				],
			]
		);

		$this->add_control(
            'pl_product_box_column_heading',
            [
                'label'     	=> esc_html__('Column', AEFE_DOMAIN),
                'type'      	=> Controls_Manager::HEADING,
				'separator'		=> 'before',
            ]
        );

        $this->add_control(
			'pl_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl td' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_table_td_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'   	=> '{{WRAPPER}} .affiliate-elements-pl td',
				'condition' 	=> [
					'pl_skin!' => ['style-3'],
				],
			]
		);

        $this->add_responsive_control(
			'pl_td_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .affiliate-elements-pl .pl-rating' => 'right: {{RIGHT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End General Style Tab

        // Start Heading Style Tab
        $this->start_controls_section(
			'pl_section_heading_style',
			[
				'label'         => esc_html__('Heading', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'pl_headings_width', [
                'label'         => esc_html__('Box Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 500,
                    ],
                ],
				'mobile_default'       => ['size' => 50, 'unit' => '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-header-title' => 'width: {{SIZE}}{{UNIT}};',
                ],
				'condition'     => [
					'pl_skin' => ['style-3', 'style-2'],
				],
            ]
        );

        $this->add_control(
			'pl_heading_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#fff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-header-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pl_heading_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-header td' => 'background-color: {{VALUE}} !important;',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-header-title' => 'background-color: {{VALUE}} !important;',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-header-title' => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'pl_heading_typography',
				'selector'  => '{{WRAPPER}} .affiliate-elements-pl .pl-header-title',
			]
		);

        $this->add_responsive_control(
			'pl_heading_text_align',
			[
				'label'     => esc_html__('Alignment', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-header-title' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'pl_heading_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-header-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Heading Style Tab

        // Start Image Style Section       
        $this->start_controls_section(
            'pl_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'pl_image_width',
			[
				'label'         => esc_html__('Width', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 500,
                    ],
                ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'pl_image_radius',
			[
				'label'         => esc_html__('Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-img' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pl_image_top_3',
			[
				'label'         => esc_html__('Image Top', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'default'       => ['size' => 80],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-img' => 'margin-top: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 table' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'     => [
					'pl_skin' => 'style-3',
				],
			]
		);

		$this->add_responsive_control(
			'pl_image_space_bottom_3',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size' => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-img' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'     => [
					'pl_skin' => 'style-3',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_image_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-img',
				'condition'     => [
					'pl_skin' => 'style-3',
				],
			]
		);

        $this->add_responsive_control(
			'pl_image_index',
			[
				'label'         => esc_html__('Z-index', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1,
                    ],
                ],
                'default'       => ['size' => 1],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-img' => 'z-index: {{SIZE}};',
				],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
			]
		);

        $this->add_responsive_control(
			'pl_image_space',
			[
				'label'         => esc_html__('Space', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size' => 30, 'unit' => 'px'],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-image' => 'padding-right: {{SIZE}}{{UNIT}};',
				],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
			]
		);

        $this->end_controls_section();
        // End Image Style Tab

        // Start Title Style Section       
        $this->start_controls_section(
            'pl_product_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'pl_title_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-title' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pl_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-title',
            ]
        );

        $this->add_responsive_control(
			'pl_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-title-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
			]
		);

        $this->end_controls_section();
        // End Title Style Tab

        // Start Content Style Section       
        $this->start_controls_section(
            'pl_product_content_style', [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'pl_product_title_heading',
            [
                'label'     	=> esc_html__('Title', AEFE_DOMAIN),
                'type'      	=> Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
			'pl_product_title_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-title' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pl_product_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-title',
            ]
        );

        $this->add_control(
            'pl_product_desc_heading',
            [
                'label'     	=> esc_html__('Description', AEFE_DOMAIN),
                'type'      	=> Controls_Manager::HEADING,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'pl_product_desc_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-description' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pl_product_desc',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-description',
            ]
        );

        $this->add_responsive_control(
			'pl_content_space_between',
			[
				'label'         => esc_html__('Space Between', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-1 .pl-content' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End content Style Tab

        // Start Label Style Section       
        $this->start_controls_section(
            'pl_product_label_style', [
                'label'         => esc_html__('Label', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'pl_label_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#999999',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-label' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'pl_label_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F5F5F5',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-label' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pl_label',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-label',
            ]
        );

        $this->add_responsive_control(
			'pl_label_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-1 .pl-product-label' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_label_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-label',
			]
		);

        $this->add_control(
			'pl_label_border_radius',
			[
				'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pl_label_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Label Style Tab

        // Start Rating Style Section       
        $this->start_controls_section(
            'pl_rating_style', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
				'condition'     => [
					'pl_skin' => 'style-1',
				],
            ]
        );

        $this->add_responsive_control(
			'pl_rating_size',
			[
				'label'         => esc_html__('Size', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size' => 55, 'unit' => 'px'],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-rating' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'pl_rating_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-rating' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'pl_rating_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-rating' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pl_rating',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-rating',
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_rating_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-rating',
			]
		);

        $this->add_control(
			'pl_rating_border_radius',
			[
				'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-rating' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Rating Style Tab

		// Start Rating Style Section   
        $this->start_controls_section(
            'pl2_rating_style', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
				'condition'     => [
					'pl_skin' => ['style-2', 'style-3'],
				],
            ]
        );

        $this->add_responsive_control(
            'pl2_star_size',
            [
                'label'         => esc_html__('Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'       => ['size'  => 30],
                'selectors' => [
                    '{{WRAPPER}} .pl-rating .elementor-star-rating' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pl2_star_space',
            [
                'label'         => esc_html__('Space between', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .pl-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .pl-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'pl2_star_spacing_bottom',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-rating' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'pl2_stars_color',
            [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .pl-rating .elementor-star-rating i:before' => 'color: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'pl2_stars_unmarked_color',
            [
                'label'         => esc_html__('Unmarked Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .pl-rating .elementor-star-rating i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Rating Style Section

        // Start Button Style Tab
        $this->start_controls_section(
			'pl_button_style',
			[
				'label'         => esc_html__('Button', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'pl_button_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-button',
			]
		);

        $this->add_responsive_control(
            'pl_button_icon_size', [
                'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-product-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .affiliate-elements-pl .pl-product-button svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pl_button_icon_spacing', [
                'label'         => esc_html__('Icon Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'default'       => ['size' => 10, 'unit' => 'px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pl .pl-product-button i, {{WRAPPER}} .affiliate-elements-pl .pl-product-button svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'pl_button_text_align',
			[
				'label'     => esc_html__('Alignment', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-button' => 'text-align: {{VALUE}};',
				],
				'condition'     => [
					'pl_skin' => 'style-1',
				],
			]
		);

		$this->start_controls_tabs('pl_button_style_tabs');

		$this->start_controls_tab(
			'pl_button_style_normal_tab',
			[
				'label'         => esc_html__('Normal', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'pl_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-pl .pl-product-button svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pl_button_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button' => 'background-color: {{VALUE}};',
				],
                'separator'     => 'after',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'pl_button_style_hover_tab',
			[
				'label'         => esc_html__('Hover', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'pl_button_color_hover',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-pl .pl-product-button:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pl_button_bg_color_hover',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'pl_btn_border_color_hover',
			[
				'label'         => esc_html__('Border Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button:hover' => 'border-color: {{VALUE}};',
				],
            	'separator'     => 'after',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'          => 'pl_button_shadow',
				'label'         => 'Button Shadow',
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-button',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'pl_btn_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-button',
			]
		);

		$this->add_control(
			'pl_btn_border_radius',
			[
				'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pl_button_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pl_button_margin',
			[
				'label'         => esc_html__('Margin', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl .pl-product-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
        // End Button Style Tab

		// Start Mobile Tab Style Tab
        $this->start_controls_section(
			'pl_tab_style',
			[
				'label'         => esc_html__('Mobile Tab', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
				'condition'     => [
					'pl_skin' => ['style-2', 'style-3'],
				],
			]
		);

		$this->add_control(
            'pl_tab_format', [
                'label'         => esc_html__('Start Tab Format From', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1200,
                    ],
                ],
                'default'       => ['size'  => 767],
            ]
        );

		$this->add_control(
			'pl_heading_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-heading' => 'color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pl_heading_active_text_color',
			[
				'label'         => esc_html__('Active Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-heading.active' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-heading.active' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'pl_heading_text_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-heading' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pl_heading_active_text_bg_color',
			[
				'label'         => esc_html__('Active Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#0071BD',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-heading.active' => 'background-color: {{VALUE}} !important;',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-heading.active' => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'pl_tab_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-pl .pl-product-heading',
			]
		);

		$this->add_responsive_control(
			'pl_tab_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-2 .pl-product-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-pl.pl-style-3 .pl-product-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
        // End Mobile Tab Style Tab

    }

    // Function for counting products
    public function add_condition_value( $j ) {

		$value = [];

		for ( $i = $j; $i < 101; $i++ ) {
			$value[] = $i;
		}
        
		return $value;

	}

    /**
     * Render Product Listing Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();
        $icon           = '&#9733;';
		$id 			= '.elementor-element-' . $this->get_id();

        switch ($settings['pl_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/product-listing/style-1.php'; // Style 1
                break;
            case 'style-2':
                include AEFE_PATH . 'include/product-listing/style-2.php'; // Style 2
                break;
            case 'style-3':
                include AEFE_PATH . 'include/product-listing/style-3.php'; // Style 3
                break;
            default:
                include AEFE_PATH . 'include/product-listing/style-1.php'; // Default
                break;
        }?>

		<style>
		@media (max-width: <?php esc_attr_e($settings['pl_tab_format']['size']);?>px)  {
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-2 ul,
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-3 ul {
				display: flex;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-2 tr td:nth-child(2),
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-3 tr td:nth-child(2) {
				display: table-cell;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-2 td:nth-child(1),
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-3 td:nth-child(1) {
				display: table-cell;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-2 td,
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-3 td {
				display: none;
			}
		}
		@media (min-width: calc(<?php esc_attr_e($settings['pl_tab_format']['size']);?>px + 1px))  {
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-2 td,
			<?php esc_attr_e($id);?> .affiliate-elements-pl.pl-style-3 td {
				display: table-cell !important;
			}
		}
		</style><?php

    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Product_Listing_Elementor_Widget());