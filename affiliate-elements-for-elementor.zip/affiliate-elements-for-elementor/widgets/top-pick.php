<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Top Pick
 */
class Top_Pick_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-top-pick';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Top Pick', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-image-rollover';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['top pick', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-top-pick'];
    }

    // Adding the controls fields for the Call to Action Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'tp_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'tp_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

		$this->add_control(
			'tp_image',
			[
				'label'         => esc_html__('Choose Image', AEFE_DOMAIN),
				'type'          => Controls_Manager::MEDIA,
				'dynamic'       => [
					'active' => true,
				],
				'default'       => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'separator'     => 'before',
			]
		);

        $this->add_responsive_control(
			'tp_image_position',
			[
				'label'     => esc_html__('Image Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'0' => [
						'title' => esc_html__('Start', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'1' => [
						'title' => esc_html__('End', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
                'default'       => '0',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-image-container' => 'order: {{VALUE}};',
                ],
                'condition'     => [
                    'tp_skin' => 'style-1',
                ],
			]
		);

        $this->add_control(
            'tp_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Title', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'tp_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
				'condition'     => [
					'tp_title!' => '',
				],
			]
		);

        $this->add_control(
            'tp_subtitle',
            [
                'label'         => esc_html__('Subtitle', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Subtitle', AEFE_DOMAIN),
                'label_block'   => true,
            ]
        );

        $this->add_control(
			'tp_subtitle_tag',
			[
				'label'         => esc_html__('Subtitle HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h5',
				'condition'     => [
					'tp_subtitle!' => '',
				],
			]
		);

        $this->add_control(
            'tp_description',
            [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXTAREA,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum commodo dui fermentum ligula ullamcorper scelerisque.', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'tp_show_ribbon',
            [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'type'          => Controls_Manager::SWITCHER,
                'default'       => 'yes',
                'label_on'      => esc_html__('Show', AEFE_DOMAIN),
                'label_off'     => esc_html__('Hide', AEFE_DOMAIN),
                'separator'     => 'before',
            ]
        );

        $this->add_control(
            'tp_ribbon_skin', [
                'label'         => esc_html__('Ribbon Type', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Style 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Style 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Style 3', AEFE_DOMAIN),
                    'style-4' => esc_html__('Style 4', AEFE_DOMAIN),
                    'style-5' => esc_html__('Style 5', AEFE_DOMAIN),
                    'style-6' => esc_html__('Style 6', AEFE_DOMAIN),
                    'style-7' => esc_html__('Style 7', AEFE_DOMAIN),
                    'style-8' => esc_html__('Style 8', AEFE_DOMAIN),
                    'style-9' => esc_html__('Style 9', AEFE_DOMAIN),
                    'style-10' => esc_html__('Style 10', AEFE_DOMAIN),
                ],
                'condition'     => [
                    'tp_show_ribbon' => 'yes',
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
			'tp_ribbon',
			[
				'label'         => esc_html__('Ribbon Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Top Pick', AEFE_DOMAIN),
                'condition'     => [
                    'tp_show_ribbon' => 'yes',
                ],
			]
		);

        $this->add_control(
			'tp_ribbon_layout',
			[
				'label'         => esc_html__('Ribbon Position', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition'     => [
                    'tp_show_ribbon' => 'yes',
                    'tp_ribbon_skin' => ['style-1', 'style-3', 'style-5', 'style-6', 'style-7', 'style-8', 'style-10'],
                ],
                'default'       => 'left',
			]
		);

        $this->add_control(
			'tp_button',
			[
				'label'         => esc_html__('Button Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'dynamic'       => ['active' => true],
				'default'       => esc_html__('Click Here', AEFE_DOMAIN),
				'separator'     => 'before',
			]
		);

		$this->add_control(
			'tp_link',
			[
				'label'         => esc_html__('Link', AEFE_DOMAIN),
				'type'          => Controls_Manager::URL,
				'dynamic'       => ['active' => true],
			]
		);

        $this->end_controls_section();
        // End Content Section

        // Start Box Style Section       
        $this->start_controls_section(
            'tp_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'tp_box_padding', [
                'label'         => esc_html__('Box Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'=> '50',
                    'left'  => '50',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'tp_box_background_hover',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp',
            ]
        );

        $this->start_controls_tabs(
            'tp_box_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'tp_box_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'tp_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp',
            ]
        );

        $this->add_responsive_control(
            'tp_box_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'tp_box_shadow_normal',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-tp',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tp_box_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'tp_box_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp:hover',
            ]
        );

        $this->add_responsive_control(
            'tp_box_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'tp_box_shadow_hover',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-tp:hover',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Box Style Section

        // Start Content Box Style Section       
        $this->start_controls_section(
            'tp_content_box_style', [
                'label'         => esc_html__('Content Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'tp_content_padding', [
                'label'         => esc_html__('Content Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '20',
                    'right' => '20',
                    'bottom'=> '20',
                    'left'  => '20',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-content-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'     => 'before',
            ]
        );

        $this->end_controls_section();
        // End Content Box Style Section

        // Start Image Style Section
        $this->start_controls_section(
            'tp_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
            'tp_image_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'center',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-image-container' => 'text-align: {{VALUE}};',
				],
            ]
        );

        $this->add_responsive_control(
            'ct_image_width', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ct_image_radius', [
                'label'         => esc_html__('Image Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'tp_image_shadow_',
				'label'         => esc_html__('Image Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-image',
			]
		);

        $this->end_controls_section();
        // End Image Section

        // Start Title Style Section
        $this->start_controls_section(
            'tp_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tp_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_tp_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-title',
            ]
        );

        $this->add_responsive_control(
            'tp_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-title' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'tp_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Subtitle Style Section
        $this->start_controls_section(
            'tp_subtitle_style', [
                'label'         => esc_html__('Subtitle', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tp_subtitle_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_tp_subtitle',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-subtitle',
            ]
        );

        $this->add_responsive_control(
            'tp_subtitle_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-subtitle' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'tp_subtitle_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Subtitle Style Section

        // Start Description Style Section
        $this->start_controls_section(
            'tp_description_style', [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tp_description_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_tp_description',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-description',
            ]
        );

        $this->add_responsive_control(
            'tp_description_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-description' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'tp_description_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Description Style Section

        // Start Ribbon Style Section   
        $this->start_controls_section(
            'tp_ribbon_style', [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'tp_show_ribbon' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'tp_ribbon_space',
            [
                'label'         => esc_html__('Distance', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 35],
                'selectors' => [
                    '{{WRAPPER}} .ribbon-style-1' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ribbon-style-2, {{WRAPPER}} .ribbon-style-4' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-6.right, {{WRAPPER}} .tp-ribbon-container.ribbon-style-8.right' => 'right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-6.left, {{WRAPPER}} .tp-ribbon-container.ribbon-style-8.left' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'tp_ribbon_skin' => ['style-1', 'style-2', 'style-4', 'style-6', 'style-8'],
                ],
            ]
        );

        $this->add_responsive_control(
            'tp_ribbon_size',
            [
                'label'         => esc_html__('Ribbon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 100,
                        'max' => 300,
                    ],
                ],
                'default'       => ['size'  => 150],
                'selectors' => [
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-1' => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}}{{UNIT}}/2); border-bottom-left-radius: {{SIZE}}{{UNIT}}; border-bottom-right-radius: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-2,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-9,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10 .tp-ribbon' => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}}{{UNIT}}/3);',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-2:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4 .ribbon-after' => 'border-top-width: calc({{SIZE}}{{UNIT}}/6); border-bottom-width: calc({{SIZE}}{{UNIT}}/6);',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-3,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-6,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-7' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-6:after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8 .ribbon-after' => 'border-right-width: calc({{SIZE}}{{UNIT}}/2); border-left-width: calc({{SIZE}}{{UNIT}}/2);',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-9' => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}}{{UNIT}}/2); margin: 0 calc({{SIZE}}{{UNIT}}/2);',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-9:before' => 'border-width: calc({{SIZE}}{{UNIT}}/4); left: calc({{SIZE}}{{UNIT}}/-2);',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-9:after' => 'border-top-width: calc({{SIZE}}{{UNIT}}/4); border-bottom-width: calc({{SIZE}}{{UNIT}}/4); border-left-width: calc({{SIZE}}{{UNIT}}/4); right: calc({{SIZE}}{{UNIT}}/-4);',
                ],
                'condition'     => [
                    'tp_ribbon_skin!' => 'style-5',
                ],
            ]
        );

        $this->add_control(
			'tp_ribbon_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .tp-ribbon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tp_ribbon_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#000',
				'selectors'     => [
					'{{WRAPPER}} .tp-ribbon-container.ribbon-style-1,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-1:after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-1:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-2,
                    {{WRAPPER}} .ribbon-style-3,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4:after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-5 .tp-ribbon,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-6,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-7,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8:after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-9,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10 .tp-ribbon,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10:after' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-2:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-4 .ribbon-after' => 'border-top-color: {{VALUE}}; border-bottom-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-2:after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-8 .ribbon-after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10 .tp-ribbon:after' => 'border-top-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-2 .ribbon-after,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-6:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-10 .tp-ribbon:before' => 'border-bottom-color: {{VALUE}};',                    
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-5:before,
                    {{WRAPPER}} .tp-ribbon-container.ribbon-style-5:after' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-6:after' => 'border-left-color: {{VALUE}}; border-right-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-9:before' => 'border-top-color: {{VALUE}}; border-bottom-color: {{VALUE}}; border-right-color: {{VALUE}};',
                    '{{WRAPPER}} .tp-ribbon-container.ribbon-style-9:after' => 'border-left-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'tp_ribbon_text_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .tp-ribbon-text',
			]
		);  

        $this->add_responsive_control(
            'tp_ribbon_padding', [
                'label'         => esc_html__('Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'default'   => [
                    'top'   => '20',
                    'right' => '5',
                    'bottom'=> '20',
                    'left'  => '5',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .tp-ribbon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
                    'tp_ribbon_skin!' => 'style-5',
                ],
            ]
        );

        $this->end_controls_section();
        // End Ribbon Style Section

        // Start Button Style Section
        $this->start_controls_section(
            'tp_button_style', [
                'label'         => esc_html__('Button', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_tp_button',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-button',
            ]
        );

        $this->add_responsive_control(
            'tp_button_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-button-wrapper' => 'text-align: {{VALUE}};',
				],
            ]
        );

        $this->add_responsive_control(
            'tp_button_padding', [
                'label'         => esc_html__('Button Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '30',
                    'bottom'=> '10',
                    'left'  => '30',
                    'isLinked'  => false,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tp_button_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'tp_button_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'tp_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tp_button_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#000',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-button' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'tp_button_border',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-button',
            ]
        );

        $this->add_responsive_control(
            'tp_button_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'tp_button_shadow_normal',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-button',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tp_button_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'tp_button_hover_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tp_button_background_hover_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-tp .tp-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'tp_button_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-button:hover',
            ]
        );

        $this->add_responsive_control(
            'tp_button_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-tp .tp-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'tp_button_shadow_hover',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-tp .tp-button:hover',
			]
		);
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Button Style Section
    }

    protected function render_ribbons() {
        $settings       = $this->get_settings();

        if($settings['tp_show_ribbon'] === 'yes') { 
            if($settings['tp_ribbon_skin'] === 'style-1') { ?>
                <div class="tp-ribbon-container ribbon-style-1 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <div class="tp-ribbon-text"><?php esc_html_e($settings['tp_ribbon']); ?></div>
                    </div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-2') { ?>
                <div class="tp-ribbon-container ribbon-style-2 right">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php esc_html_e($settings['tp_ribbon']); ?></span>
                    </div>
                    <div class="ribbon-after"></div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-3') { ?>
                <div class="tp-ribbon-container ribbon-style-3 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php esc_html_e($settings['tp_ribbon']); ?></span>
                    </div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-4') { ?>
                <div class="tp-ribbon-container ribbon-style-4 left">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php esc_html_e($settings['tp_ribbon']); ?></span>
                    </div>
                    <div class="ribbon-after"></div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-5') { ?>
                <div class="tp-ribbon-container ribbon-style-5 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php esc_html_e($settings['tp_ribbon']); ?></span>
                    </div>                    
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-6') { ?>
                <div class="tp-ribbon-container ribbon-style-6 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php echo $settings['tp_ribbon']; ?></span>
                    </div>
                    <div class="ribbon-after"></div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-7') { ?>
                <div class="tp-ribbon-container ribbon-style-7 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php echo $settings['tp_ribbon']; ?></span>
                    </div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-8') { ?>
                <div class="tp-ribbon-container ribbon-style-8 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php echo $settings['tp_ribbon']; ?></span>
                    </div>
                    <div class="ribbon-after"></div>
                </div>
            <?php }
            elseif($settings['tp_ribbon_skin'] === 'style-9') { ?>
                <div class="tp-ribbon-container ribbon-style-9 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php echo $settings['tp_ribbon']; ?></span>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="tp-ribbon-container ribbon-style-10 <?php esc_attr_e($settings['tp_ribbon_layout']); ?>">
                    <div class="tp-ribbon">
                        <span class="tp-ribbon-text"><?php echo $settings['tp_ribbon']; ?></span>
                    </div>
                </div>
            <?php }
        }
        return;
    }

    /**
     * Render Call to Action Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();

        $title_tag      = $settings['tp_title_tag'];
        $subtitle_tag   = $settings['tp_subtitle_tag'];
        $button_link    = $settings['tp_link']['url'];
		$target 		= $settings['tp_link']['is_external'] ? ' target="_blank"' : '';
		$rel 			= $settings['tp_link']['nofollow'] ? ' rel="nofollow"' : '';

        switch ($settings['tp_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/top-pick/style-1.php'; // Style 1
                break;
			case 'style-2':
				include AEFE_PATH . 'include/top-pick/style-2.php'; // Style 2
				break;
            default:
                include AEFE_PATH . 'include/top-pick/style-1.php'; // Default
                break;
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Top_Pick_Elementor_Widget());