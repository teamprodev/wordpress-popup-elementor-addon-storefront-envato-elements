<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Call to Action
 */
class Call_to_Action_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-call-to-action';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Call to Action', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-image-rollover';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['call to action', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-call-to-action'];
    }

    // Adding the controls fields for the Call to Action Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'cta_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'cta_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

		$this->add_control(
			'cta_image',
			[
				'label'         => esc_html__('Choose Image', AEFE_DOMAIN),
				'type'          => Controls_Manager::MEDIA,
				'dynamic'       => [
					'active' => true,
				],
				'default'       => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'separator'     => 'before',
                'condition'     => [
					'cta_skin' => 'style-2',
				],
			]
		);

        $this->add_responsive_control(
			'cta_image_layout',
			[
				'label'         => esc_html__('Position', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'above' => [
						'title' => esc_html__('Above', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
                'default'       => 'left',
                'mobile_default' => 'above',
				'prefix_class'  => 'cta-image-align%s-',
				'condition'     => [
					'cta_skin' => 'style-2',
				],
			]
		);

        $this->add_control(
            'cta_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Call To Action', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
            'cta_description',
            [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXTAREA,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('The Call-To-Action block is great for bringing attention to actionable items or buttons that you want your users to click!', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'cta_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
				'condition'     => [
					'cta_title!' => '',
				],
			]
		);

        $this->add_control(
			'cta_button',
			[
				'label'         => esc_html__('Button Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'dynamic'       => ['active' => true],
				'default'       => esc_html__('Click Here', AEFE_DOMAIN),
				'separator'     => 'before',
			]
		);

		$this->add_control(
			'cta_link',
			[
				'label'         => esc_html__('Link', AEFE_DOMAIN),
				'type'          => Controls_Manager::URL,
				'dynamic'       => ['active' => true],
			]
		);

        $this->end_controls_section();
        // End Content Section

        // Start Box Style Section       
        $this->start_controls_section(
            'cta_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'cta_box_padding', [
                'label'         => esc_html__('Box Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'=> '50',
                    'left'  => '50',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'cta_box_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'cta_box_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'cta_box_background_hover',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'cta_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta',
            ]
        );

        $this->add_responsive_control(
            'cta_box_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'cta_box_shadow_normal',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-cta',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'cta_box_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'cta_box_background',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'cta_box_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta:hover',
            ]
        );

        $this->add_responsive_control(
            'cta_box_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'cta_box_shadow_hover',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-cta:hover',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Box Style Section

        // Start Content Box Style Section       
        $this->start_controls_section(
            'cta_content_box_style', [
                'label'         => esc_html__('Content Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
					'cta_skin' => 'style-2',
				],
            ]
        );

        $this->add_responsive_control(
            'cta_content_padding', [
                'label'         => esc_html__('Content Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '20',
                    'right' => '20',
                    'bottom'=> '20',
                    'left'  => '20',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-content-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'     => 'before',
            ]
        );

        $this->add_responsive_control(
			'cta_vertical_position',
			[
				'label'     => esc_html__('Vertical Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__('Top', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__('Middle', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_html__('Bottom', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'default'       => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta.ct-style-2 .cta-container' => 'align-items: {{VALUE}};',
                ],
			]
		);

        $this->end_controls_section();
        // End Content Box Style Section

        // Start Image Style Section
        $this->start_controls_section(
            'cta_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
					'cta_skin' => 'style-2',
				],
            ]
        );

        $this->add_responsive_control(
            'ct_image_width', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta.ct-style-2 .cta-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ct_image_radius', [
                'label'         => esc_html__('Image Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta.ct-style-2 .cta-image' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ct_image_box_width', [
                'label'         => esc_html__('Image Box Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
                'default'       => ['unit' => '%', 'size' => 50],
                'selectors'     => [
                    '{{WRAPPER}}.cta-image-align-left .affiliate-elements-cta.ct-style-2 .cta-image-container, {{WRAPPER}}.cta-image-align-right .affiliate-elements-cta.ct-style-2 .cta-image-container' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.cta-image-align-left .affiliate-elements-cta.ct-style-2 .cta-content-container, {{WRAPPER}}.cta-image-align-right .affiliate-elements-cta.ct-style-2 .cta-content-container' => 'width: calc(100% - {{SIZE}}{{UNIT}});',
                ],
                'condition'     => [
					'cta_image_layout!' => 'above',
				],
            ]
        );

        $this->start_controls_tabs(
            'cta_image_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'cta_image_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'cta_image_normal',
				'selector' => '{{WRAPPER}} .affiliate-elements-cta .cta-image',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'cta_image_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'cta_image_hover',
				'selector' => '{{WRAPPER}} .affiliate-elements-cta:hover .cta-image',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Image Section

        // Start Title Style Section
        $this->start_controls_section(
            'cta_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'cta_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cta_title_hover_color', [
                'label'         => esc_html__('Hover Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta:hover .cta-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_cta_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-title',
            ]
        );

        $this->add_responsive_control(
            'cta_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'center',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-title' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'cta_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 20],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Description Style Section
        $this->start_controls_section(
            'cta_description_style', [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'cta_description_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'cta_description_hover_color', [
                'label'         => esc_html__('Hover Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta:hover .cta-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_cta_description',
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-description',
            ]
        );

        $this->add_responsive_control(
            'cta_description_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'center',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-description' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'cta_description_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 30],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Description Style Section

        // Start Button Style Section
        $this->start_controls_section(
            'cta_button_style', [
                'label'         => esc_html__('Button', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_cta_button',
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-button',
            ]
        );

        $this->add_responsive_control(
            'cta_button_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'center',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-button-wrapper' => 'text-align: {{VALUE}};',
				],
            ]
        );

        $this->add_responsive_control(
            'cta_button_padding', [
                'label'         => esc_html__('Button Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '60',
                    'bottom'=> '10',
                    'left'  => '60',
                    'isLinked'  => false,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'cta_button_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'cta_button_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'cta_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_button_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-button' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'cta_button_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'double',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '5',
                            'right'     => '5',
                            'bottom'    => '5',
                            'left'      => '5',
                            'isLinked'  => true,
                        ],
                    ],
                    'color'     => [
                        'default'   => '#ffffff',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-button',
            ]
        );

        $this->add_responsive_control(
            'cta_button_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'cta_button_shadow_normal',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-button',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'cta_button_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'cta_button_hover_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_button_background_hover_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-cta .cta-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'cta_button_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-button:hover',
            ]
        );

        $this->add_responsive_control(
            'cta_button_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-cta .cta-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'cta_button_shadow_hover',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-cta .cta-button:hover',
			]
		);
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Button Style Section
    }

    /**
     * Render Call to Action Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();

        $title_tag      = $settings['cta_title_tag'];
        $button_link    = $settings['cta_link']['url'];
		$target 		= $settings['cta_link']['is_external'] ? ' target="_blank"' : '';
		$rel 			= $settings['cta_link']['nofollow'] ? ' rel="nofollow"' : '';

        switch ($settings['cta_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/call-to-action/style-1.php'; // Style 1
                break;
			case 'style-2':
				include AEFE_PATH . 'include/call-to-action/style-2.php'; // Style 2
				break;
            default:
                include AEFE_PATH . 'include/call-to-action/style-1.php'; // Default
                break;
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Call_to_Action_Elementor_Widget());