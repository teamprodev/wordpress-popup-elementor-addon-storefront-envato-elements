<?php
namespace Elementor;

use Elementor\Icons_Manager;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Notice Box
 */
class Notice_Box_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-notice-box';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Notice Box', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-alert';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['notice box', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-notice-box'];
    }

    // Funcyion for include js
    public function get_script_depends()
    {
        return ['aefe-notice-box-js'];
    }

    // Adding the controls fields for the Notice Box Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'nb_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'nb_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
            'nb_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Title', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

		$this->add_control(
			'nb_text',
			[
				'label' => esc_html__( 'Text', AEFE_DOMAIN),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'List Item', AEFE_DOMAIN),
				'default' => esc_html__( 'List Item', AEFE_DOMAIN),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'nb_selected_icon',
			[
				'label' => esc_html__( 'Icon', AEFE_DOMAIN),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
				'fa4compatibility' => 'icon',
			]
		);  
    
        $this->add_control(
			'nb_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
			]
		);

        $this->add_responsive_control(
			'nb_vertical_position',
			[
				'label'     => esc_html__('Vertical Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__('Start', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_html__('End', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'default'       => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-nb.nb-style-1 .notice-box' => 'align-items: {{VALUE}};',
                ],
			]
		);

        $this->end_controls_section();
        // End Content Section

        // Start Box Style Section       
        $this->start_controls_section(
            'nb_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'nb_box_padding', [
                'label'         => esc_html__('Box Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '20',
                    'right' => '20',
                    'bottom'=> '20',
                    'left'  => '20',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-nb .nb-container .notice-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'nb_box_background_hover',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-nb .nb-container .notice-box',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'nb_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-nb .nb-container .notice-box',
            ]
        );

        $this->add_responsive_control(
            'nb_box_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-nb .nb-container .notice-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'nb_box_shadow_normal',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-nb .nb-container',
			]
		);

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Box Style Section

		// Start Icon Style Section
		$this->start_controls_section(
			'section_icon',
			[
				'label' => esc_html__( 'Icon', AEFE_DOMAIN),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);  

        $this->add_control(
			'nb_icon_color',
			[
				'label' => esc_html__( 'Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-icon i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .notice-box-wrapper .notice-box-icon svg' => 'fill: {{VALUE}};',
				],
				'default' => '#fff',
			]
		);

        $this->add_control(
			'nb_icon_background_color',
			[
				'label' => esc_html__( 'Background Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-icon' => 'background-color: {{VALUE}};',
				],
				'default' => '#000',
			]
		);

        $this->add_responsive_control(
            'nb_icon_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'flex-start'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'flex-start',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-nb .notice-box .notice-icon-container' => 'justify-content: {{VALUE}};',
				],
                'condition'     => [
                    'nb_skin' => 'style-2',
                ],
            ]
        );

		$this->add_responsive_control(
			'nb_icon_size',
			[
				'label' => esc_html__( 'Size', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 6,
					],
				],
                'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-icon i' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .notice-box-wrapper .notice-box-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'nb_icon_spacing',
			[
				'label' => esc_html__( 'Spacing', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 0,
					],
				],
                'selectors' => [
					'{{WRAPPER}} .affiliate-elements-nb.nb-style-1 .notice-box-wrapper .notice-box-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .affiliate-elements-nb.nb-style-2 .notice-box-wrapper .notice-box-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'nb_icon_padding',
			[
				'label' => esc_html__( 'Padding', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 0,
					],
				],
                'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-icon' => 'padding: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
            'nb_icon_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '30',
                    'right' => '30',
                    'bottom'=> '30',
                    'left'  => '30',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .notice-box-wrapper .notice-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
		// End Icon Style Section

        // Start Title Style Section
        $this->start_controls_section(
            'nb_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'nb_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-nb .nb-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_nb_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-nb .nb-title',
            ]
        );

        $this->add_responsive_control(
            'nb_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-nb .nb-title' => 'text-align: {{VALUE}};',
				],
                'condition'     => [
                    'nb_skin' => 'style-2',
                ],
            ]
        );

		$this->add_responsive_control(
			'nb_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
					'selectors'     => [
						'{{WRAPPER}} .affiliate-elements-nb .nb-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Description Style Section
		$this->start_controls_section(
			'section_description',
			[
				'label' => esc_html__( 'Description', AEFE_DOMAIN),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);  

        $this->add_control(
			'nb_description_color',
			[
				'label' => esc_html__( 'Text Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-content .notice-box-description' => 'color: {{VALUE}};',
				],
				'default' => '#000',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'selector' => '{{WRAPPER}} .notice-box-wrapper .notice-box-content .notice-box-description',
			]
		);

        $this->add_responsive_control(
            'nb_description_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .notice-box-wrapper .notice-box-content .notice-box-description' => 'text-align: {{VALUE}};',
				],
                'condition'     => [
                    'nb_skin' => 'style-2',
                ],
            ]
        );

		$this->end_controls_section();
		// End Description Section

        // Start Close button Section
		$this->start_controls_section(
			'section_close_button',
			[
				'label' => esc_html__( 'Close Button', AEFE_DOMAIN),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);  

        $this->add_control(
			'nb_close_button_color',
			[
				'label' => esc_html__( 'Icon Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .notice-box-wrapper .nb-close-btn' => 'color: {{VALUE}};',
				],
				'default' => 'rgb(0 0 0 / 50%)',
			]
		);

        $this->add_responsive_control(
			'nb_close_button_size',
			[
				'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 20],
					'selectors'     => [
						'{{WRAPPER}} .notice-box-wrapper .nb-close-btn' => 'font-size: {{SIZE}}{{UNIT}};',
					],
			]
		);

		$this->end_controls_section();
		// End Close button Section
    }

    /**
     * Render Notice Box Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();

        $title_tag      = $settings['nb_title_tag'];

        switch ($settings['nb_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/notice-box/style-1.php'; // Style 1
                break;
            case 'style-2':
                include AEFE_PATH . 'include/notice-box/style-2.php'; // Style 2
                break;
            default:
                include AEFE_PATH . 'include/notice-box/style-1.php'; // Default
                break;
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Notice_Box_Elementor_Widget());