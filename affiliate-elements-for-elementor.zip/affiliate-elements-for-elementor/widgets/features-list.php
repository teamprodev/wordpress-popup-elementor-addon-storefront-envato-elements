<?php
namespace Elementor;

use Elementor\Icons_Manager;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Features List
 */
class Features_List_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-features-list';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Features List', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-bullet-list';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['features list', 'aefe', 'affiliate elements'];
	}

    // Function for include css
    public function get_style_depends()
    {
        return ['aefe-features-list'];
    }

    // Adding the controls fields for the Call to Action Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'fl_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'fl_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

		$this->add_control(
			'fl_image',
			[
				'label'         => esc_html__('Choose Image', AEFE_DOMAIN),
				'type'          => Controls_Manager::MEDIA,
				'dynamic'       => [
					'active' => true,
				],
				'default'       => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'separator'     => 'before',
			]
		);

        $this->add_control(
            'fl_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Title', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'fl_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
			]
		);
		
		$repeater = new Repeater();

		$repeater->add_control(
			'fl_text',
			[
				'label' => esc_html__( 'Text', AEFE_DOMAIN),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'List Item', AEFE_DOMAIN),
				'default' => esc_html__( 'List Item', AEFE_DOMAIN),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'fl_selected_icon',
			[
				'label' => esc_html__( 'Icon', AEFE_DOMAIN),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
				'fa4compatibility' => 'icon',
			]
		);

		$this->add_control(
			'fl_icon_list',
			[
				'label' => esc_html__( 'Items', AEFE_DOMAIN),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'fl_text' => esc_html__( 'List Item #1', AEFE_DOMAIN),
						'fl_selected_icon' => [
							'value' => 'fas fa-check',
							'library' => 'fa-solid',
						],
					],
					[
						'fl_text' => esc_html__( 'List Item #2', AEFE_DOMAIN),
						'fl_selected_icon' => [
							'value' => 'fas fa-times',
							'library' => 'fa-solid',
						],
					],
					[
						'fl_text' => esc_html__( 'List Item #3', AEFE_DOMAIN),
						'fl_selected_icon' => [
							'value' => 'fas fa-dot-circle',
							'library' => 'fa-solid',
						],
					],
				],				
			]
		);

        $this->add_control(
			'fl_list_style',
			[
				'label'         => esc_html__('Icon List Style', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'column-1' => esc_html__('1 Column', AEFE_DOMAIN),
					'column-2' => esc_html__('2 Column', AEFE_DOMAIN),
				],
				'default'       => 'column-1',
			]
		);

        $this->end_controls_section();
        // End Content Section

        // Start Box Style Section       
        $this->start_controls_section(
            'fl_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'fl_image_position',
			[
				'label'     => esc_html__('Image Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'0' => [
						'title' => esc_html__('Start', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'1' => [
						'title' => esc_html__('End', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
                'default'       => '0',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-content-container' => 'order: {{VALUE}};',
                ],
                'condition'     => [
                    'fl_skin' => 'style-1',
                ],
			]
		);

        $this->add_responsive_control(
			'fl_image_position_2',
			[
				'label'     => esc_html__('Image Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'0' => [
						'title' => esc_html__('Start', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'1' => [
						'title' => esc_html__('End', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'default'       => '0',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-content-container' => 'order: {{VALUE}};',
                ],
                'condition'     => [
                    'fl_skin' => 'style-2',
                ],
			]
		);

		$this->add_responsive_control(
			'fl_vertical_position',
			[
				'label'     => esc_html__('Vertical Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__('Start', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_html__('End', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'default'       => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl.fl-style-1 .fl-container' => 'align-items: {{VALUE}};',
                ],
			]
		);

        $this->add_responsive_control(
            'fl_box_padding', [
                'label'         => esc_html__('Box Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'=> '50',
                    'left'  => '50',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'fl_box_background_hover',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-container',
            ]
        );

        $this->start_controls_tabs(
            'fl_box_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'fl_box_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'fl_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-container',
            ]
        );

        $this->add_responsive_control(
            'fl_box_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'fl_box_shadow_normal',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-container',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'fl_box_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'fl_box_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-container:hover',
            ]
        );

        $this->add_responsive_control(
            'fl_box_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-container:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'fl_box_shadow_hover',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-container:hover',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Box Style Section

        // Start Content Box Style Section       
        $this->start_controls_section(
            'fl_content_box_style', [
                'label'         => esc_html__('Content Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'fl_content_padding', [
                'label'         => esc_html__('Content Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '20',
                    'right' => '20',
                    'bottom'=> '20',
                    'left'  => '20',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-content-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'     => 'before',
            ]
        );
		
        $this->end_controls_section();
        // End Content Box Style Section

        // Start Image Style Section
        $this->start_controls_section(
            'fl_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'fl_image_width', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'fl_image_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fl .fl-image-container' => 'text-align: {{VALUE}};',
				],
            ]
        );        

        $this->add_responsive_control(
            'fl_image_radius', [
                'label'         => esc_html__('Image Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-image' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Image Section

        // Start Title Style Section
        $this->start_controls_section(
            'fl_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'fl_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fl .fl-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_fl_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fl .fl-title',
            ]
        );

        $this->add_responsive_control(
            'fl_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fl .fl-title' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'fl_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
					'selectors'     => [
						'{{WRAPPER}} .affiliate-elements-fl .fl-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
			]
		);

        $this->end_controls_section();
        // End Title Style Section
		
		// Start Icon List Style Section
		$this->start_controls_section(
			'section_icon_list',
			[
				'label' => esc_html__( 'Icon List', AEFE_DOMAIN),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label' => esc_html__( 'Space Between', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .features-list' => 'row-gap: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_align',
			[
				'label' => esc_html__( 'Alignment', AEFE_DOMAIN),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default'  => 'left',
				'selectors' => [
					'{{WRAPPER}} .features-list .fl-content' => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'fl_icon_options',
			[
				'label'         => esc_html__('Icon', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
			]
		);

        $this->add_control(
			'fl_icon_color',
			[
				'label' => esc_html__( 'Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .features-list .fl-content i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .features-list .fl-content svg' => 'fill: {{VALUE}};',
				],
				'default' => '#000',
			]
		);

		$this->add_responsive_control(
			'fl_icon_size',
			[
				'label' => esc_html__( 'Size', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min' => 6,
					],
				],
                'selectors' => [
					'{{WRAPPER}} .features-list .fl-content i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .features-list .fl-content svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'fl_text_options',
			[
				'label'         => esc_html__('Text ', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
			]
		);

        $this->add_control(
			'fl_text_color',
			[
				'label' => esc_html__( 'Text Color', AEFE_DOMAIN),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .features-list .fl-content' => 'color: {{VALUE}};',
				],
				'default' => '#000',
			]
		);

		$this->add_control(
			'fl_text_indent',
			[
				'label' => esc_html__( 'Text Indent', AEFE_DOMAIN),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .features-list .fl-content i, {{WRAPPER}} .features-list .fl-content svg' => 'padding-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'selector' => '{{WRAPPER}} .features-list .fl-content',
			]
		);

		$this->end_controls_section();
		// End Icon List Style Section
    }

    /**
     * Render Features List Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();

        $title_tag      = $settings['fl_title_tag'];

        switch ($settings['fl_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/features-list/style-1.php'; // Style 1
                break;
            case 'style-2':
                include AEFE_PATH . 'include/features-list/style-2.php'; // Style 2
                break;
            default:
                include AEFE_PATH . 'include/features-list/style-1.php'; // Default
                break;
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Features_List_Elementor_Widget());