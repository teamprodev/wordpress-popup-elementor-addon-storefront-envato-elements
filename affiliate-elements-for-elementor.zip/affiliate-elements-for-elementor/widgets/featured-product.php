<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;   
}

// Class Featured Product
class Featured_Product_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-featured-product';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Featured Product', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-image-box';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['featured product', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-featured-product'];
    }

    // Adding the controls fields for the Featured Product Element
    protected function _register_controls() {

        // Start General Section
        $this->start_controls_section(
            'fp_section_general', array(
                'label'         => esc_html__('General', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'fp_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Design 3', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
            'fp_image',
            [
                'label'     => esc_html__('Image', AEFE_DOMAIN),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
					'url'   => Utils::get_placeholder_image_src(),
				],
            ]
        );

        $this->add_control(
            'fp_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Title', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'fp_content_type', [
                'label'         => esc_html__('Content Type', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'desc' => esc_html__('Description', AEFE_DOMAIN),
                    'list' => esc_html__('List', AEFE_DOMAIN),
                ],
                'default'       => 'desc',
            ]
        );

        $this->add_control(
            'fp_description',
            [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', AEFE_DOMAIN),
                'condition'     => [
					'fp_content_type' => 'desc',
				],
            ]
        );

        $this->add_control(
            'fp_list_icon',
            [
                'label'         => esc_html__('List Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-check-circle',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'fp_content_type' => 'list',
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'fp_product_list',
            [
                'type'          => Controls_Manager::TEXTAREA,
                'label_block'   => true,
                'rows'          => 2,
                'default'       => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'fp_product_lists',
			[
				'label'         => esc_html__('List', AEFE_DOMAIN),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'render_type'   => 'template',
                'default'       => [
                    [
                        'fp_product_list' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'fp_product_list' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                    [
                        'fp_product_list' => esc_html__('Lorem ipsum dolor sit amet', AEFE_DOMAIN),
                    ],
                ],
                'title_field'   => '{{{ fp_product_list }}}',
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
        );

        $this->add_control(
			'fp_price',
			[
				'label'         => esc_html__('Price', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('$63.50', AEFE_DOMAIN),
                'separator'     => 'before',
			]
		);

        $this->add_control(
			'fp_original_price',
			[
				'label'         => esc_html__('Original Price', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('$83.50', AEFE_DOMAIN),
			]
		);

        $this->add_control(
			'fp_button',
			[
				'label'         => esc_html__('Button Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('BUY NOW', AEFE_DOMAIN),
                'separator'     => 'before',
                'condition'     => [
					'fp_skin!' => 'style-2',
				],
			]
		);

        $this->add_control(
            'fp_button_icon',
            [
                'label'         => esc_html__('Button Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fa fa-shopping-bag',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
					'fp_skin' => 'style-2',
				],
            ]
        );

		$this->add_control(
			'fp_link',
			[
				'label'         => esc_html__('Link', AEFE_DOMAIN),
				'type'          => Controls_Manager::URL,
			]
		);

        $this->add_control(
            'fp_show_ribbon',
            [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'type'          => Controls_Manager::SWITCHER,
                'default'       => 'yes',
                'label_on'      => esc_html__('Show', AEFE_DOMAIN),
                'label_off'     => esc_html__('Hide', AEFE_DOMAIN),
                'separator'     => 'before',
            ]
        );

        $this->add_control(
            'fp_ribbon_skin', [
                'label'         => esc_html__('Ribbon Type', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Style 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Style 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Style 3', AEFE_DOMAIN),
                    'style-4' => esc_html__('Style 4', AEFE_DOMAIN),
                ],
                'condition'     => [
                    'fp_show_ribbon' => 'yes',
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
			'fp_ribbon',
			[
				'label'         => esc_html__('Ribbon Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('NEW', AEFE_DOMAIN),
                'condition'     => [
                    'fp_show_ribbon' => 'yes',
                ],
			]
		);

        $this->add_control(
            'fp_ribbon_icon',
            [
                'label'         => esc_html__('Ribbon Icon', AEFE_DOMAIN),
                'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fas fa-trophy',
                    'library'   => 'fa-solid',
                ],
                'condition'     => [
                    'fp_show_ribbon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'fp_rating', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'type'          => Controls_Manager::NUMBER,
                'min'           => 0,
                'max'           => 5,
                'step'          => 0.1,
                'default'       => 4.5,
                'separator'     => 'before',
            ]
        );

        $this->end_controls_section();
        // End General Section

        // Start Box Style Section       
        $this->start_controls_section(
            'fp_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'fp_box_padding', [
                'label'         => esc_html__('Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '30',
                    'right' => '30',
                    'bottom'=> '30',
                    'left'  => '30',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fp .fp-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'fp_box_color', [
                'label'         => esc_html__('Background Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fp .fp-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'fp_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-fp',
            ]
        );

        $this->add_responsive_control(
            'fp_box_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-fp' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'fp_box_shadow',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-fp',
			]
		);

        $this->end_controls_section();
        // End Box Style Section

        // Start Title Style Section       
        $this->start_controls_section(
            'fp_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'fp_title_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-title' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_fp_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fp .fp-title',
            ]
        );

        $this->add_responsive_control(
			'fp_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Content Style Section       
        $this->start_controls_section(
            'fp_content_style', [
                'label'         => esc_html__('Content', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'fp_icon_color',
			[
				'label'         => esc_html__('Icon Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-list-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-fp .fp-list-icon svg' => 'fill: {{VALUE}};',
				],
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
		);

        $this->add_responsive_control(
			'fp_icon_size',
			[
				'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 18],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-list-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .affiliate-elements-fp .fp-list-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
		);

        $this->add_control(
			'fp_icon_spacing',
			[
				'label'         => esc_html__('Icon Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-list-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
		);

        $this->add_control(
			'fp_content_color',
			[
				'label'         => esc_html__('Content Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-content' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_fp_content',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fp .fp-content',
            ]
        );
        
        $this->add_responsive_control(
			'fp_content_spacing',
			[
				'label'         => esc_html__('List Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-lists .fp-list' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
		);

        $this->add_responsive_control(
			'fp_content_spacing_bottom',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-lists' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_content_type' => 'list',
				],
			]
		);

        $this->add_responsive_control(
			'fp_content_spacing_bottom_content',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_content_type' => 'desc',
				],
			]
		);

        $this->end_controls_section();
        // End Content Style Section

        // Start Image Style Section       
        $this->start_controls_section(
            'fp_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'fp_image_width',
			[
				'label'         => esc_html__('Width', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 500,
                    ],
                ],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'fp_image_radius',
			[
				'label'         => esc_html__('Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-image' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'fp_image_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 20],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Image Style Section

        // Start Price Style Section       
        $this->start_controls_section(
            'fp_price_style', [
                'label'         => esc_html__('Price', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
					'fp_price!' => '',
				],
            ]
        );

        $this->add_control(
			'fp_price_color',
			[
				'label'         => esc_html__('Price Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-price' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_fp_price',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fp .fp-price',
            ]
        );

        $this->add_control(
			'fp_original_price_color',
			[
				'label'         => esc_html__('Original Price Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#717171',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-original-price' => 'color: {{VALUE}};',
				],
                'condition'     => [
					'fp_original_price!' => '',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Original Price Typography', AEFE_DOMAIN),
                'name'          => 'typography_fp_orginal_price',
                'selector'      => '{{WRAPPER}} .affiliate-elements-fp .fp-original-price',
                'condition'     => [
					'fp_original_price!' => '',
				],
            ]
        );

        $this->add_responsive_control(
			'fp_price_space_between',
			[
				'label'         => esc_html__('Space Between', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 5],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-original-price' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_original_price!' => '',
				],
			]
		);

        $this->add_responsive_control(
			'fp_price_spacing',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-price-container' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_skin' => 'style-2',
				],
			]
		);

        $this->end_controls_section();
        // End Price Style Section

        // Start Button Style Section       
        $this->start_controls_section(
            'fp_button_style', [
                'label'         => esc_html__('Button', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('fp_button_color_setting');

        $this->start_controls_tab(
			'fp_button_normal_tab',
			[
				'label'         => esc_html__('Normal', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'fp_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .fp-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .fp-button svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fp_button_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .fp-button' => 'background-color: {{VALUE}};',
				],
                'separator'     => 'after',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'fp_button_hover_tab',
			[
				'label'         => esc_html__('Hover', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'fp_button_color_hover',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .fp-button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .fp-button:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fp_button_background_color_hover',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .fp-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'fp_button_border_color_hover',
			[
				'label'         => esc_html__('Border Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .fp-button:hover' => 'border-color: {{VALUE}};',
				],
                'separator'     => 'after',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'fp_button_text_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .fp-button',
                'condition'     => [
					'fp_skin!' => 'style-2',
				],
			]
		);

        $this->add_responsive_control(
            'fp_button_icon_size',
            [
                'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .fp-button' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .fp-button svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
					'fp_skin' => 'style-2',
				],
            ]
        );

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'fp_button_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .fp-button',
			]
		);

		$this->add_control(
			'fp_button_border_radius',
			[
				'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .fp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'fp_button_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .fp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'fp_button_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp.fp-style-2 .fp-button' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_skin' => 'style-2',
				],
			]
		);

        $this->end_controls_section();
        // End Button Style Section

        // Start Rating Style Section   
        $this->start_controls_section(
            'fp_rating_style', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'fp_star_size',
            [
                'label'         => esc_html__('Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'       => ['size'  => 30],
                'selectors' => [
                    '{{WRAPPER}} .fp-rating .elementor-star-rating' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_star_space',
            [
                'label'         => esc_html__('Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .fp-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .fp-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'fp_star_spacing_bottom',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-fp .fp-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'fp_skin' => 'style-2',
				],
			]
		);

        $this->add_control(
            'fp_stars_color',
            [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
                'selectors'     => [
                    '{{WRAPPER}} .fp-rating .elementor-star-rating i:before' => 'color: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'fp_stars_unmarked_color',
            [
                'label'         => esc_html__('Unmarked Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FDA0A0',
                'selectors'     => [
                    '{{WRAPPER}} .fp-rating .elementor-star-rating i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Rating Style Section

        // Start Ribbon Style Section   
        $this->start_controls_section(
            'fp_ribbon_style', [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'fp_show_ribbon' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_space',
            [
                'label'         => esc_html__('Distance', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 35],
                'selectors' => [
                    '{{WRAPPER}} .fp-ribbon' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => 'style-2',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_size',
            [
                'label'         => esc_html__('Ribbon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                    ],
                ],
                'default'       => ['size'  => 150],
                'selectors' => [
                    '{{WRAPPER}} .fp-ribbon-container.ribbon-style-1' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; top: calc(-{{SIZE}}{{UNIT}} / 2); left: calc(-{{SIZE}}{{UNIT}} / 2);',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => 'style-1',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_size_three',
            [
                'label'         => esc_html__('Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'default'       => ['size'  => 75],
                'selectors' => [
                    '{{WRAPPER}} .ribbon-style-3 .fp-ribbon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => 'style-3',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_radius',
            [
                'label'         => esc_html__('Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'       => ['size'  => 100],
                'selectors' => [
                    '{{WRAPPER}} .ribbon-style-3 .fp-ribbon' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => 'style-3',
                ],
            ]
        );

        $this->add_control(
			'fp_ribbon_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .fp-ribbon' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'fp_ribbon_icon_color',
			[
				'label'         => esc_html__('Icon Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .fp-ribbon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .fp-ribbon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fp_ribbon_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .fp-ribbon-container.ribbon-style-1' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .ribbon-style-2 .fp-ribbon, {{WRAPPER}} .ribbon-style-3 .fp-ribbon, {{WRAPPER}} .ribbon-style-4 .fp-ribbon' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'fp_ribbon_text_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .fp-ribbon-text',
			]
		);

        $this->add_responsive_control(
            'fp_ribbon_icon_size',
            [
                'label'         => esc_html__('Icon Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 22],
                'selectors' => [
                    '{{WRAPPER}} .fp-ribbon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .fp-ribbon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_icon_spacing',
            [
                'label'         => esc_html__('Icon Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 5],
                'selectors' => [
                    '{{WRAPPER}} .ribbon-style-1 .fp-ribbon-icon' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ribbon-style-2 .fp-ribbon .fp-ribbon-icon, {{WRAPPER}} .ribbon-style-3 .fp-ribbon .fp-ribbon-icon, {{WRAPPER}} .ribbon-style-4 .fp-ribbon .fp-ribbon-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'fp_ribbon_border',
                'selector'      => '{{WRAPPER}} .fp-ribbon-container.ribbon-style-1, {{WRAPPER}} .ribbon-style-2 .fp-ribbon, {{WRAPPER}} .ribbon-style-3 .fp-ribbon, {{WRAPPER}} .ribbon-style-4 .fp-ribbon',
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .ribbon-style-4 .fp-ribbon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => 'style-4',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_padding', [
                'label'         => esc_html__('Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .fp-ribbon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin!' => 'style-3',
                ],
            ]
        );

        $this->add_responsive_control(
            'fp_ribbon_margin', [
                'label'         => esc_html__('Margin', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .ribbon-style-3 .fp-ribbon, {{WRAPPER}} .ribbon-style-4 .fp-ribbon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
                    'fp_ribbon_skin' => ['style-3', 'style-4'],
                ],
            ]
        );

        $this->end_controls_section();
        // End Ribbon Style Section

    }

    /**
     * @since 1.0.0
     * @access protected
     */
    protected function get_rating() {
        $settings       = $this->get_settings_for_display();
        $rating_scale   = 5;
        $rating         = (float) $settings['fp_rating'] > $rating_scale ? $rating_scale : $settings['fp_rating'];

        return [$rating, $rating_scale];
    }

    /**
     * @since 1.0.0
     * @access protected
     */
    protected function render_stars($icon) {
        $rating_data    = $this->get_rating();
        $rating         = $rating_data[0];
        $floored_rating = (int) $rating;
        $stars_html     = '';

        for ($stars = 1; $stars <= $rating_data[1]; $stars++) {
            if ($stars <= $floored_rating) {
                $stars_html .= '<i class="elementor-star-full">' . $icon . '</i>';
            } elseif ($floored_rating + 1 === $stars && $rating !== $floored_rating) {
                $stars_html .= '<i class="elementor-star-' . ( $rating - $floored_rating ) * 10 . '">' . $icon . '</i>';
            } else {
                $stars_html .= '<i class="elementor-star-empty">' . $icon . '</i>';
            }
        }

        return $stars_html;
    }

    protected function render_ribbons() {
        $settings       = $this->get_settings();

        if($settings['fp_show_ribbon'] === 'yes') { 
            if($settings['fp_ribbon_skin'] === 'style-1') { ?>
                <div class="fp-ribbon-container ribbon-style-1"></div>
                <div class="fp-ribbon ribbon-style-1">
                    <div class="fp-ribbon-text"><?php esc_html_e($settings['fp_ribbon']); ?></div>
                    <div class="fp-ribbon-icon"><?php Icons_Manager::render_icon($settings['fp_ribbon_icon'], [ 'aria-hidden' => 'true' ]); ?></div>
                </div>
            <?php }
            elseif($settings['fp_ribbon_skin'] === 'style-2') { ?>
                <div class="fp-ribbon-container ribbon-style-2">
                    <div class="fp-ribbon">
                        <span class="fp-ribbon-text"><?php esc_html_e($settings['fp_ribbon']); ?></span>
                        <span class="fp-ribbon-icon"><?php Icons_Manager::render_icon($settings['fp_ribbon_icon'], [ 'aria-hidden' => 'true' ]); ?></span>
                    </div>
                </div>
            <?php }
            elseif($settings['fp_ribbon_skin'] === 'style-3') { ?>
                <div class="fp-ribbon-container ribbon-style-3">
                    <div class="fp-ribbon">
                        <span class="fp-ribbon-text"><?php esc_html_e($settings['fp_ribbon']); ?></span>
                        <span class="fp-ribbon-icon"><?php Icons_Manager::render_icon($settings['fp_ribbon_icon'], [ 'aria-hidden' => 'true' ]); ?></span>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="fp-ribbon-container ribbon-style-4">
                    <div class="fp-ribbon">
                        <span class="fp-ribbon-text"><?php esc_html_e($settings['fp_ribbon']); ?></span>
                        <span class="fp-ribbon-icon"><?php Icons_Manager::render_icon($settings['fp_ribbon_icon'], [ 'aria-hidden' => 'true' ]); ?></span>
                    </div>
                </div>
            <?php }
        }
        return;
    }

    /**
     * Render Featured Product Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();
        $rating_data    = $this->get_rating();
        $icon           = '&#9733;';
        $button_link    = $settings['fp_link']['url'];
		$target 		= $settings['fp_link']['is_external'] ? ' target="_blank"' : '';
		$rel 			= $settings['fp_link']['nofollow'] ? ' rel="nofollow"' : '';
        
        switch ($settings['fp_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/featured-product/style-1.php'; // Style 1
                break;
			case 'style-2':
				include AEFE_PATH . 'include/featured-product/style-2.php'; // Style 2
				break;
			case 'style-3':
				include AEFE_PATH . 'include/featured-product/style-3.php'; // Style 3
				break;
            default:
                include AEFE_PATH . 'include/featured-product/style-1.php'; // Default
                break;
        }

    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Featured_Product_Elementor_Widget());