<?php
namespace Elementor;

// Create Category into Elementor.
function affiliate_elements_category() {
    Plugin::instance()->elements_manager->add_category(
        'affiliate-elements', [
            'title' => esc_html__('Affiliate Elements', AEFE_DOMAIN),
            'icon' => 'font'
        ], 1
    );
}

add_action('elementor/init', 'Elementor\affiliate_elements_category');
?>