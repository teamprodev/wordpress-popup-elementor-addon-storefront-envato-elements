<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Single Product
 */
class Single_Product_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-single-product';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Single Product', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-image-box';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['single product', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-single-product'];
    }

    // Adding the controls fields for the Call to Action Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'sp_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'sp_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

		$this->add_control(
			'sp_image',
			[
				'label'         => esc_html__('Choose Image', AEFE_DOMAIN),
				'type'          => Controls_Manager::MEDIA,
				'dynamic'       => [
					'active' => true,
				],
				'default'       => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'separator'     => 'before',
			]
		);

        $this->add_control(
			'sp_image_layout',
			[
				'label'         => esc_html__('Position', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon' => 'eicon-h-align-right',
					],
				],
                'default'       => 'left',
				'prefix_class'  => 'sp-image-align-',
                
                'condition'     => [
					'sp_skin' => 'style-1',
				],
			]
		);

        $this->add_control(
            'sp_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Title', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'sp_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
				'condition'     => [
					'sp_title!' => '',
				],
			]
		);

        $this->add_control(
            'sp_subtitle',
            [
                'label'         => esc_html__('Subtitle', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Subtitle', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'sp_subtitle_tag',
			[
				'label'         => esc_html__('Subtitle HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h3',
				'condition'     => [
					'sp_subtitle!' => '',
				],
			]
		);

        $this->add_control(
            'sp_show_separator',
            [
                'label'         => esc_html__('Show Separator', AEFE_DOMAIN),
                'type'          => Controls_Manager::SWITCHER,
                'default'       => 'yes',
                'label_on'      => esc_html__('Show', AEFE_DOMAIN),
                'label_off'     => esc_html__('Hide', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
            'sp_description',
            [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXTAREA,
                'dynamic'       => ['active' => true],
                'default'       => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum commodo dui fermentum ligula ullamcorper scelerisque.', AEFE_DOMAIN),
                'separator'     => 'before',
            ]
        );

        $this->end_controls_section();

        // Start Price Section
        $this->start_controls_section(
            'sp_section_price', array(
                'label'         => esc_html__('Price', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'sp_price',
            [
                'label'         => esc_html__('Price', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Rs. 1187', AEFE_DOMAIN),
                'label_block'   => true,
            ]
        ); 
        
        $this->add_control(
            'sp_original_price',
            [
                'label'         => esc_html__('Original Price', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Rs. 3299', AEFE_DOMAIN),
                'label_block'   => true,
            ]
        ); 

        $this->end_controls_section();
        // End Price Section

        // Start Ribbon Section
        $this->start_controls_section(
            'sp_section_ribbon', array(
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'sp_ribbon',
            [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Top Pick', AEFE_DOMAIN),
                'label_block'   => true,
            ]
        );

        $this->end_controls_section();
        // End Ribbon Section

        // Start Button Section
        $this->start_controls_section(
            'sp_section_button', array(
                'label'         => esc_html__('Button', AEFE_DOMAIN),
            )
        );

        $this->add_control(
			'sp_button',
			[
				'label'         => esc_html__('Button Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Click Here', AEFE_DOMAIN),
				'separator'     => 'before',
			]
		);

		$this->add_control(
			'sp_link',
			[
				'label'         => esc_html__('Link', AEFE_DOMAIN),
				'type'          => Controls_Manager::URL,
				'dynamic'       => ['active' => true],
			]
		);

        $this->end_controls_section();
        // End Button Section

        // Start Ratings Section
        $this->start_controls_section(
            'sp_section_ratings', array(
                'label'         => esc_html__('Ratings', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'sp_rating', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'type'          => Controls_Manager::NUMBER,
                'min'           => 0,
                'max'           => 5,
                'step'          => 0.1,
                'default'       => 4.5,
                'separator'     => 'before',
				'dynamic'       => ['active' => true],
            ]
        );

        $this->add_control(
            'sp_show_text_rating',
            [
                'label'         => esc_html__('Show Text Rating', AEFE_DOMAIN),
                'type'          => Controls_Manager::SWITCHER,
                'default'       => 'yes',
                'label_on'      => esc_html__('Show', AEFE_DOMAIN),
                'label_off'     => esc_html__('Hide', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'sp_rating_text',
			[
				'label'         => esc_html__('Text', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'dynamic'       => ['active' => true],
				'default'       => esc_html__('4.5 Ratings', AEFE_DOMAIN),
                'condition'     => [
					'sp_show_text_rating' => 'yes',
				],
			]
		);

        $this->end_controls_section();
        // End Ratings Section

        // Start Box Style Section       
        $this->start_controls_section(
            'sp_box_style', [
                'label'         => esc_html__('Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sp_box_padding', [
                'label'         => esc_html__('Box Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'=> '50',
                    'left'  => '50',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'          => 'sp_box_background_hover',
                'label'         => esc_html__('Background', AEFE_DOMAIN),
                'types'         => ['classic', 'gradient'],
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'sp_box_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'solid',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '1',
                            'right'     => '1',
                            'bottom'    => '1',
                            'left'      => '1',
                        ],
                    ],
                    'color'     => [
                        'default'   => '#dadada',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp',
            ]
        );

        $this->add_responsive_control(
            'sp_box_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '10',
                    'bottom'=> '10',
                    'left'  => '10',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'sp_box_shadow_normal',
				'label'         => esc_html__('Box Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-sp',
			]
		);

        $this->end_controls_section();
        // End Box Style Section

        // Start Content Box Style Section       
        $this->start_controls_section(
            'sp_content_box_style', [
                'label'         => esc_html__('Content Box', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sp_content_padding', [
                'label'         => esc_html__('Content Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '20',
                    'right' => '20',
                    'bottom'=> '20',
                    'left'  => '20',
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-content-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'sp_vertical_position',
			[
				'label'     => esc_html__('Vertical Position', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__('Top', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__('Middle', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_html__('Bottom', AEFE_DOMAIN),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'default'       => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-content-grid' => 'align-items: {{VALUE}};',
                ],
                'condition'     => [
					'sp_skin' => 'style-1',
				],
			]
		);

        $this->end_controls_section();
        // End Content Box Style Section

        // Start Image Style Section
        $this->start_controls_section(
            'sp_image_style', [
                'label'         => esc_html__('Image', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sp_image_width', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sp_image_radius', [
                'label'         => esc_html__('Image Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Image Section

        // Start Title Style Section
        $this->start_controls_section(
            'sp_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sp_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-title',
            ]
        );

        $this->add_responsive_control(
            'sp_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-title' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'sp_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Subtitle Style Section
        $this->start_controls_section(
            'sp_subtitle_style', [
                'label'         => esc_html__('Subtitle', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sp_subtitle_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_subtitle',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-subtitle',
            ]
        );

        $this->add_responsive_control(
            'sp_subtitle_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-subtitle' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'sp_subtitle_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Subtitle Style Section

        // Start Separator Style Section
        $this->start_controls_section(
            'sp_separator_style', [
                'label'         => esc_html__('Separator', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'sp_separator_width',
			[
				'label'         => esc_html__('Spearator Width', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 1],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-separator' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'sp_separator_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-separator' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'sp_separator_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-separator' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Separator Style Section

        // Start Description Style Section
        $this->start_controls_section(
            'sp_description_style', [
                'label'         => esc_html__('Description', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sp_description_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_description',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-description',
            ]
        );

        $this->add_responsive_control(
            'sp_description_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-description' => 'text-align: {{VALUE}};',
				],
            ]
        );

		$this->add_responsive_control(
			'sp_description_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Description Style Section

        // Start Price Style Section       
        $this->start_controls_section(
            'sp_price_style', [
                'label'         => esc_html__('Price', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'sp_price_color',
			[
				'label'         => esc_html__('Price Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-price' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_price',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-price',
            ]
        );

        $this->add_control(
			'sp_original_price_color',
			[
				'label'         => esc_html__('Original Price Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#717171',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-original-price' => 'color: {{VALUE}};',
				],
                'condition'     => [
					'sp_original_price!' => '',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Original Price Typography', AEFE_DOMAIN),
                'name'          => 'typography_sp_orginal_price',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-original-price',
                'condition'     => [
					'sp_original_price!' => '',
				],
            ]
        );

        $this->add_responsive_control(
			'sp_price_space_between',
			[
				'label'         => esc_html__('Space Between', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 5],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-original-price' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
                'condition'     => [
					'sp_original_price!' => '',
				],
			]
		);

        $this->add_responsive_control(
			'sp_price_spacing',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-price-container' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Price Style Section

        // Start Rating Style Section   
        $this->start_controls_section(
            'sp_rating_style', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sp_star_size',
            [
                'label'         => esc_html__('Size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'       => ['size'  => 20],
                'selectors' => [
                    '{{WRAPPER}} .sp-rating .elementor-star-rating' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sp_star_space',
            [
                'label'         => esc_html__('Star Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .sp-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .sp-rating .elementor-star-rating i:not(:last-of-type)' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'sp_stars_color',
            [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
                'selectors'     => [
                    '{{WRAPPER}} .sp-rating .elementor-star-rating i:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sp_stars_unmarked_color',
            [
                'label'         => esc_html__('Unmarked Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#FDA0A0',
                'selectors'     => [
                    '{{WRAPPER}} .sp-rating .elementor-star-rating i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
			'sp_rating_text_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#717171',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-rating-text' => 'color: {{VALUE}};',
				],
                'condition'     => [
					'sp_show_text_rating' => 'yes',
				],
                'separator' => 'before',
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'label'         => esc_html__('Text Typography', AEFE_DOMAIN),
                'name'          => 'typography_sp_rating_text',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-rating-text',
                'condition'     => [
					'sp_show_text_rating' => 'yes',
				],
            ]
        );

        $this->add_responsive_control(
			'sp_space_between_rating_label',
			[
				'label'         => esc_html__('Spacing Between', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-rating-text' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'sp_star_spacing_bottom',
			[
				'label'         => esc_html__('Spacing Bottom', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Rating Style Section

        // Start Ribbon Style Section
        $this->start_controls_section(
            'sp_ribbon_style', [
                'label'         => esc_html__('Ribbon', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'sp_ribbon_text_color', [
                'label'         => esc_html__('Text Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#ffffff',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-2-ribbon' => 'color: {{VALUE}};',                    
                ],
            ]
        );

        $this->add_control(
            'sp_ribbon_bg_color', [
                'label'         => esc_html__('Background Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#1D73BE',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon:before' => 'border-right-color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-2-ribbon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_ribbon',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon, {{WRAPPER}} .affiliate-elements-sp .sp-style-2-ribbon',
            ]
        );

        $this->add_responsive_control(
            'sp_ribbon_padding', [
                'label'         => esc_html__('Ribbon Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '5',
                    'right' => '30',
                    'bottom'=> '5',
                    'left'  => '30',
                    'isLinked'  => false,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon,
                     {{WRAPPER}} .affiliate-elements-sp .sp-style-2-ribbon ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'sp_ribbon_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 20],
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-style-1-ribbon' => 'top: {{SIZE}}{{UNIT}};',                    
				],
                'condition'     => [
					'sp_skin' => 'style-1',
				],
			]
		);

        $this->end_controls_section();
        // End Ribbon Style Section

        // Start Button Style Section
        $this->start_controls_section(
            'sp_button_style', [
                'label'         => esc_html__('Button', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_sp_button',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-button',
            ]
        );

        $this->add_responsive_control(
            'sp_button_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-justify',
                    ],
                ],
                'default'       => 'left',
				'prefix_class'  => 'sp-button-align-',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-button-wrapper' => 'text-align: {{VALUE}};',
				],
            ]
        );

        $this->add_responsive_control(
            'sp_button_padding', [
                'label'         => esc_html__('Button Padding', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'default'   => [
                    'top'   => '10',
                    'right' => '60',
                    'bottom'=> '10',
                    'left'  => '60',
                    'isLinked'  => false,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'sp_button_normal_hover',
            [
                'separator'     => 'before',
            ]
        );

        $this->start_controls_tab(
            'sp_button_setting_normal',
            [
                'label'         => esc_html__('Normal', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'sp_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sp_button_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
                'default'       => '#F54141',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-button' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'sp_button_border',
                'fields_options'=> [
                    'border'    => [
                        'default'   => 'double',
                    ],
                    'width'     => [
                        'default'   => [
                            'top'       => '5',
                            'right'     => '5',
                            'bottom'    => '5',
                            'left'      => '5',
                            'isLinked'  => true,
                        ],
                    ],
                    'color'     => [
                        'default'   => '#ffffff',
                    ],
                ],
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-button',
            ]
        );

        $this->add_responsive_control(
            'sp_button_border_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'sp_button_shadow_normal',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-button',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'sp_button_setting_hover',
            [
                'label'         => esc_html__('Hover', AEFE_DOMAIN),
            ]
        );

        $this->add_control(
			'sp_button_hover_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sp_button_background_hover_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-sp .sp-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'sp_button_border_hover',
                'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-button:hover',
            ]
        );

        $this->add_responsive_control(
            'sp_button_border_radius_hover', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-sp .sp-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(), [
				'name'          => 'sp_button_shadow_hover',
				'label'         => esc_html__('Button Shadow', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .affiliate-elements-sp .sp-button:hover',
			]
		);
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
        // End Button Style Section
    }

    /**
     * @since 1.0.0
     * @access protected
     */
    protected function get_rating() {
        $settings       = $this->get_settings_for_display();
        $rating_scale   = 5;
        $rating         = (float) $settings['sp_rating'] > $rating_scale ? $rating_scale : $settings['sp_rating'];

        return [$rating, $rating_scale];
    }

    /**
     * @since 1.0.0
     * @access protected
     */
    protected function render_stars($icon) {
        $rating_data    = $this->get_rating();
        $rating         = $rating_data[0];
        $floored_rating = (int) $rating;
        $stars_html     = '';

        for ($stars = 1; $stars <= $rating_data[1]; $stars++) {
            if ($stars <= $floored_rating) {
                $stars_html .= '<i class="elementor-star-full">' . $icon . '</i>';
            } elseif ($floored_rating + 1 === $stars && $rating !== $floored_rating) {
                $stars_html .= '<i class="elementor-star-' . ( $rating - $floored_rating ) * 10 . '">' . $icon . '</i>';
            } else {
                $stars_html .= '<i class="elementor-star-empty">' . $icon . '</i>';
            }
        }

        return $stars_html;
    }

    /**
     * Render Single Product Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();
        $rating_data    = $this->get_rating();
        $icon           = '&#9733;';
        $title_tag      = $settings['sp_title_tag'];
        $subtitle_tag   = $settings['sp_subtitle_tag'];
        $button_link    = $settings['sp_link']['url'];
		$target 		= $settings['sp_link']['is_external'] ? ' target="_blank"' : '';
		$rel 			= $settings['sp_link']['nofollow'] ? ' rel="nofollow"' : '';

        switch ($settings['sp_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/single-product/style-1.php'; // Style 1
                break;
			case 'style-2':
				include AEFE_PATH . 'include/single-product/style-2.php'; // Style 2
				break;
            default:
                include AEFE_PATH . 'include/single-product/style-1.php'; // Default
                break;
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Single_Product_Elementor_Widget());