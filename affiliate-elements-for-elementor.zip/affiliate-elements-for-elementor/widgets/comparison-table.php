<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Comparison Table
 */
class Comparison_Table_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-comparison-table';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Comparison Table', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-table-of-contents';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['comparison table', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-comparison-table'];
    }

	// Funcyion for include js
	public function get_script_depends()
    {
        return ['aefe-comparison-table-js'];
    }

    // Adding the controls fields for the Comparison Table Element
    protected function _register_controls() {

        // Start General Section
        $this->start_controls_section(
            'ct_section_general', array(
                'label'         => esc_html__('General', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'ct_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Design 3', AEFE_DOMAIN),
					'style-4' => esc_html__('Design 4', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

		$this->add_control(
			'ct_product_count',
			[
				'label'         => esc_html__('Products', AEFE_DOMAIN),
				'type'          => Controls_Manager::NUMBER,
				'default'       => 3,
				'min'           => 2,
				'max'           => 6,
			]
		);

		$this->end_controls_section();
        // End General Section

        // Start Features Section
        $this->start_controls_section(
            'ct_section_feature', array(
                'label'         => esc_html__('Features Box', AEFE_DOMAIN),
            )
        );

		$this->add_control(
			'ct_feature_heading',
			[
				'label'         => esc_html__('Heading', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Product', AEFE_DOMAIN),
			]
		);

        $repeater = new Repeater();

		$repeater->add_control(
			'ct_feature',
			[
                'label'         => esc_html__('Feature', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Feature', AEFE_DOMAIN),
			]
		);

        $this->add_control(
			'ct_feature_list',
			[
				'label'         => esc_html__('Features', AEFE_DOMAIN),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'render_type'   => 'template',
                'default'       => [
                    [
                        'ct_feature' => esc_html__('Title', AEFE_DOMAIN),
                    ],
                    [
                        'ct_feature' => esc_html__('Size', AEFE_DOMAIN),
                    ],
                    [
                        'ct_feature' => esc_html__('Warranty', AEFE_DOMAIN),
                    ],
                    [
                        'ct_feature' => esc_html__('Availability', AEFE_DOMAIN),
                    ],
                ],
			]
        );

        $this->add_control(
			'ct_feature_heading_button',
			[
				'label'         => esc_html__('Button Heading', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);

        $this->end_controls_section();
        // End Features Section

        $this->add_product();

    }

    // Function for adding product sections
    public function add_product() {

        $repeater = new Repeater();

		$repeater->add_control(
			'ct_content_type',
			[
				'label'         => esc_html__('Content', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'label_block'   => false,
				'options'       => [
					'fa fa-check' => [
						'title' => esc_html__('Yes', AEFE_DOMAIN),
						'icon'  => 'fa fa-check',
					],
					'fa fa-close' => [
						'title' => esc_html__('No', AEFE_DOMAIN),
						'icon'  => 'eicon-close',
					],
                    'icon' => [
						'title' => esc_html__('Icon', AEFE_DOMAIN),
						'icon'  => 'fa fa-info',
					],
					'text' => [
						'title' => esc_html__('Text', AEFE_DOMAIN),
						'icon'  => 'fa fa-font',
					],
				],
				'default'       => 'text',
			]
		);

		$repeater->add_control(
			'ct_feature_text',
			[
				'label'         => esc_html__('Feature', AEFE_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__('Feature', AEFE_DOMAIN),
				'condition'     => [
					'ct_content_type' => 'text',
				],
			]
		);

        $repeater->add_control(
			'ct_feature_icon',
			[
				'label'         => esc_html__('Icon', AEFE_DOMAIN),
				'type'          => Controls_Manager::ICONS,
                'default'       => [
                    'value'     => 'fa fa-shopping-bag',
                    'library'   => 'fa-solid',
                ],
				'condition'     => [
					'ct_content_type' => 'icon',
				],
			]
		);

        for ( $i = 1; $i <7; $i++ ) {

            $this->start_controls_section(
				'ct_product_section_' . $i,
				[
					'label'     => sprintf( esc_html__('Product %s', AEFE_DOMAIN), $i ),
					'operator'  => '>',
					'condition' => [
						'ct_product_count' => $this->add_condition_value( $i ),
					],
				]
			);

			$this->add_control(
				'ct_product_title_' . $i,
				[
					'label'     => esc_html__('Title', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('Title', AEFE_DOMAIN),
				]
			);

			$this->add_control(
				'ct_product_price_' . $i,
				[
					'label'     => esc_html__('Price', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('$199', AEFE_DOMAIN),
				]
			);

            $this->add_control(
				'ct_product_image_' . $i,
				[
					'label'     => esc_html__('Image', AEFE_DOMAIN),
					'type'      => Controls_Manager::MEDIA,
				]
			);

			$this->add_control(
				'ct_button_text_' . $i,
				[
					'label'     => esc_html__('Button Text', AEFE_DOMAIN),
					'type'      => Controls_Manager::TEXT,
					'default'   => esc_html__('Buy Now', AEFE_DOMAIN),
				]
			);

			$this->add_control(
				'ct_product_link_' . $i,
				[
					'label'     => esc_html__('Link', AEFE_DOMAIN),
					'type'      => Controls_Manager::URL,
					'default'   => [
						'url'         => '#',
						'is_external' => '',
					],
				]
			);

            $this->add_control(
                'ct_feature_list_' .$i,
                [
                    'label'         => esc_html__('Features', AEFE_DOMAIN),
                    'type'          => Controls_Manager::REPEATER,
                    'fields'        => $repeater->get_controls(),
                    'render_type'   => 'template',
                    'default'       => [
                        [
                            'ct_feature_text' => esc_html__('Watch', AEFE_DOMAIN),
                        ],
                        [
                            'ct_feature_text' => esc_html__('All', AEFE_DOMAIN),
                        ],
                        [
                            'ct_feature_text' => esc_html__('1 Year', AEFE_DOMAIN),
                        ],
                        [
                            'ct_feature_text' => esc_html__('In Stock', AEFE_DOMAIN),
                        ],
                    ],
                ]
            );

			$this->add_control(
				'ct_override_style_' . $i,
				[
					'label'        => esc_html__('Override Style', AEFE_DOMAIN),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'ct_custom_heading_' . $i,
				[
					'label'     	=> esc_html__('Heading', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::HEADING,
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_heading_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-heading.ct-product-' . $i => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_heading_bg_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-heading.ct-product-' . $i => 'background-color: {{VALUE}} !important;',
						'{{WRAPPER}} .ct-product-heading.ct-product-' . $i . ' .ct-inner' => 'fill: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_heading_bg_custom_column_color_' . $i,
				[
					'label'     	=> esc_html__('Column Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-heading.ct-product-' . $i . ' .ct-rect' => 'fill: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-4',
					],
				]
			);

			$this->add_control(
				'ct_heading_bg_custom_border_color_' . $i,
				[
					'label'     	=> esc_html__('Border Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-heading.ct-product-' . $i . ' .ct-border' => 'fill: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-4',
					],
				]
			);

			$this->add_control(
				'ct_custom_count_' . $i,
				[
					'label'     	=> esc_html__('Count', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::HEADING,
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-3',
					],
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'ct_count_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-' . $i . ' .ct-count' => 'color: {{VALUE}}; border-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-3',
					],
				]
			);

			$this->add_control(
				'ct_count_bg_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-' . $i . ' .ct-count-box' => 'background-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-3',
					],
				]
			);

			$this->add_control(
				'ct_custom_price_' . $i,
				[
					'label'     	=> esc_html__('Price', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::HEADING,
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'ct_price_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-price.ct-product-' . $i => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_price_bg_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-price.ct-product-' . $i . ' .ct-price' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ct-style-3 .ct-feature.ct-product-price.ct-product-' . $i => 'background-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin!' => ['style-1', 'style-4'],
					],
				]
			);

			$this->add_control(
				'ct_price_bg_column_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Background Column Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-price.ct-product-' . $i => 'background-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin' => 'style-2',
					],
				]
			);

			$this->add_control(
				'ct_custom_feature_' . $i,
				[
					'label'     	=> esc_html__('Features', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::HEADING,
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'ct_features_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-' . $i => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_features_tbl_check_color_' . $i,
				[
					'label'     	=> esc_html__('Check Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-' . $i . ' i.fa.fa-check' => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_features_tbl_close_color_' . $i,
				[
					'label'     	=> esc_html__('Close Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature.ct-product-' . $i . ' i.fa.fa-close' => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_odd_row_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Odd Row Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} tr:nth-child(even) td.ct-product-' . $i => 'background-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_even_row_custom_color_' . $i,
				[
					'label'     	=> esc_html__('Even Row Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} tr:nth-child(odd) td.ct-product-' . $i => 'background-color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_custom_button_heading_' . $i,
				[
					'label'     	=> esc_html__('Button', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::HEADING,
					'separator' 	=> 'before',
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_custom_button_text_color_' . $i,
				[
					'label'     	=> esc_html__('Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-' . $i . ' .ct-product-btn' => 'color: {{VALUE}};',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_custom_button_bg_color_' . $i,
				[
					'label'     	=> esc_html__('Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-product-' . $i . ' .ct-product-btn' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ct-style-3 .ct-feature-button.ct-product-' . $i => 'background-color: {{VALUE}} !important;',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
					],
				]
			);

			$this->add_control(
				'ct_custom_btn_clm_background_color_' . $i,
				[
					'label'     	=> esc_html__('Column Background Color', AEFE_DOMAIN),
					'type'      	=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .ct-feature-button.ct-product-' . $i => 'background-color: {{VALUE}} !important;',
					],
					'condition' 	=> [
						'ct_override_style_' . $i => 'yes',
						'ct_skin!' => 'style-3',
					],
				]
			);

            $this->end_controls_section();

        }

        // Start General Style Tab
        $this->start_controls_section(
			'section_general_style',
			[
				'label'         => esc_html__('General', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'ct_odd_color',
			[
				'label'         => esc_html__('Odd Row Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#E3E3FB',
				'selectors'     => [
					'{{WRAPPER}} tr:nth-child(even) td' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_even_color',
			[
				'label'         => esc_html__('Even Row Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} tr:nth-child(odd) td' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'table_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'fields_options'=> [
					'border'    => [
						'default' => 'solid',
					],
					'width'     => [
						'default' => [
							'top'    => 1,
							'right'  => 1,
							'bottom' => 1,
							'left'   => 1,
						],
					],
					'color'  => [
						'default' => '#FFFFFF',
					],
				],
				'selector'   	=> '{{WRAPPER}} .affiliate-elements-ct td',
				'label_block'   => true,
			]
		);

		$this->add_control(
            'ct_box_radius_spacing', [
                'label'         => esc_html__('Box Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
				'default'       => ['size'  => 15],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-ct.ct-style-2 td.ct-product-price, {{WRAPPER}} .affiliate-elements-ct.ct-style-4 .ct-header td' => 'border-top-left-radius: {{SIZE}}{{UNIT}}; border-top-right-radius: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-2 td.ct-feature-button, {{WRAPPER}} .affiliate-elements-ct.ct-style-4 td.ct-feature-button, {{WRAPPER}} .affiliate-elements-ct.ct-style-4 td.ct-feature-heading-button' => 'border-bottom-left-radius: {{SIZE}}{{UNIT}}; border-bottom-right-radius: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-3 td' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
				'condition' 	=> [
					'ct_skin!' => ['style-1']
				],
            ]
        );

		$this->add_control(
            'ct_box_column_spacing', [
                'label'         => esc_html__('Column Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
				'default'       => ['size'  => 15],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-ct.ct-style-2 table' => 'border-spacing: {{SIZE}}{{UNIT}} 0px;',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-4 table' => 'border-spacing: {{SIZE}}{{UNIT}} 0px;',
                ],
				'condition' 	=> [
					'ct_skin!' => ['style-1'],
				],
            ]
        );

		$this->add_control(
            'ct_box_row_spacing', [
                'label'         => esc_html__('Row Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
				'default'       => ['size'  => 15],
				'condition' 	=> [
					'ct_skin' => ['style-3'],
				],
            ]
        );

        $this->end_controls_section();
        // End General Style Tab

        // Start Feature Box Style Tab
        $this->start_controls_section(
			'section_feature_box_style',
			[
				'label'         => esc_html__('Feature Box', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'ct_features_box_heading_style',
			[
				'label'         => esc_html__('Heading', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
            'ct_headings_width', [
                'label'         => esc_html__('Box Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 500,
                    ],
                ],
				'mobile_default'       => ['size' => 50, 'unit' => '%'],
                'selectors'     => [
                    '{{WRAPPER}} .ct-features-heading' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'ct_features_heading_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#fff',
				'selectors'     => [
					'{{WRAPPER}} .ct-features-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'feature_heading_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#031468',
				'selectors'     => [
					'{{WRAPPER}} td.ct-features-heading' => 'background-color: {{VALUE}} !important;',
					'{{WRAPPER}} .ct-features-heading .ct-inner' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'feature_heading_bg_column_color',
			[
				'label'         => esc_html__('Column Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .ct-features-heading .ct-rect' => 'fill: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-4',
				],
			]
		);

		$this->add_control(
			'feature_heading_bg_border_color',
			[
				'label'         => esc_html__('Border Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-features-heading .ct-border' => 'fill: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-4',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'ct_features_heading_typography',
				'selector'  => '{{WRAPPER}} .ct-features-heading',
			]
		);

        $this->add_responsive_control(
			'ct_features_text_align',
			[
				'label'     => esc_html__('Alignment', AEFE_DOMAIN),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .ct-features-heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ct_features_text_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-features-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'ct_feature_box_heading_style',
			[
				'label'         => esc_html__('Feature', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
				'separator'     => 'before',
			]
		);

        $this->add_control(
			'ct_feature_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-feature-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_feature_text_bg_color',
			[
				'label'         => esc_html__('Primary Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} tbody tr:nth-child(odd) .ct-feature-heading' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_feature_even_color',
			[
				'label'         => esc_html__('Secondary Row Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} tbody tr:nth-child(even) .ct-feature-heading' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_feature_text_typography',
				'selector'      => '{{WRAPPER}} .ct-feature-heading',
			]
		);

		$this->add_responsive_control(
			'ct_feature_text_align',
			[
				'label'         => esc_html__('Alignment', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'       => 'left',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature-heading' => 'text-align: {{VALUE}};',
				],
			]
		);
        
		$this->add_responsive_control(
			'ct_feature_text_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-feature-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Feature Box Style Tab

        // Start Products Style Tab
        $this->start_controls_section(
			'section_products_box_style',
			[
				'label'         => esc_html__('Products', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'ct_product_box_heading_style',
			[
				'label'         => esc_html__('Heading', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
            'ct_tab_format', [
                'label'         => esc_html__('Start Tab Format From', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1200,
                    ],
                ],
                'default'       => ['size'  => 767],
            ]
        );

        $this->add_control(
			'ct_heading_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_heading_active_text_color',
			[
				'label'         => esc_html__('Active Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading.active' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'ct_heading_text_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#031468',
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-1 tr:nth-child(odd) .ct-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-3 tr:nth-child(odd) .ct-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-2 tr:nth-child(even) .ct-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-4 tr:nth-child(odd) .ct-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} li.ct-product-heading' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .ct-product-heading .ct-inner' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_heading_active_text_bg_color',
			[
				'label'         => esc_html__('Active Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading.active' => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'feature_product_bg_column_color',
			[
				'label'         => esc_html__('Column Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#ffffff',
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading .ct-rect' => 'fill: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-4',
				],
			]
		);

		$this->add_control(
			'feature_product_bg_border_color',
			[
				'label'         => esc_html__('Border Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading .ct-border' => 'fill: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-4',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_heading_text_typography',
				'selector'      => '{{WRAPPER}} .ct-product-heading',
			]
		);

		$this->add_responsive_control(
			'ct_heading_text_align',
			[
				'label'         => esc_html__('Alignment', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'       => 'center',
				'selectors'     => [
					'{{WRAPPER}} .ct-product-heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ct_heading_text_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} td.ct-product-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'ct_heading_spacing', [
                'label'         => esc_html__('Spacing', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .ct-product-img' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
            'ct_image_width', [
                'label'         => esc_html__('Image Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 1000,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .ct-product-img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ct_heading_image_radius', [
                'label'         => esc_html__('Image Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'default'       => ['size' => 20],
                'selectors'     => [
                    '{{WRAPPER}} .ct-product-img' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'ct_product_box_count_style',
			[
				'label'         => esc_html__('Count', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
				'separator'     => 'before',
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->add_control(
			'ct_product_count_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#031468',
				'selectors'     => [
					'{{WRAPPER}} .ct-count' => 'color: {{VALUE}}; border-color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->add_control(
			'ct_product_count_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#E3E3FB',
				'selectors'     => [
					'{{WRAPPER}} .ct-count-box' => 'background-color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_product_count_text_typography',
				'selector'      => '{{WRAPPER}} .ct-count-box',
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->add_responsive_control(
            'ct_count_width', [
                'label'         => esc_html__('Width', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
				'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 100,
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-ct.ct-style-3 .ct-count' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-3 .ct-count-box' => 'top: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .affiliate-elements-ct.ct-style-3 table' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
            ]
        );

		$this->add_control(
			'ct_product_box_price_style',
			[
				'label'         => esc_html__('Price', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
				'separator'     => 'before',
			]
		);

		$this->add_control(
			'ct_product_price_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-feature.ct-product-price' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ct-product-heading .ct-product-price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_product_price_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#E3E3FB',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature.ct-product-price .ct-price' => 'background-color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-2',
				],
			]
		);

		$this->add_control(
			'ct_product_price_column_color',
			[
				'label'         => esc_html__('Column Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature.ct-product-price' => 'background-color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_product_price_text_typography',
				'selector'      => '{{WRAPPER}} .ct-feature.ct-product-price',
				'condition' 	=> [
					'ct_skin!' => 'style-4',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_product_price_text_typography_4',
				'selector'      => '{{WRAPPER}} .ct-product-heading .ct-product-price',
				'condition' 	=> [
					'ct_skin' => 'style-4',
				],
			]
		);

		$this->add_responsive_control(
            'ct_price_box', [
                'label'         => esc_html__('Box size', AEFE_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 150,
                    ],
                ],
                'default'       => ['size' => 80],
                'selectors'     => [
                    '{{WRAPPER}} .ct-price' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
				'condition' 	=> [
					'ct_skin' => 'style-2',
				],
            ]
        );

		$this->add_responsive_control(
			'ct_product_price_text_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-style-2 .ct-feature.ct-product-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ct-style-3 .ct-feature.ct-product-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'ct_skin' => ['style-2', 'style-3']
				],
			]
		);

        $this->add_control(
			'ct_product_box_feature_style',
			[
				'label'         => esc_html__('Feature', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
				'separator'     => 'before',
			]
		);

        $this->add_control(
			'ct_product_features_text_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#000000',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_features_check_color',
			[
				'label'         => esc_html__('Check Icon Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#0AB179',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature i.fa.fa-check' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_features_close_color',
			[
				'label'         => esc_html__('Close Icon Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#F44336',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature i.fa.fa-close' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'ct_product_feature_text_typography',
				'selector'      => '{{WRAPPER}} .ct-feature',
			]
		);

		$this->add_responsive_control(
			'ct_product_feature_text_align',
			[
				'label'         => esc_html__('Alignment', AEFE_DOMAIN),
				'type'          => Controls_Manager::CHOOSE,
				'options'       => [
					'left' => [
						'title' => esc_html__('Left', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', AEFE_DOMAIN),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'       => 'center',
				'selectors'     => [
					'{{WRAPPER}} .ct-feature' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ct_product_feature_text_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-feature, {{WRAPPER}} .ct-feature-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
        // End Products Style Tab

        // Start Button Style Tab
        $this->start_controls_section(
			'ct_button_style',
			[
				'label'         => esc_html__('Button', AEFE_DOMAIN),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ct_button_heading_style',
			[
				'label'         => esc_html__('Heading', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'ct_button_heading_color',
			[
				'label'         => esc_html__('Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-feature-heading-button' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'ct_button_heading_bg_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-ct .ct-feature-heading-button' => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'button_heading_typography',
				'selector'      => '{{WRAPPER}} .ct-feature-heading-button',
			]
		);

        $this->add_control(
			'ct_button_head_style',
			[
				'label'         => esc_html__('Button', AEFE_DOMAIN),
				'type'          => Controls_Manager::HEADING,
				'separator'     => 'before',
			]
		);

		$this->add_control(
			'ct_button_color_3',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .ct-style-3 .ct-product-btn' => 'color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->add_control(
			'ct_btn_background_color_3',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#031468',
				'selectors'     => [
					'{{WRAPPER}} .ct-style-3 .ct-feature-button' => 'background-color: {{VALUE}};',
				],
				'condition' 	=> [
					'ct_skin' => 'style-3',
				],
			]
		);

		$this->start_controls_tabs(
			'ct_button_style_tabs',
			[
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->start_controls_tab(
			'ct_button_style_normal_tab',
			[
				'label'         => esc_html__('Normal', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'ct_button_color',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#FFFFFF',
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_btn_background_color',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'default'       => '#031468',
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ct_button_style_hover_tab',
			[
				'label'         => esc_html__('Hover', AEFE_DOMAIN),
			]
		);

		$this->add_control(
			'ct_button_color_hover',
			[
				'label'         => esc_html__('Text Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'ct_btn_background_color_hover',
			[
				'label'         => esc_html__('Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'ct_btn_border_color_hover',
			[
				'label'         => esc_html__('Border Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'ct_btn_clm_background_color',
			[
				'label'         => esc_html__('Column Background Color', AEFE_DOMAIN),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} tr:last-child td' => 'background-color: {{VALUE}};',
				],
                'separator'     => 'before',
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'btn_text_typography',
				'label'         => esc_html__('Typography', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .ct-product-btn',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'          => 'ct_button_shadow',
				'label'         => 'Box Shadow',
				'selector'      => '{{WRAPPER}} .ct-product-btn',
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'          => 'ct_btn_border',
				'label'         => esc_html__('Border', AEFE_DOMAIN),
				'selector'      => '{{WRAPPER}} .ct-product-btn',
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->add_control(
			'ct_btn_border_radius',
			[
				'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->add_responsive_control(
			'ct_button_padding',
			[
				'label'         => esc_html__('Padding', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', 'em', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->add_responsive_control(
			'ct_button_margin',
			[
				'label'         => esc_html__('Margin', AEFE_DOMAIN),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', 'em', '%' ],
				'selectors'     => [
					'{{WRAPPER}} .ct-product-btn ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' 	=> [
					'ct_skin!' => 'style-3',
				],
			]
		);

		$this->end_controls_section();
        // End Button Style Tab

    }

    // Function for counting products
    public function add_condition_value( $j ) {

		$value = [];

		for ( $i = $j; $i < 7; $i++ ) {
			$value[] = $i;
		}
		return $value;

	}

    /**
     * Render Comparison Table Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings();
		$id = '.elementor-element-' . $this->get_id();

        switch ($settings['ct_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/comparison-table/style-1.php'; // Style 1
                break;
			case 'style-2':
				include AEFE_PATH . 'include/comparison-table/style-2.php'; // Style 2
				break;
			case 'style-3':
				include AEFE_PATH . 'include/comparison-table/style-3.php'; // Style 3
				break;
			case 'style-4':
				include AEFE_PATH . 'include/comparison-table/style-4.php'; // Style 4
				break;
            default:
                include AEFE_PATH . 'include/comparison-table/style-1.php'; // Default
                break;
        }?>

		<style>
		<?php esc_attr_e($id);?> .affiliate-elements-ct.ct-style-3 table {
			border-spacing: <?php esc_attr_e($settings['ct_box_column_spacing']['size']);?>px <?php esc_attr_e($settings['ct_box_row_spacing']['size']); ?>px;
		}
		@media (max-width: <?php esc_attr_e($settings['ct_tab_format']['size']);?>px)  {
			<?php esc_attr_e($id);?> .affiliate-elements-ct ul {
				display: flex;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-ct tr td:nth-child(2) {
				display: table-cell;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-ct td:nth-child(1) {
				display: table-cell;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-ct td {
				display: none;
			}
		}
		@media (min-width: calc(<?php esc_attr_e($settings['ct_tab_format']['size']);?>px + 1px))  {
			<?php esc_attr_e($id);?> .affiliate-elements-ct td {
				display: table-cell !important;
			}
			<?php esc_attr_e($id);?> .affiliate-elements-ct td.ct-hide {
				display: none !important;
			}
		}
		</style><?php

    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Comparison_Table_Elementor_Widget());