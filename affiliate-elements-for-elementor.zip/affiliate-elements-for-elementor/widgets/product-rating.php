<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;   
}

/**
 * Class Product Rating
 */
class Product_Rating_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'aefe-product-rating';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('AE Product Rating', AEFE_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-skill-bar';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['affiliate-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['product rating', 'aefe', 'affiliate elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['aefe-product-rating'];
    }

    // Adding the controls fields for the Product Rating Element
    protected function _register_controls() {

        // Start Content Section
        $this->start_controls_section(
            'pr_content_section', array(
                'label'         => esc_html__('Content', AEFE_DOMAIN),
            )
        );

        $this->add_control(
            'pr_skin', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'style-1' => esc_html__('Design 1', AEFE_DOMAIN),
                    'style-2' => esc_html__('Design 2', AEFE_DOMAIN),
                    'style-3' => esc_html__('Design 3', AEFE_DOMAIN),
                    'style-4' => esc_html__('Design 4', AEFE_DOMAIN),
                ],
                'default'       => 'style-1',
            ]
        );

        $this->add_control(
            'pr_direction', [
                'label'         => esc_html__('Direction', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'ltr' => esc_html__('LTR', AEFE_DOMAIN),
                    'rtl' => esc_html__('RTL', AEFE_DOMAIN),
                ],
                'default'       => 'ltr',
                'condition'     => [
					'pr_skin' => ['style-1', 'style-3']
				],
            ]
        );

        $this->add_control(
            'pr_title',
            [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'default'       => esc_html__('Title', AEFE_DOMAIN),
                'label_block'   => true,
                'separator'     => 'before',
            ]
        );

        $this->add_control(
			'pr_title_tag',
			[
				'label'         => esc_html__('Title HTML Tag', AEFE_DOMAIN),
				'type'          => Controls_Manager::SELECT,
				'options'       => [
					'h1' => esc_html__('H1', AEFE_DOMAIN),
					'h2' => esc_html__('H2', AEFE_DOMAIN),
					'h3' => esc_html__('H3', AEFE_DOMAIN),
					'h4' => esc_html__('H4', AEFE_DOMAIN),
					'h5' => esc_html__('H5', AEFE_DOMAIN),
					'h6' => esc_html__('H6', AEFE_DOMAIN),
				],
				'default'       => 'h2',
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'pr_feature',
            [
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => esc_html__('Lorem ipsum', AEFE_DOMAIN),
            ]
        );

        $repeater->add_control(
            'pr_rating', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'type'          => Controls_Manager::NUMBER,
                'min'           => 0,
                'max'           => 5,
                'step'          => 0.1,
                'default'       => 4.5,
            ]
        );

        $this->add_control(
			'feature_lists',
			[
				'label'         => esc_html__('Features & Rating', AEFE_DOMAIN),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'render_type'   => 'template',
                'default'       => [
                    [
                        'pr_feature' => esc_html__('Cleaning Ability', AEFE_DOMAIN),
                        'pr_rating' => 5,
                    ],
                    [
                        'pr_feature' => esc_html__('Easy of use', AEFE_DOMAIN),
                        'pr_rating' => 4,
                    ],
                    [
                        'pr_feature' => esc_html__('Durability', AEFE_DOMAIN),
                        'pr_rating' => 4.8,
                    ],
                    [
                        'pr_feature' => esc_html__('Stability', AEFE_DOMAIN),
                        'pr_rating' => 2,
                    ],
                    [
                        'pr_feature' => esc_html__('Price', AEFE_DOMAIN),
                        'pr_rating' => 3.5,
                    ],
                ],
                'title_field'   => '{{{ pr_feature }}}',
                'separator'     => 'before',
			]
        );

        $this->add_control(
            'pr_bg_shape', [
                'label'         => esc_html__('Layouts', AEFE_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'pr-circle' => esc_html__('Circle', AEFE_DOMAIN),
                    'pr-rounded' => esc_html__('Rounded', AEFE_DOMAIN),
                    'pr-rectangle' => esc_html__('Rectangle', AEFE_DOMAIN),
                ],
                'default'       => 'pr-rectangle',
                'condition'     => [
					'pr_skin' => ['style-3', 'style-4']
				],
            ]
        );

        $this->end_controls_section();
        // End Content Section

        // Start Title Style Section       
        $this->start_controls_section(
            'pr_title_style', [
                'label'         => esc_html__('Title', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'pr_title_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'left',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pr .pr-title' => 'text-align: {{VALUE}};',
				],
            ]
        );

        $this->add_control(
            'pr_title_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pr_title',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pr .pr-title',
            ]
        );

        $this->add_responsive_control(
			'pr_title_spacing',
			[
				'label'         => esc_html__('Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 30],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
			]
		);

        $this->end_controls_section();
        // End Title Style Section

        // Start Feature Style Section       
        $this->start_controls_section(
            'pr_feature_style', [
                'label'         => esc_html__('Feature', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'pr_feature_alignment',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'flex-start'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'flex-end',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar' => 'justify-content: {{VALUE}};',
				],
                'condition'     => [
					'pr_skin' => ['style-1', 'style-2']
				],
            ]
        );

        $this->add_responsive_control(
            'pr_feature_alignment_3',
            [
                'label'         => esc_html__('Alignment', AEFE_DOMAIN),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'  => [
                        'title' => esc_html__('Left', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'=> [
                        'title' => esc_html__('Center', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', AEFE_DOMAIN),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'       => 'right',
                'selectors'     => [
					'{{WRAPPER}} .affiliate-elements-pr .pr-feature-name' => 'text-align: {{VALUE}};',
				],
                'condition'     => [
					'pr_skin' => ['style-3']
				],
            ]
        );

        $this->add_control(
            'pr_feature_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar, {{WRAPPER}} .affiliate-elements-pr .pr-feature-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pr_feature',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar, {{WRAPPER}} .pr-feature-name',
            ]
        );

        $this->add_responsive_control(
			'pr_feature_space_title',
			[
				'label'         => esc_html__('Title Spacing', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 10],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr.pr-style-3 .pr-feature-name, {{WRAPPER}} .affiliate-elements-pr.pr-style-4 .pr-container-block-in' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
					'pr_skin' => ['style-3', 'style-4'],
				],
			]
		);

        $this->add_responsive_control(
			'pr_feature_space_between',
			[
				'label'         => esc_html__('Space Between List', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 30],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-container-block' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
			]
		);

        $this->end_controls_section();
        // End Feature Style Section

        // Start Rating Style Section       
        $this->start_controls_section(
            'pr_rating_style', [
                'label'         => esc_html__('Rating', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'pr_rating_width',
			[
				'label'         => esc_html__('Width', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 300,
                    ],
                ],
                'default'       => ['size'  => 100],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-rating' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
					'pr_skin!' => 'style-4',
				],
			]
		);

        $this->add_responsive_control(
			'pr_rating_height',
			[
				'label'         => esc_html__('Height', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 50],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-rating' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
                'condition'     => [
					'pr_skin!' => ['style-3', 'style-4'],
				],
			]
		);

        $this->add_control(
            'pr_rating_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#000000',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-rating' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pr_rating_bg_color', [
                'label'         => esc_html__('Background Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#6EC1E4',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-rating' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .affiliate-elements-pr.pr-style-2 .pr-rating:after' => 'border-top-color: {{VALUE}};',
                ],
                'condition'     => [
					'pr_skin!' => ['style-3', 'style-4'],
				],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'          => 'typography_pr_rating',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pr .pr-rating',
            ]
        );

        $this->add_responsive_control(
            'pr_rating_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-rating' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
					'pr_skin!' => 'style-3',
				],
            ]
        );

        $this->end_controls_section();
        // End Rating Style Section

        // Start Progress Bar Style Section       
        $this->start_controls_section(
            'pr_progress_bar_style', [
                'label'         => esc_html__('Progress Bar', AEFE_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'pr_progress_height',
			[
				'label'         => esc_html__('Min Height', AEFE_DOMAIN),
				'type'          => Controls_Manager::SLIDER,
                'default'       => ['size'  => 20],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
			]
		);

        $this->add_control(
            'pr_progress_bar_color', [
                'label'         => esc_html__('Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#6EC1E4',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pr_progress_bar_bg_color', [
                'label'         => esc_html__('Background Color', AEFE_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#dddddd',
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pr_bar_radius', [
                'label'         => esc_html__('Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition'     => [
					'pr_skin!' => ['style-3', 'style-4']
				],
            ]
        );

        $this->add_responsive_control(
            'pr_bar_margin', [
                'label'         => esc_html__('Margin', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(), [
                'name'          => 'pr_bar_background_border',
                'selector'      => '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar-container',
                'separator'     => 'before',
            ]
        );

        $this->add_responsive_control(
            'pr_bar_background_radius', [
                'label'         => esc_html__('Border Radius', AEFE_DOMAIN),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px'],
                'selectors'     => [
                    '{{WRAPPER}} .affiliate-elements-pr .pr-progress-bar-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Progress Bar Section
    }

    /**
     * Render Product Rating Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {

        $settings       = $this->get_settings();
        $title_tag      = $settings['pr_title_tag'];

        switch ($settings['pr_skin']) {
            case 'style-1':
                include AEFE_PATH . 'include/product-rating/style-1.php'; // Style 1
                break;
            case 'style-2':
                include AEFE_PATH . 'include/product-rating/style-2.php'; // Style 2
                break;
            case 'style-3':
                include AEFE_PATH . 'include/product-rating/style-3.php'; // Style 3
                break;
            case 'style-4':
                include AEFE_PATH . 'include/product-rating/style-4.php'; // Style 3
                break;
            default:
                include AEFE_PATH . 'include/product-rating/style-1.php'; // Default
                break;
        }

    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Product_Rating_Elementor_Widget());