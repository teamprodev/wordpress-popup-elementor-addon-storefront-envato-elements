=== Affiliate Elements for Elementor ===
Contributors: techeshta
Tags: affiliate elements for elementor, plugin for affiliate related websites, elementor widgets, advanced elementor widgets, elementor widgets for affiliates, pros and cons widget, call to action widget, product listing widget, comparison table widget, featured product widget
Requires at least: 4.4
Tested up to: 5.8.2
Requires PHP: 5.6
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Affiliate Elements for Elementor is an affiliate marketing featured rich WordPress plugin having all the required features in one place.

== Description ==

<strong>Affiliate Elements for Elementor</strong> plugin give the best Affiliate Elements widgets pack for WordPress. Its advanced elementor widgets enable you to customize everything the way you want and design your site exactly as your imagination. It will help you build your stunning websites without any coding skills.

This plugin provides a precisely designed 4+ of the most trending affiliate elements focusing on user experience, flexibility, and creativity that enable you to drag and drop your way to create an impactful website. We will keep adding more in future versions.

This pack is truly remarkable and unique in its design and usability. So, stop wasting your time searching for widgets. You can find everything you need in one place.

<strong>[View Demo](https://elementor.techeshta.com/affiliate-elements-for-elementor/)</strong>

== Where are the Affiliate Elements for Elementor Plugin Useful? ==

Affiliate Elements for Elementor plugin useful for all WordPress websites. Below is one small list for which purposes you can start using the Affiliate Elements for Elementor plugin.

* Affiliate Related Websites
* Present Your Product Listing in Unique Ways
* Add a Relevant Image to Your Pros and Cons
* Create an Attractive Comparison Table in Minutes
* Easily Change the Look of Your Product Listing
* Decorate Your Featured Product Differently
* Etc.

== How to Start with Affiliate Elements for Elementor? ==

Explore the steps to start the journey with Affiliate Elements for Elementor.

<strong>1. Checkout Live Demo</strong>

We have already implemented a demo for Affiliate Elements for Elementor on our [live demo](https://elementor.techeshta.com/affiliate-elements-for-elementor/) website.

<strong>2. Install Plugin</strong>

First, download the plugin zip file. After that, extract it to your local drive and choose plugin zip file (affiliate-elements-for-elementor.zip) for ‘Upload Plugin’ selection and then Install and Activate Affiliate Elements for Elementor from the admin area.

<strong>3. Select Your Affiliate Elements</strong>

Go to your page, and then edit it with Elementor. On the left-hand side, you will see a section panel with the name "Affiliate Elements". Here; you can use elements on your page with all your appropriate requirements.

<strong>4. Happy Visitors</strong>

Attract more visitors with fabulous and straightforward. No coding skill is required to change listing styles. Beginners can also do that thing. Enjoy with Affiliate Elements for Elementor.

== Readymade Affiliate Elements == 

We have created the five most useful elements to showcase/decorate your website with Affiliate Elements. It allows you to climb the top of your design capabilities.

1. Pros and Cons
2. Comparison Table
3. Featured Product
4. Product Listing
5. Call to Action

== Powerfully Ultimate Plugin Features == 

<strong>1. 4+ Ready Made Designs</strong>

More than 4+ ready-made Affiliate Elements designs to save your precious time. Now focus on content rather than designs.

<strong>2. User-Friendly Controls</strong>

Multiple editing options to make these widgets meet all your personal preferences and choices.

<strong>3. Blocks For Your Every Need</strong>

You can use these widgets to promote services, products, software, or anything. These widgets can be used for multi-purpose.

<strong>4. Fully Customizable Widgets</strong>

You can quickly align every single widget to your design ideas with options for typography, image settings, icons and colors, and more.

<strong>5. Pixel Perfect Designs</strong>

High-quality elements are integrated to help designers and developers build awesome responsive layouts easily.

<strong>6. Translation Ready</strong>

Compatible with WPML, Affiliate Elements for Elementor Plugin allows users to build multilingual Elementor websites easier than ever.

<strong>7. Fully Responsive For Any Devices</strong>

It is fully responsive to smartphones, tablets, iPad, laptops, desktop computers, etc.

<strong>8. Cross-browser Compatibility</strong>

Templates are compatible with all major browsers like Firefox, Chrome, Opera, Safari, etc.

<strong>9. Easy To Install, Use and Customize</strong>

The plugin is user-friendly, with no expertise required. Basic WordPress users can also easily use it.

<strong>10. SEO Friendly</strong>

Affiliate Elements for Elementor plugin is built with search engine optimization in mind to ensure better rankings across all search engines.

<strong>11. No Coding Skills Required</strong>

You don't need any coding or technical skills to install and use the plugin, it installs just like any other plugin. Setup is also easy and our extensive document makes it even more effortless.

<strong>12. Optimized Performance</strong>

The plugin is built with performance in mind. So, the clean and optimized code ensures a blazing loading speed of the site.


== What Makes Affiliate Elements for Elementor Outstanding? ==

* Easy to Setup or Configure.
* Clean Code, Layout, and Design.
* Create Stunning Affiliate Sections with just a Few Clicks.
* Well Documented.
* More Features and Options are coming soon…

== Installation ==

1. Upload the **affiliate-elements-for-elementor.zip** file Via WordPress Admin > Plugins > Add New,
2. Alternately, upload **affiliate-elements-for-elementor** folder to the /wp-content/plugins/ directory via FTP,
3. Activate the **Affiliate Elements for Elementor** plugin from Admin > Plugins.

== Frequently Asked Questions ==

= Can This Plugin Be Used With Any Theme? =
Yes, this plugin can be used with any Elementor compatible WordPress theme.

= How Can We Boost Sales With This Plugin? =
This plugin has specially designed widgets for the affiliate which are going to make your posts look more professional. As a result, you are going to see more clicks and ultimately more sales.

= Will This Plugin Work With Gutenberg Or Any Page Builder? =
No. This is an Elementor plugin and it will work with Elementor only.

= Do You Provide Customer Support? =
Yes, we have a support portal [here](mailto:support@techeshta.com). 

== Screenshots ==	

1. Pros and Cons
2. Comparison Table
3. Featured Product
4. Product Listing
5. Call to Action

**Improvement Suggestions**

If you have any suggestions on how to improve this item, please let us know! We will be happy to consider any advice and appreciate your efforts. We will go through all your feedback weekly and pick the most requested features to include in a future update! Contact us [here](mailto:support@techeshta.com).

== Changelog ==

= 1.1 =
Release Date: November 27th, 2021
* Added: New 6 elements - Feature List, Image Slider, Notice Box, Product Rating, Single Product, Top Pick
* Fixed: WordPress Compatibility to Version 5.8.2     

= 1.0 =
Release Date: June 1, 2021

* Initial Release

== Upgrade Notice ==

= 1.0 =
