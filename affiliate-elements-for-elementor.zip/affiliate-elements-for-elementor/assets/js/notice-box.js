/* Start Notice Box Style JS */
(function( $ ) {
    "use strict";
    $(window).on('elementor/frontend/init', function () {
    var NoticeBox = function () {
        $(".nb-close-btn i").click(function(){
            $(this).closest('.elementor-widget-aefe-notice-box').hide();
        });
    };
        elementorFrontend.hooks.addAction('frontend/element_ready/aefe-notice-box.default', NoticeBox);
    });

})(jQuery)
/* End Notice Box Style JS */