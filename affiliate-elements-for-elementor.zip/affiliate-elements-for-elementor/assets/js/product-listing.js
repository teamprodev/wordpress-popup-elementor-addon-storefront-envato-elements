/* Start Product Listing Style JS */
(function( $ ) {
    "use strict";
    $(window).on('elementor/frontend/init', function () {
    var CompareTable = function ($scope, $) {
        $($scope.find(".pl-product-heading")[0]).addClass("active");
        $scope.find("ul").on("click", "li", function () {
            var pos = $(this).index() + 2;
            $scope.find("tr").find('td:not(:eq(0))').hide();
            $scope.find('td:nth-child(' + pos + ')').css('display', 'table-cell');
            $scope.find("tr").find('th:not(:eq(0))').hide();
            $scope.find('li').removeClass('active');
            $(this).addClass('active');
        });
    };
        elementorFrontend.hooks.addAction('frontend/element_ready/aefe-product-listing.default', CompareTable);
    });

})(jQuery)
/* End Product Listing Style JS */